import Link from 'next/link';
import { AlertCircle, CalendarClock, CreditCard, RefreshCcw, ShieldCheck, XCircle } from 'lucide-react';
import { getViewer } from '@/lib/auth';
import { PricingCards } from '@/components/PricingCards';
import { Faq } from '@/components/Faq';
import { isStripeConfigured } from '@/lib/env';

export const metadata = { title: 'Pricing – Free & Premium €6.99/month' };

const errors: Record<string, string> = {
  'stripe-not-configured': 'Payments are not configured yet on this site (missing Stripe keys). No charge was made.',
  'checkout-failed': 'We could not start the checkout. No charge was made – please try again.',
};

export default async function PricingPage({ searchParams }: { searchParams: { error?: string; checkout?: string; reason?: string } }) {
  const viewer = await getViewer();
  return (
    <div className="py-14">
      <div className="container">
        <div className="mx-auto mb-12 max-w-2xl text-center">
          <p className="eyebrow">Pricing</p>
          <h1 className="mt-2 text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-5xl">Simple, transparent pricing</h1>
          <p className="section-sub">Learn the basics for free forever. Go Premium for the complete path to a Python developer job.</p>
        </div>

        {searchParams.error && (
          <div className="mx-auto mb-8 flex max-w-2xl items-start gap-3 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800 dark:border-red-900 dark:bg-red-500/10 dark:text-red-300">
            <AlertCircle className="h-5 w-5 shrink-0" /> {errors[searchParams.error] ?? 'Something went wrong. No charge was made.'}
          </div>
        )}
        {searchParams.checkout === 'canceled' && (
          <div className="mx-auto mb-8 max-w-2xl rounded-xl border border-slate-200 bg-slate-50 p-4 text-center text-sm text-slate-700 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300">
            Checkout was canceled – you have not been charged.
          </div>
        )}
        {searchParams.reason === 'certificates' && (
          <div className="mx-auto mb-8 max-w-2xl rounded-xl bg-amber-50 p-4 text-center text-sm text-amber-900 dark:bg-amber-500/10 dark:text-amber-200">
            Certificates are included with Premium.
          </div>
        )}
        {!isStripeConfigured() && (
          <p className="mx-auto mb-8 max-w-2xl rounded-xl bg-slate-100 p-3 text-center text-xs text-slate-600 dark:bg-slate-800 dark:text-slate-400">
            Site owner: set STRIPE_SECRET_KEY and STRIPE_PRICE_ID to enable checkout.
          </p>
        )}

        <PricingCards signedIn={!!viewer.user} premiumActive={viewer.premium} />

        {/* Billing terms – shown before payment */}
        <div className="mx-auto mt-16 max-w-4xl">
          <h2 className="text-center text-2xl font-bold text-slate-900 dark:text-white">How Premium billing works</h2>
          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            {[
              [CreditCard, 'Secure payment by Stripe', 'You pay on Stripe’s secure checkout page. We never see or store your card number.'],
              [RefreshCcw, 'Automatic monthly renewal', 'Your subscription renews every month at €6.99 on the same day you subscribed, until you cancel.'],
              [XCircle, 'Cancel anytime', 'Dashboard → Subscription → “Manage or cancel”. No fees, no questions. Cancelling stops all future charges.'],
              [CalendarClock, 'Access until period end', 'After cancelling you keep Premium until the end of the month already paid. We don’t prorate partial months.'],
              [ShieldCheck, 'EU right of withdrawal', 'By starting Premium immediately you agree that digital content is provided at once, and you acknowledge that the 14-day withdrawal right ends when access begins (where permitted by law). See our Terms.'],
              [AlertCircle, 'Failed payments', 'If a payment fails we email you and Stripe retries. If it still fails, Premium is paused until payment succeeds – your progress is kept.'],
            ].map(([Icon, t, d]: any) => (
              <div key={t} className="card flex gap-4 p-5">
                <Icon className="h-5 w-5 shrink-0 text-brand-600" />
                <div>
                  <h3 className="font-semibold text-slate-900 dark:text-white">{t}</h3>
                  <p className="mt-1 text-sm leading-6 text-slate-600 dark:text-slate-400">{d}</p>
                </div>
              </div>
            ))}
          </div>
          <p className="mt-6 text-center text-sm text-slate-500">
            Full details in our{' '}
            <Link href="/terms" className="font-medium text-brand-700 underline">
              Terms of Service
            </Link>{' '}
            and{' '}
            <Link href="/privacy" className="font-medium text-brand-700 underline">
              Privacy Policy
            </Link>
            .
          </p>
        </div>

        <div className="mt-20">
          <h2 className="mb-8 text-center text-2xl font-bold text-slate-900 dark:text-white">Questions</h2>
          <Faq />
        </div>
      </div>
    </div>
  );
}
