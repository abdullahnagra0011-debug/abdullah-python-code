import Link from 'next/link';
import { AlertTriangle, CheckCircle2, Clock, Crown, ExternalLink, Receipt } from 'lucide-react';
import { requireUser } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';

export const metadata = { title: 'Subscription & billing' };

const fmtDate = (d: string | null) => (d ? new Date(d).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }) : '—');
const fmtMoney = (cents: number, cur: string) => new Intl.NumberFormat('en-IE', { style: 'currency', currency: cur.toUpperCase() }).format(cents / 100);

export default async function BillingPage({ searchParams }: { searchParams: { checkout?: string; error?: string } }) {
  const viewer = await requireUser('/dashboard/billing');
  const sub = viewer.subscription;
  const { data: payments } = await createClient()
    .from('payments')
    .select('*')
    .eq('user_id', viewer.user.id)
    .order('created_at', { ascending: false })
    .limit(24);

  const status = sub?.status ?? 'none';
  const pastDue = status === 'past_due' || status === 'unpaid';

  return (
    <div className="mx-auto max-w-3xl space-y-8">
      <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Subscription & billing</h1>

      {searchParams.checkout === 'success' && !viewer.premium && (
        <div className="flex gap-3 rounded-xl border border-sky-200 bg-sky-50 p-4 text-sm text-sky-900 dark:border-sky-900 dark:bg-sky-500/10 dark:text-sky-200">
          <Clock className="h-5 w-5 shrink-0" />
          <div>
            <p className="font-semibold">We&apos;re confirming your payment with Stripe…</p>
            <p className="mt-0.5">This usually takes a few seconds. Refresh this page – Premium unlocks as soon as Stripe confirms the payment.</p>
          </div>
        </div>
      )}
      {searchParams.checkout === 'success' && viewer.premium && (
        <div className="flex items-center gap-3 rounded-xl bg-brand-50 p-4 text-sm font-medium text-brand-800 dark:bg-brand-500/10 dark:text-brand-300">
          <CheckCircle2 className="h-5 w-5" /> Payment confirmed – welcome to Premium!
        </div>
      )}
      {searchParams.error === 'portal' && (
        <p className="rounded-xl bg-red-50 p-4 text-sm text-red-800 dark:bg-red-500/10 dark:text-red-300">Could not open the billing portal. Please try again.</p>
      )}
      {pastDue && (
        <div className="flex gap-3 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-900 dark:border-red-900 dark:bg-red-500/10 dark:text-red-200">
          <AlertTriangle className="h-5 w-5 shrink-0" />
          <div>
            <p className="font-semibold">Your last payment failed</p>
            <p className="mt-0.5">Update your payment method to restore Premium. Stripe will retry automatically.</p>
          </div>
        </div>
      )}

      <div className="card p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="text-sm text-slate-500">Current plan</p>
            <p className="mt-1 flex items-center gap-2 text-2xl font-bold text-slate-900 dark:text-white">
              {viewer.premium ? (
                <>
                  <Crown className="h-6 w-6 text-amber-500" /> Premium
                </>
              ) : (
                'Free'
              )}
            </p>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
              {viewer.premium ? '€6.99 per month' : '€0 – access to the first 6 modules'}
            </p>
          </div>
          <span className={viewer.premium ? 'badge-green' : pastDue ? 'badge bg-red-50 text-red-700' : 'badge-slate'}>Status: {status}</span>
        </div>

        {sub?.current_period_end && status !== 'none' && (
          <div className="mt-5 rounded-xl bg-slate-50 p-4 text-sm text-slate-700 dark:bg-slate-800/60 dark:text-slate-300">
            {sub.cancel_at_period_end ? (
              <>
                Your subscription is <b>cancelled</b>. You keep Premium until <b>{fmtDate(sub.current_period_end)}</b>; you will not be charged again.
              </>
            ) : status === 'canceled' ? (
              <>Your subscription ended on {fmtDate(sub.current_period_end)}.</>
            ) : (
              <>
                Next payment of <b>€6.99</b> on <b>{fmtDate(sub.current_period_end)}</b>. Renews automatically every month.
              </>
            )}
          </div>
        )}

        <div className="mt-6 flex flex-wrap gap-3">
          {sub?.stripe_customer_id && status !== 'none' ? (
            <form action="/api/stripe/portal" method="post">
              <button className="btn-primary">
                Manage or cancel subscription <ExternalLink className="h-4 w-4" />
              </button>
            </form>
          ) : null}
          {!viewer.premium && (
            <Link href="/pricing" className={sub?.stripe_customer_id && status !== 'none' ? 'btn-secondary' : 'btn-primary'}>
              <Crown className="h-4 w-4" /> Get Premium
            </Link>
          )}
        </div>
      </div>

      <div className="card p-6" id="cancel">
        <h2 className="font-semibold text-slate-900 dark:text-white">How to cancel</h2>
        <ol className="mt-3 list-decimal space-y-1.5 pl-5 text-sm text-slate-600 dark:text-slate-400">
          <li>Click “Manage or cancel subscription” above. You are taken to Stripe&apos;s secure billing portal.</li>
          <li>Choose “Cancel plan” and confirm.</li>
          <li>You keep Premium until the end of the paid month and are not charged again. Your progress stays saved.</li>
        </ol>
        <p className="mt-3 text-sm text-slate-500">
          In the portal you can also update your card and download invoices. Need help? Contact support from the footer.
        </p>
      </div>

      <div className="card overflow-hidden">
        <h2 className="flex items-center gap-2 border-b border-slate-100 px-6 py-4 font-semibold text-slate-900 dark:border-slate-800 dark:text-white">
          <Receipt className="h-4 w-4" /> Payment history
        </h2>
        {!payments?.length ? (
          <p className="px-6 py-5 text-sm text-slate-500">No payments yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-left text-xs uppercase tracking-wider text-slate-500 dark:bg-slate-800/50">
                <tr>
                  <th className="px-6 py-3">Date</th>
                  <th className="px-6 py-3">Amount</th>
                  <th className="px-6 py-3">Status</th>
                  <th className="px-6 py-3">Invoice</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {payments.map((p: any) => (
                  <tr key={p.id}>
                    <td className="px-6 py-3">{fmtDate(p.created_at)}</td>
                    <td className="px-6 py-3 font-medium">{fmtMoney(p.amount, p.currency)}</td>
                    <td className="px-6 py-3">
                      <span className={p.status === 'paid' ? 'badge-green' : 'badge bg-red-50 text-red-700 dark:bg-red-500/10 dark:text-red-300'}>{p.status}</span>
                    </td>
                    <td className="px-6 py-3">
                      {p.invoice_url ? (
                        <a href={p.invoice_url} target="_blank" rel="noopener noreferrer" className="font-medium text-brand-700 hover:underline dark:text-brand-400">
                          View
                        </a>
                      ) : (
                        '—'
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
