import Link from 'next/link';
import {
  ArrowRight,
  Award,
  BookCheck,
  Crown,
  Flame,
  Lock,
  Medal,
  PlayCircle,
  Target,
  Trophy,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { requireUser } from '@/lib/auth';
import { getCurriculum, flattenLessons, lessonKey } from '@/lib/content';
import { getProgress, allCourseStatuses, learningStreak, achievements } from '@/lib/progress';
import { createClient } from '@/lib/supabase/server';
import { PASS_RATE } from '@/content/courses';

export const metadata = { title: 'Dashboard' };

const certMessages: Record<string, string> = {
  'not-eligible': 'You have not met all completion criteria for that course yet.',
  error: 'The certificate could not be issued. Please try again.',
  'unknown-course': 'Unknown course.',
};

export default async function DashboardPage({ searchParams }: { searchParams: { cert?: string } }) {
  const viewer = await requireUser('/dashboard');
  const [modules, progress] = await Promise.all([getCurriculum(), getProgress(viewer.user.id)]);
  const { data: certs } = await createClient().from('certificates').select('id, course_slug, issued_at, revoked').eq('user_id', viewer.user.id);

  const all = flattenLessons(modules);
  const accessible = all.filter((l) => l.module.free || viewer.premium);
  const nextLesson = accessible.find((l) => !progress.completed.has(lessonKey(l.moduleSlug, l.slug)));
  const lockedNext = !nextLesson ? all.find((l) => !progress.completed.has(lessonKey(l.moduleSlug, l.slug))) : null;
  const { streak, activeDays } = learningStreak(progress);
  const courses = allCourseStatuses(modules, progress);
  const badges = achievements(progress, modules, streak);
  const totalPct = all.length ? Math.round((progress.completed.size / all.length) * 100) : 0;
  const firstName = (viewer.profile?.full_name || viewer.user.email || '').split(' ')[0].split('@')[0];

  const recent = Array.from(progress.completed.entries())
    .sort((a, b) => b[1].localeCompare(a[1]))
    .slice(0, 6)
    .map(([key, at]) => {
      const [m, l] = key.split('/');
      const lesson = all.find((x) => x.moduleSlug === m && x.slug === l);
      return lesson ? { lesson, at } : null;
    })
    .filter(Boolean) as { lesson: (typeof all)[number]; at: string }[];

  return (
    <div className="space-y-8">
      {searchParams.cert && certMessages[searchParams.cert] && (
        <div className="flex items-center gap-3 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900 dark:border-amber-900 dark:bg-amber-500/10 dark:text-amber-200">
          <AlertCircle className="h-5 w-5" /> {certMessages[searchParams.cert]}
        </div>
      )}

      {/* welcome */}
      <div className="flex flex-wrap items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900 dark:text-white">Welcome back, {firstName} 👋</h1>
          <p className="mt-1 text-slate-600 dark:text-slate-400">
            {progress.completed.size === 0 ? 'Ready for your very first lesson? It takes about 10 minutes.' : 'Keep the momentum going – small daily steps add up.'}
          </p>
        </div>
        {viewer.premium ? (
          <span className="badge-amber !px-3 !py-1.5 !text-sm">
            <Crown className="h-4 w-4" /> Premium member
          </span>
        ) : (
          <Link href="/pricing" className="btn-primary">
            <Crown className="h-4 w-4" /> Upgrade to Premium
          </Link>
        )}
      </div>

      {/* stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat icon={BookCheck} label="Lessons completed" value={`${progress.completed.size}`} sub={`of ${all.length} · ${totalPct}%`} />
        <Stat icon={Flame} label="Learning streak" value={`${streak} day${streak === 1 ? '' : 's'}`} sub={`${activeDays} active days in total`} accent="text-orange-500" />
        <Stat icon={Target} label="Exercise sets" value={`${progress.best.size}`} sub={`${progress.results.length} attempts`} />
        <Stat icon={Award} label="Certificates" value={`${(certs ?? []).filter((c: any) => !c.revoked).length}`} sub={`${courses.filter((c) => c.eligible).length} course(s) ready`} accent="text-amber-500" />
      </div>

      <div className="grid gap-8 lg:grid-cols-[1.6fr_1fr]">
        <div className="space-y-8">
          {/* next lesson */}
          <section className="relative overflow-hidden rounded-2xl bg-slate-900 p-6 text-white dark:bg-brand-950 sm:p-8">
            <div className="absolute inset-0 bg-[radial-gradient(30rem_15rem_at_100%_0%,rgba(18,183,106,.35),transparent)]" />
            <div className="relative">
              <p className="text-sm font-semibold text-brand-300">Recommended next lesson</p>
              {nextLesson ? (
                <>
                  <h2 className="mt-2 text-2xl font-bold">{nextLesson.title}</h2>
                  <p className="mt-1 text-slate-300">
                    Module {nextLesson.module.number}: {nextLesson.module.title}
                  </p>
                  <Link href={`/learn/${nextLesson.moduleSlug}/${nextLesson.slug}`} className="btn-primary mt-6">
                    <PlayCircle className="h-5 w-5" /> {progress.completed.size ? 'Continue learning' : 'Start lesson 1'}
                  </Link>
                </>
              ) : lockedNext ? (
                <>
                  <h2 className="mt-2 text-2xl font-bold">You finished all free lessons! 🎉</h2>
                  <p className="mt-1 text-slate-300">Next up: {lockedNext.module.title} – part of Premium.</p>
                  <Link href="/pricing" className="btn-primary mt-6">
                    <Lock className="h-4 w-4" /> Unlock the full path
                  </Link>
                </>
              ) : (
                <>
                  <h2 className="mt-2 text-2xl font-bold">You completed every lesson. Incredible! 🏆</h2>
                  <p className="mt-1 text-slate-300">Claim your certificates below and keep building projects.</p>
                </>
              )}
            </div>
          </section>

          {/* courses */}
          <section>
            <h2 className="mb-4 text-lg font-semibold text-slate-900 dark:text-white">Your courses</h2>
            <div className="space-y-4">
              {courses.map((c) => {
                const cert = (certs ?? []).find((x: any) => x.course_slug === c.course.slug && !x.revoked);
                return (
                  <div key={c.course.slug} className="card p-5">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div>
                        <h3 className="font-semibold text-slate-900 dark:text-white">{c.course.title}</h3>
                        <p className="text-sm text-slate-500">
                          {c.done}/{c.total} lessons · {c.course.level}
                        </p>
                      </div>
                      {cert ? (
                        <Link href={`/certificates/${cert.id}`} className="btn-secondary !py-2">
                          <Award className="h-4 w-4 text-amber-500" /> View certificate
                        </Link>
                      ) : c.eligible ? (
                        <form action="/api/certificates/issue" method="post">
                          <input type="hidden" name="course" value={c.course.slug} />
                          <button className="btn-primary !py-2">
                            <Award className="h-4 w-4" /> Claim certificate
                          </button>
                        </form>
                      ) : (
                        <span className="text-sm font-semibold text-brand-700 dark:text-brand-400">{c.pct}%</span>
                      )}
                    </div>
                    <div className="mt-3 h-2 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                      <div className="h-full rounded-full bg-gradient-to-r from-brand-500 to-emerald-400 transition-all" style={{ width: `${c.pct}%` }} />
                    </div>
                    {!c.eligible && !cert && (c.done > 0 || c.missingQuizzes.length < c.course.modules.length) && (
                      <p className="mt-3 text-xs text-slate-500">
                        Certificate requires: all lessons completed{c.lessonsComplete ? ' ✓' : ''} and ≥{PASS_RATE * 100}% in every module&apos;s exercises
                        {c.missingQuizzes.length ? ` (${c.missingQuizzes.length} remaining)` : ' ✓'}
                        {!viewer.premium && ' · Premium plan'}.
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          </section>

          {/* quiz results */}
          <section>
            <h2 className="mb-4 text-lg font-semibold text-slate-900 dark:text-white">Quiz & exercise results</h2>
            {progress.best.size === 0 ? (
              <p className="card p-5 text-sm text-slate-500">No scores yet. Finish a module and open its “Exercises & Quiz” page.</p>
            ) : (
              <div className="card divide-y divide-slate-100 dark:divide-slate-800">
                {Array.from(progress.best.entries()).map(([slug, b]) => {
                  const m = modules.find((x) => x.slug === slug);
                  const pct = Math.round((b.score / b.total) * 100);
                  return (
                    <Link key={slug} href={`/learn/${slug}/exercises`} className="flex items-center justify-between gap-4 px-5 py-3.5 hover:bg-slate-50 dark:hover:bg-slate-800/50">
                      <span className="text-sm font-medium text-slate-800 dark:text-slate-200">
                        {m?.number}. {m?.title ?? slug}
                      </span>
                      <span className={`text-sm font-semibold ${pct >= PASS_RATE * 100 ? 'text-brand-700 dark:text-brand-400' : 'text-amber-600'}`}>
                        {b.score}/{b.total} · {pct}%
                      </span>
                    </Link>
                  );
                })}
              </div>
            )}
          </section>
        </div>

        <div className="space-y-8">
          {/* achievements */}
          <section>
            <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-slate-900 dark:text-white">
              <Trophy className="h-5 w-5 text-amber-500" /> Achievements
            </h2>
            <div className="grid grid-cols-2 gap-3">
              {badges.map((b) => (
                <div key={b.id} className={`card p-4 text-center ${b.earned ? '' : 'opacity-50 grayscale'}`} title={b.desc}>
                  <Medal className={`mx-auto h-8 w-8 ${b.earned ? 'text-amber-500' : 'text-slate-400'}`} />
                  <p className="mt-2 text-sm font-semibold text-slate-900 dark:text-white">{b.title}</p>
                  <p className="text-[11px] leading-4 text-slate-500">{b.desc}</p>
                </div>
              ))}
            </div>
          </section>

          {/* completed lessons */}
          <section>
            <h2 className="mb-4 text-lg font-semibold text-slate-900 dark:text-white">Recently completed</h2>
            {recent.length === 0 ? (
              <p className="card p-5 text-sm text-slate-500">Lessons you mark as completed appear here.</p>
            ) : (
              <ul className="card divide-y divide-slate-100 dark:divide-slate-800">
                {recent.map(({ lesson, at }) => (
                  <li key={lesson.moduleSlug + lesson.slug}>
                    <Link href={`/learn/${lesson.moduleSlug}/${lesson.slug}`} className="flex items-center gap-3 px-4 py-3 hover:bg-slate-50 dark:hover:bg-slate-800/50">
                      <CheckCircle2 className="h-4 w-4 shrink-0 text-brand-500" />
                      <span className="flex-1 text-sm text-slate-800 dark:text-slate-200">{lesson.title}</span>
                      <span className="text-xs text-slate-400">{new Date(at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}</span>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
            <Link href="/courses" className="mt-3 inline-flex items-center gap-1 text-sm font-medium text-brand-700 dark:text-brand-400">
              Browse all modules <ArrowRight className="h-4 w-4" />
            </Link>
          </section>
        </div>
      </div>
    </div>
  );
}

function Stat({ icon: Icon, label, value, sub, accent = 'text-brand-600' }: { icon: any; label: string; value: string; sub: string; accent?: string }) {
  return (
    <div className="card p-5">
      <div className="flex items-center gap-2 text-sm font-medium text-slate-500">
        <Icon className={`h-4 w-4 ${accent}`} /> {label}
      </div>
      <p className="mt-2 text-3xl font-bold tracking-tight text-slate-900 dark:text-white">{value}</p>
      <p className="mt-0.5 text-xs text-slate-500">{sub}</p>
    </div>
  );
}
