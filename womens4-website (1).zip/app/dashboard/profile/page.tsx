import Link from 'next/link';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { Download, KeyRound, Trash2, AlertCircle, CheckCircle2 } from 'lucide-react';
import { requireUser } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';

export const metadata = { title: 'Profile & privacy' };

async function saveProfile(formData: FormData) {
  'use server';
  const viewer = await requireUser('/dashboard/profile');
  const full_name = String(formData.get('full_name') ?? '').trim().slice(0, 120);
  const marketing_consent = formData.get('marketing_consent') === 'on';
  const { error } = await createClient()
    .from('profiles')
    .update({ full_name, marketing_consent, updated_at: new Date().toISOString() })
    .eq('id', viewer.user.id);
  revalidatePath('/dashboard', 'layout');
  redirect(`/dashboard/profile?${error ? 'error=save' : 'saved=1'}`);
}

export default async function ProfilePage({ searchParams }: { searchParams: { saved?: string; error?: string; need?: string } }) {
  const viewer = await requireUser('/dashboard/profile');
  const p = viewer.profile;

  return (
    <div className="mx-auto max-w-2xl space-y-8">
      <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Profile & privacy</h1>

      {searchParams.saved && (
        <p className="flex items-center gap-2 rounded-xl bg-brand-50 p-3 text-sm text-brand-800 dark:bg-brand-500/10 dark:text-brand-300">
          <CheckCircle2 className="h-4 w-4" /> Profile saved.
        </p>
      )}
      {searchParams.need === 'name' && (
        <p className="flex items-center gap-2 rounded-xl bg-amber-50 p-3 text-sm text-amber-900 dark:bg-amber-500/10 dark:text-amber-200">
          <AlertCircle className="h-4 w-4" /> Add your full name first – it is printed on your certificate.
        </p>
      )}
      {searchParams.error && (
        <p className="flex items-center gap-2 rounded-xl bg-red-50 p-3 text-sm text-red-800 dark:bg-red-500/10 dark:text-red-300">
          <AlertCircle className="h-4 w-4" />
          {searchParams.error === 'confirm'
            ? 'Type DELETE to confirm account deletion.'
            : searchParams.error === 'delete-failed'
              ? 'Your account could not be deleted. Please contact support.'
              : 'Could not save your profile.'}
        </p>
      )}

      <form action={saveProfile} className="card space-y-5 p-6">
        <h2 className="font-semibold text-slate-900 dark:text-white">Personal details</h2>
        <div>
          <label className="label" htmlFor="full_name">
            Full name (shown on certificates)
          </label>
          <input id="full_name" name="full_name" defaultValue={p?.full_name ?? ''} className="input" required maxLength={120} />
        </div>
        <div>
          <label className="label">Email</label>
          <input value={viewer.user.email ?? ''} disabled className="input opacity-70" />
        </div>
        <label className="flex items-start gap-2.5 text-sm text-slate-600 dark:text-slate-400">
          <input type="checkbox" name="marketing_consent" defaultChecked={p?.marketing_consent} className="mt-1 accent-brand-600" />
          Send me occasional emails about new courses and features (optional, unsubscribe anytime).
        </label>
        <button className="btn-primary">Save changes</button>
      </form>

      <div className="card space-y-4 p-6">
        <h2 className="font-semibold text-slate-900 dark:text-white">Security</h2>
        <Link href="/forgot-password" className="btn-secondary">
          <KeyRound className="h-4 w-4" /> Change password
        </Link>
        <p className="text-xs text-slate-500">We email you a secure link to set a new password.</p>
      </div>

      <div className="card space-y-4 p-6">
        <h2 className="font-semibold text-slate-900 dark:text-white">Your data (GDPR)</h2>
        <p className="text-sm text-slate-600 dark:text-slate-400">
          Download a copy of everything we store about you: profile, progress, scores, certificates and payment history.
        </p>
        <a href="/api/account/export" className="btn-secondary">
          <Download className="h-4 w-4" /> Download my data (JSON)
        </a>
      </div>

      <form action="/api/account/delete" method="post" className="card space-y-4 border-red-200 p-6 dark:border-red-900/60">
        <h2 className="flex items-center gap-2 font-semibold text-red-700 dark:text-red-400">
          <Trash2 className="h-4 w-4" /> Delete account
        </h2>
        <p className="text-sm text-slate-600 dark:text-slate-400">
          This permanently deletes your account, progress and certificates and immediately cancels any active subscription (no further charges). This cannot be undone.
          Invoices required for tax purposes are kept by Stripe.
        </p>
        <div>
          <label className="label" htmlFor="confirm">
            Type <b>DELETE</b> to confirm
          </label>
          <input id="confirm" name="confirm" className="input max-w-xs" autoComplete="off" />
        </div>
        <button className="btn bg-red-600 text-white hover:bg-red-700">Delete my account permanently</button>
      </form>
    </div>
  );
}
