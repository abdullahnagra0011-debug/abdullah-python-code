import { notFound, redirect } from 'next/navigation';
import { getModule } from '@/lib/content';

export default async function ModuleIndex({ params }: { params: { module: string } }) {
  const mod = await getModule(params.module);
  if (!mod || !mod.lessons.length) notFound();
  redirect(`/learn/${mod.slug}/${mod.lessons[0].slug}`);
}
