import Link from 'next/link';
import { notFound, redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { ArrowLeft, Trash2 } from 'lucide-react';
import { requireAdmin } from '@/lib/auth';
import { createAdminClient } from '@/lib/supabase/admin';
import type { Question, Level } from '@/lib/exercise-types';

const slugify = (s: string) =>
  s
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
    .slice(0, 60);

const LEVELS: Level[] = ['Beginner', 'Intermediate', 'Advanced'];

async function updateModule(formData: FormData) {
  'use server';
  await requireAdmin();
  const id = String(formData.get('id'));
  await createAdminClient()
    .from('custom_modules')
    .update({
      title: String(formData.get('title')),
      description: String(formData.get('description') ?? ''),
      position: Number(formData.get('position') || 100),
      is_free: formData.get('is_free') === 'on',
      published: formData.get('published') === 'on',
    })
    .eq('id', id);
  revalidatePath('/', 'layout');
  redirect(`/admin/content/${id}?saved=module`);
}

async function deleteModule(formData: FormData) {
  'use server';
  await requireAdmin();
  await createAdminClient().from('custom_modules').delete().eq('id', String(formData.get('id')));
  revalidatePath('/', 'layout');
  redirect('/admin/content');
}

async function saveLesson(formData: FormData) {
  'use server';
  await requireAdmin();
  const moduleId = String(formData.get('module_id'));
  const lessonId = String(formData.get('lesson_id') ?? '');
  const title = String(formData.get('title')).trim();
  const row = {
    module_id: moduleId,
    title,
    slug: slugify(String(formData.get('slug') || title)),
    body_md: String(formData.get('body_md') ?? ''),
    position: Number(formData.get('position') || 0),
    published: formData.get('published') === 'on',
  };
  const admin = createAdminClient();
  if (lessonId) await admin.from('custom_lessons').update(row).eq('id', lessonId);
  else await admin.from('custom_lessons').insert(row);
  revalidatePath('/', 'layout');
  redirect(`/admin/content/${moduleId}?saved=lesson`);
}

async function deleteLesson(formData: FormData) {
  'use server';
  await requireAdmin();
  await createAdminClient().from('custom_lessons').delete().eq('id', String(formData.get('lesson_id')));
  revalidatePath('/', 'layout');
  redirect(`/admin/content/${formData.get('module_id')}`);
}

async function addQuestion(formData: FormData) {
  'use server';
  await requireAdmin();
  const moduleId = String(formData.get('module_id'));
  const type = String(formData.get('type'));
  const level = (LEVELS.includes(formData.get('level') as Level) ? formData.get('level') : 'Beginner') as Level;
  const prompt = String(formData.get('prompt') ?? '').trim();
  const explain = String(formData.get('explain') ?? '').trim();
  let q: Question | null = null;
  if (type === 'mcq') {
    const options = String(formData.get('options') ?? '')
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean);
    const answer = Number(formData.get('answer')) - 1;
    if (options.length >= 2 && answer >= 0 && answer < options.length) q = { type: 'mcq', level, prompt, options, answer, explain };
  } else if (type === 'fill') {
    const code = String(formData.get('code') ?? '');
    const answer = String(formData.get('accepted') ?? '')
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean);
    if (code.includes('___') && answer.length) q = { type: 'fill', level, prompt, code, answer, explain };
  } else if (type === 'code') {
    q = {
      type: 'code',
      level,
      prompt,
      starter: String(formData.get('starter') ?? ''),
      tests: String(formData.get('tests') ?? ''),
      explain,
      hint: String(formData.get('hint') ?? '') || undefined,
    };
  }
  if (!q || !prompt) redirect(`/admin/content/${moduleId}?error=question`);
  const admin = createAdminClient();
  const { count } = await admin.from('custom_questions').select('id', { count: 'exact', head: true }).eq('module_id', moduleId);
  await admin.from('custom_questions').insert({ module_id: moduleId, data: q, position: count ?? 0 });
  redirect(`/admin/content/${moduleId}?saved=question`);
}

async function deleteQuestion(formData: FormData) {
  'use server';
  await requireAdmin();
  await createAdminClient().from('custom_questions').delete().eq('id', String(formData.get('question_id')));
  redirect(`/admin/content/${formData.get('module_id')}`);
}

export default async function EditModule({ params, searchParams }: { params: { id: string }; searchParams: { saved?: string; error?: string } }) {
  await requireAdmin();
  const admin = createAdminClient();
  const { data: mod } = await admin.from('custom_modules').select('*').eq('id', params.id).maybeSingle();
  if (!mod) notFound();
  const [{ data: lessons }, { data: questions }] = await Promise.all([
    admin.from('custom_lessons').select('*').eq('module_id', mod.id).order('position'),
    admin.from('custom_questions').select('*').eq('module_id', mod.id).order('position'),
  ]);

  return (
    <div className="space-y-8">
      <Link href="/admin/content" className="inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-900">
        <ArrowLeft className="h-4 w-4" /> All content
      </Link>
      {searchParams.saved && <p className="rounded-xl bg-brand-50 p-3 text-sm text-brand-800">Saved.</p>}
      {searchParams.error && <p className="rounded-xl bg-red-50 p-3 text-sm text-red-800">The question is incomplete. Check the fields.</p>}

      <form action={updateModule} className="card grid gap-4 p-6 sm:grid-cols-2">
        <input type="hidden" name="id" value={mod.id} />
        <h1 className="text-xl font-bold sm:col-span-2">Module: {mod.title}</h1>
        <div>
          <label className="label">Title</label>
          <input name="title" defaultValue={mod.title} className="input" required />
        </div>
        <div>
          <label className="label">Position</label>
          <input name="position" type="number" defaultValue={mod.position} className="input" />
        </div>
        <div className="sm:col-span-2">
          <label className="label">Description</label>
          <textarea name="description" defaultValue={mod.description} rows={2} className="input" />
        </div>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" name="is_free" defaultChecked={mod.is_free} className="accent-brand-600" /> Free for everyone
        </label>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" name="published" defaultChecked={mod.published} className="accent-brand-600" /> Published (visible to learners)
        </label>
        <div className="flex gap-3 sm:col-span-2">
          <button className="btn-primary">Save module</button>
          <Link href={`/learn/${mod.slug}`} className="btn-secondary" target="_blank">
            Preview
          </Link>
        </div>
      </form>

      <section className="space-y-4">
        <h2 className="text-lg font-semibold">Lessons</h2>
        {(lessons ?? []).map((l: any) => (
          <details key={l.id} className="card p-5">
            <summary className="cursor-pointer font-medium">
              {l.position}. {l.title} {!l.published && <span className="badge-slate ml-2">Draft</span>}
            </summary>
            <LessonForm moduleId={mod.id} lesson={l} />
            <form action={deleteLesson} className="mt-2">
              <input type="hidden" name="module_id" value={mod.id} />
              <input type="hidden" name="lesson_id" value={l.id} />
              <button className="inline-flex items-center gap-1 text-xs font-medium text-red-600">
                <Trash2 className="h-3.5 w-3.5" /> Delete lesson
              </button>
            </form>
          </details>
        ))}
        <details className="card p-5" open={!lessons?.length}>
          <summary className="cursor-pointer font-medium text-brand-700">+ Add lesson</summary>
          <LessonForm moduleId={mod.id} />
        </details>
      </section>

      <section className="space-y-4">
        <h2 className="text-lg font-semibold">Exercises & quiz ({questions?.length ?? 0})</h2>
        {(questions ?? []).map((q: any, i: number) => (
          <div key={q.id} className="card flex items-start justify-between gap-4 p-4 text-sm">
            <div>
              <span className="badge-slate mr-2">{q.data.type}</span>
              <span className="badge-green mr-2">{q.data.level}</span>
              <span className="font-medium">
                {i + 1}. {q.data.prompt}
              </span>
            </div>
            <form action={deleteQuestion}>
              <input type="hidden" name="module_id" value={mod.id} />
              <input type="hidden" name="question_id" value={q.id} />
              <button className="text-xs font-medium text-red-600">Delete</button>
            </form>
          </div>
        ))}
        <form action={addQuestion} className="card grid gap-4 p-6 sm:grid-cols-2">
          <input type="hidden" name="module_id" value={mod.id} />
          <h3 className="font-semibold sm:col-span-2">Add a question</h3>
          <div>
            <label className="label">Type</label>
            <select name="type" className="input">
              <option value="mcq">Multiple choice</option>
              <option value="fill">Fill in the code</option>
              <option value="code">Coding challenge</option>
            </select>
          </div>
          <div>
            <label className="label">Difficulty</label>
            <select name="level" className="input">
              {LEVELS.map((l) => (
                <option key={l}>{l}</option>
              ))}
            </select>
          </div>
          <div className="sm:col-span-2">
            <label className="label">Question / task</label>
            <textarea name="prompt" required rows={2} className="input" />
          </div>
          <fieldset className="rounded-xl border border-slate-200 p-4 dark:border-slate-700 sm:col-span-2">
            <legend className="px-1 text-xs font-semibold text-slate-500">Multiple choice</legend>
            <label className="label">Options (one per line)</label>
            <textarea name="options" rows={4} className="input font-mono" />
            <label className="label mt-3">Correct option number (1 = first)</label>
            <input name="answer" type="number" min={1} className="input w-28" />
          </fieldset>
          <fieldset className="rounded-xl border border-slate-200 p-4 dark:border-slate-700 sm:col-span-2">
            <legend className="px-1 text-xs font-semibold text-slate-500">Fill in the code</legend>
            <label className="label">Code with ___ marking the blank</label>
            <textarea name="code" rows={3} className="input font-mono" />
            <label className="label mt-3">Accepted answers (one per line)</label>
            <textarea name="accepted" rows={2} className="input font-mono" />
          </fieldset>
          <fieldset className="rounded-xl border border-slate-200 p-4 dark:border-slate-700 sm:col-span-2">
            <legend className="px-1 text-xs font-semibold text-slate-500">Coding challenge</legend>
            <label className="label">Starter code</label>
            <textarea name="starter" rows={4} className="input font-mono" />
            <label className="label mt-3">Tests (Python asserts; `_output` holds printed text)</label>
            <textarea name="tests" rows={3} className="input font-mono" placeholder={'assert _output.strip() == "Hello"\nassert add(2, 3) == 5, "add(2, 3) should be 5"'} />
            <label className="label mt-3">Hint (optional)</label>
            <input name="hint" className="input" />
          </fieldset>
          <div className="sm:col-span-2">
            <label className="label">Explanation (shown after answering)</label>
            <textarea name="explain" rows={2} className="input" />
          </div>
          <div className="sm:col-span-2">
            <button className="btn-primary">Add question</button>
          </div>
        </form>
      </section>

      <form action={deleteModule} className="card border-red-200 p-5">
        <input type="hidden" name="id" value={mod.id} />
        <p className="text-sm text-slate-600">Deleting a module removes all its lessons and questions.</p>
        <button className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-red-600">
          <Trash2 className="h-4 w-4" /> Delete module
        </button>
      </form>
    </div>
  );
}

function LessonForm({ moduleId, lesson }: { moduleId: string; lesson?: any }) {
  return (
    <form action={saveLesson} className="mt-4 grid gap-4 sm:grid-cols-3">
      <input type="hidden" name="module_id" value={moduleId} />
      {lesson && <input type="hidden" name="lesson_id" value={lesson.id} />}
      <div className="sm:col-span-2">
        <label className="label">Title</label>
        <input name="title" defaultValue={lesson?.title} required className="input" />
      </div>
      <div>
        <label className="label">Position</label>
        <input name="position" type="number" defaultValue={lesson?.position ?? 0} className="input" />
      </div>
      <div className="sm:col-span-3">
        <label className="label">Slug (optional)</label>
        <input name="slug" defaultValue={lesson?.slug} className="input" />
      </div>
      <div className="sm:col-span-3">
        <label className="label">Content (Markdown). Use ```python for runnable “Try it Yourself” examples, ```python-norun for display-only code.</label>
        <textarea name="body_md" defaultValue={lesson?.body_md} rows={14} className="input font-mono !text-xs" />
      </div>
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" name="published" defaultChecked={lesson?.published ?? true} className="accent-brand-600" /> Published
      </label>
      <div className="sm:col-span-3">
        <button className="btn-primary">{lesson ? 'Save lesson' : 'Add lesson'}</button>
      </div>
    </form>
  );
}
