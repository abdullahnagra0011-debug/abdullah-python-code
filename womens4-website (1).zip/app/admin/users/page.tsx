import { revalidatePath } from 'next/cache';
import { requireAdmin } from '@/lib/auth';
import { createAdminClient, hasServiceRole } from '@/lib/supabase/admin';
import { getStripe } from '@/lib/stripe';
import { syncSubscription } from '@/lib/billing';

export const metadata = { title: 'Admin · Users' };

async function setRole(formData: FormData) {
  'use server';
  const me = await requireAdmin();
  const id = String(formData.get('id'));
  const role = formData.get('role') === 'admin' ? 'admin' : 'student';
  if (id === me.user.id) return; // don't lock yourself out
  await createAdminClient().from('profiles').update({ role }).eq('id', id);
  revalidatePath('/admin/users');
}

async function cancelSubscription(formData: FormData) {
  'use server';
  await requireAdmin();
  const subId = String(formData.get('sub'));
  const immediate = formData.get('mode') === 'now';
  const stripe = getStripe();
  const sub = immediate ? await stripe.subscriptions.cancel(subId) : await stripe.subscriptions.update(subId, { cancel_at_period_end: true });
  await syncSubscription(sub);
  revalidatePath('/admin/users');
}

async function resyncSubscription(formData: FormData) {
  'use server';
  await requireAdmin();
  const sub = await getStripe().subscriptions.retrieve(String(formData.get('sub')));
  await syncSubscription(sub);
  revalidatePath('/admin/users');
}

export default async function AdminUsers({ searchParams }: { searchParams: { q?: string; page?: string } }) {
  await requireAdmin();
  if (!hasServiceRole()) return null;
  const admin = createAdminClient();
  const page = Math.max(1, Number(searchParams.page) || 1);
  const per = 50;
  let query = admin
    .from('profiles')
    .select('id, email, full_name, role, created_at', { count: 'exact' })
    .order('created_at', { ascending: false })
    .range((page - 1) * per, page * per - 1);
  if (searchParams.q) query = query.or(`email.ilike.%${searchParams.q.replace(/[%,()]/g, '')}%,full_name.ilike.%${searchParams.q.replace(/[%,()]/g, '')}%`);
  const { data: users, count } = await query;
  const ids = (users ?? []).map((u: any) => u.id);
  const { data: subs } = ids.length ? await admin.from('subscriptions').select('*').in('user_id', ids) : { data: [] };
  const { data: progress } = ids.length ? await admin.from('lesson_progress').select('user_id').in('user_id', ids) : { data: [] };
  const subOf = (id: string) => (subs ?? []).find((s: any) => s.user_id === id);
  const lessonsOf = (id: string) => (progress ?? []).filter((p: any) => p.user_id === id).length;

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Users & subscriptions</h1>
          <p className="text-sm text-slate-500">{count ?? 0} users</p>
        </div>
        <form className="flex gap-2">
          <input name="q" defaultValue={searchParams.q} placeholder="Search email or name" className="input w-64" />
          <button className="btn-secondary">Search</button>
        </form>
      </div>

      <div className="card mt-6 overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-left text-xs uppercase tracking-wider text-slate-500 dark:bg-slate-800/50">
            <tr>
              <th className="px-4 py-3">User</th>
              <th className="px-4 py-3">Joined</th>
              <th className="px-4 py-3">Lessons</th>
              <th className="px-4 py-3">Subscription</th>
              <th className="px-4 py-3">Role</th>
              <th className="px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {(users ?? []).map((u: any) => {
              const s = subOf(u.id);
              const live = s && ['active', 'trialing', 'past_due'].includes(s.status);
              return (
                <tr key={u.id} className="align-top">
                  <td className="px-4 py-3">
                    <p className="font-medium text-slate-900 dark:text-white">{u.full_name || '—'}</p>
                    <p className="text-xs text-slate-500">{u.email}</p>
                  </td>
                  <td className="px-4 py-3 text-slate-500">{new Date(u.created_at).toLocaleDateString('en-GB')}</td>
                  <td className="px-4 py-3">{lessonsOf(u.id)}</td>
                  <td className="px-4 py-3">
                    {s && s.status !== 'none' ? (
                      <>
                        <span className={['active', 'trialing'].includes(s.status) ? 'badge-green' : 'badge-slate'}>{s.status}</span>
                        {s.cancel_at_period_end && <span className="badge-amber ml-1">cancelling</span>}
                        {s.current_period_end && <p className="mt-1 text-xs text-slate-500">until {new Date(s.current_period_end).toLocaleDateString('en-GB')}</p>}
                        {s.stripe_customer_id && (
                          <a
                            className="mt-1 block text-xs text-brand-700 hover:underline"
                            href={`https://dashboard.stripe.com/customers/${s.stripe_customer_id}`}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            Open in Stripe
                          </a>
                        )}
                      </>
                    ) : (
                      <span className="text-slate-400">Free</span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <form action={setRole} className="flex items-center gap-1">
                      <input type="hidden" name="id" value={u.id} />
                      <select name="role" defaultValue={u.role} className="rounded-lg border border-slate-200 bg-transparent px-2 py-1 text-xs dark:border-slate-700">
                        <option value="student">student</option>
                        <option value="admin">admin</option>
                      </select>
                      <button className="text-xs font-medium text-brand-700">Save</button>
                    </form>
                  </td>
                  <td className="space-y-1 px-4 py-3">
                    {live && s.stripe_subscription_id && (
                      <>
                        {!s.cancel_at_period_end && (
                          <form action={cancelSubscription}>
                            <input type="hidden" name="sub" value={s.stripe_subscription_id} />
                            <input type="hidden" name="mode" value="period_end" />
                            <button className="text-xs font-medium text-amber-700 hover:underline">Cancel at period end</button>
                          </form>
                        )}
                        <form action={cancelSubscription}>
                          <input type="hidden" name="sub" value={s.stripe_subscription_id} />
                          <input type="hidden" name="mode" value="now" />
                          <button className="text-xs font-medium text-red-600 hover:underline">Cancel immediately</button>
                        </form>
                      </>
                    )}
                    {s?.stripe_subscription_id && (
                      <form action={resyncSubscription}>
                        <input type="hidden" name="sub" value={s.stripe_subscription_id} />
                        <button className="text-xs font-medium text-slate-600 hover:underline">Re-sync from Stripe</button>
                      </form>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <div className="mt-4 flex gap-2">
        {page > 1 && (
          <a className="btn-secondary" href={`?page=${page - 1}${searchParams.q ? `&q=${encodeURIComponent(searchParams.q)}` : ''}`}>
            Previous
          </a>
        )}
        {(count ?? 0) > page * per && (
          <a className="btn-secondary" href={`?page=${page + 1}${searchParams.q ? `&q=${encodeURIComponent(searchParams.q)}` : ''}`}>
            Next
          </a>
        )}
      </div>
      <p className="mt-4 text-xs text-slate-500">Refunds and plan changes are handled in the Stripe dashboard; changes sync back automatically via webhooks.</p>
    </div>
  );
}
