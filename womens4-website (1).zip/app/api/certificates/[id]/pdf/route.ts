import { NextResponse } from 'next/server';
import { getCertificate, renderCertificatePdf } from '@/lib/certificates';

export const runtime = 'nodejs';

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const cert = await getCertificate(params.id);
  if (!cert || cert.revoked) return NextResponse.json({ error: 'Certificate not found' }, { status: 404 });
  const bytes = await renderCertificatePdf(cert);
  return new NextResponse(Buffer.from(bytes), {
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="womens4-certificate-${cert.course_slug}.pdf"`,
    },
  });
}
