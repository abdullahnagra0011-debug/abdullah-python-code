import { NextResponse } from 'next/server';
import { getViewer } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';

/** GDPR Art. 15/20 – download all personal data we hold, as JSON. */
export async function GET() {
  const viewer = await getViewer();
  if (!viewer.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const sb = createClient();
  const uid = viewer.user.id;
  const [profile, subscription, payments, progress, results, certificates] = await Promise.all([
    sb.from('profiles').select('*').eq('id', uid).maybeSingle(),
    sb.from('subscriptions').select('status, current_period_end, cancel_at_period_end, updated_at').eq('user_id', uid).maybeSingle(),
    sb.from('payments').select('*').eq('user_id', uid),
    sb.from('lesson_progress').select('*').eq('user_id', uid),
    sb.from('exercise_results').select('*').eq('user_id', uid),
    sb.from('certificates').select('*').eq('user_id', uid),
  ]);
  const payload = {
    exported_at: new Date().toISOString(),
    account: { id: uid, email: viewer.user.email, created_at: viewer.user.created_at },
    profile: profile.data,
    subscription: subscription.data,
    payments: payments.data,
    lesson_progress: progress.data,
    exercise_results: results.data,
    certificates: certificates.data,
  };
  return new NextResponse(JSON.stringify(payload, null, 2), {
    headers: {
      'Content-Type': 'application/json',
      'Content-Disposition': 'attachment; filename="womens4-my-data.json"',
    },
  });
}
