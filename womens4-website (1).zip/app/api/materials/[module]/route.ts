import { NextResponse } from 'next/server';
import { getViewer } from '@/lib/auth';
import { getModule } from '@/lib/content';

/** Premium: download a module's lessons as a Markdown study guide. */
export async function GET(_req: Request, { params }: { params: { module: string } }) {
  const viewer = await getViewer();
  if (!viewer.user) return NextResponse.json({ error: 'Log in required' }, { status: 401 });
  if (!viewer.premium) return NextResponse.json({ error: 'Premium required' }, { status: 403 });
  const mod = await getModule(params.module);
  if (!mod) return NextResponse.json({ error: 'Not found' }, { status: 404 });

  const md = [
    `# Module ${mod.number}: ${mod.title}`,
    '',
    mod.description,
    '',
    ...mod.lessons.flatMap((l, i) => [`## ${i + 1}. ${l.title}`, '', l.body.replace(/```python-norun/g, '```python'), '']),
    '---',
    'womens4.com study guide – for personal use only.',
  ].join('\n');

  return new NextResponse(md, {
    headers: {
      'Content-Type': 'text/markdown; charset=utf-8',
      'Content-Disposition': `attachment; filename="womens4-${String(mod.number).padStart(2, '0')}-${mod.slug}.md"`,
    },
  });
}
