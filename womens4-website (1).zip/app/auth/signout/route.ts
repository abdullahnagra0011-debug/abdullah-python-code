import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { SITE_URL, isSupabaseConfigured } from '@/lib/env';

export async function POST() {
  if (isSupabaseConfigured()) await createClient().auth.signOut();
  return NextResponse.redirect(`${SITE_URL}/`, 303);
}
