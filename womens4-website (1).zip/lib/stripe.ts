import Stripe from 'stripe';

let stripe: Stripe | null = null;

/** Server-only Stripe client. */
export function getStripe() {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) throw new Error('STRIPE_SECRET_KEY is not configured');
  if (!stripe) stripe = new Stripe(key, { appInfo: { name: 'womens4.com' } });
  return stripe;
}
