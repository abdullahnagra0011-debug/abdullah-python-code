import { createClient } from './supabase/server';
import { COURSES, PASS_RATE, type Course } from '@/content/courses';
import { EXERCISES } from '@/content/exercises';
import { lessonKey, type Module } from './content';

export type ProgressData = {
  completed: Map<string, string>; // lessonKey -> completed_at
  results: { module_slug: string; score: number; total: number; created_at: string }[];
  best: Map<string, { score: number; total: number }>;
};

export async function getProgress(userId: string): Promise<ProgressData> {
  const sb = createClient();
  const [{ data: lp }, { data: er }] = await Promise.all([
    sb.from('lesson_progress').select('lesson_key, completed_at').eq('user_id', userId),
    sb
      .from('exercise_results')
      .select('module_slug, score, total, created_at')
      .eq('user_id', userId)
      .order('created_at', { ascending: false }),
  ]);
  const completed = new Map<string, string>((lp ?? []).map((r: any) => [r.lesson_key, r.completed_at]));
  const results = (er ?? []) as ProgressData['results'];
  const best = new Map<string, { score: number; total: number }>();
  for (const r of results) {
    const prev = best.get(r.module_slug);
    if (!prev || r.score / r.total > prev.score / prev.total) best.set(r.module_slug, { score: r.score, total: r.total });
  }
  return { completed, results, best };
}

export function moduleProgress(mod: Module, completed: Map<string, string>) {
  const done = mod.lessons.filter((l) => completed.has(lessonKey(mod.slug, l.slug))).length;
  return { done, total: mod.lessons.length, pct: mod.lessons.length ? Math.round((done / mod.lessons.length) * 100) : 0 };
}

export function courseStatus(course: Course, modules: Module[], p: ProgressData) {
  const mods = course.modules.map((s) => modules.find((m) => m.slug === s)).filter(Boolean) as Module[];
  let done = 0;
  let total = 0;
  const missingQuizzes: string[] = [];
  for (const m of mods) {
    const mp = moduleProgress(m, p.completed);
    done += mp.done;
    total += mp.total;
    if (EXERCISES[m.slug]?.length) {
      const b = p.best.get(m.slug);
      if (!b || b.score / b.total < PASS_RATE) missingQuizzes.push(m.title);
    }
  }
  return {
    done,
    total,
    pct: total ? Math.round((done / total) * 100) : 0,
    lessonsComplete: total > 0 && done === total,
    missingQuizzes,
    eligible: total > 0 && done === total && missingQuizzes.length === 0,
  };
}

export function allCourseStatuses(modules: Module[], p: ProgressData) {
  return COURSES.map((c) => ({ course: c, ...courseStatus(c, modules, p) }));
}

/** Consecutive days (ending today or yesterday) with at least one completed lesson or exercise. */
export function learningStreak(p: ProgressData) {
  const days = new Set<string>();
  p.completed.forEach((d) => days.add(d.slice(0, 10)));
  p.results.forEach((r) => days.add(r.created_at.slice(0, 10)));
  const dayStr = (d: Date) => d.toISOString().slice(0, 10);
  const cursor = new Date();
  if (!days.has(dayStr(cursor))) cursor.setUTCDate(cursor.getUTCDate() - 1);
  let streak = 0;
  while (days.has(dayStr(cursor))) {
    streak++;
    cursor.setUTCDate(cursor.getUTCDate() - 1);
  }
  return { streak, activeDays: days.size };
}

export function achievements(p: ProgressData, modules: Module[], streak: number) {
  const lessons = p.completed.size;
  const perfect = Array.from(p.best.values()).some((b) => b.score === b.total && b.total > 0);
  const modulesDone = modules.filter((m) => m.lessons.length && moduleProgress(m, p.completed).pct === 100).length;
  return [
    { id: 'first-step', title: 'First Step', desc: 'Complete your first lesson', earned: lessons >= 1 },
    { id: 'ten-lessons', title: 'Getting Serious', desc: 'Complete 10 lessons', earned: lessons >= 10 },
    { id: 'fifty-lessons', title: 'Half Century', desc: 'Complete 50 lessons', earned: lessons >= 50 },
    { id: 'first-module', title: 'Module Master', desc: 'Finish an entire module', earned: modulesDone >= 1 },
    { id: 'quiz-taker', title: 'Quiz Taker', desc: 'Submit your first exercise set', earned: p.results.length >= 1 },
    { id: 'perfect', title: 'Perfectionist', desc: 'Score 100% on an exercise set', earned: perfect },
    { id: 'streak-3', title: 'On Fire', desc: 'Keep a 3-day learning streak', earned: streak >= 3 },
    { id: 'streak-7', title: 'Unstoppable', desc: 'Keep a 7-day learning streak', earned: streak >= 7 },
  ];
}
