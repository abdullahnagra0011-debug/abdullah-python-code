import { EXERCISES } from '@/content/exercises';
import type { Question } from './exercise-types';
import { createAdminClient, hasServiceRole } from './supabase/admin';

/** Full questions (with answers) – server only. */
export async function getQuestions(moduleSlug: string): Promise<Question[]> {
  if (EXERCISES[moduleSlug]) return EXERCISES[moduleSlug];
  if (!hasServiceRole()) return [];
  try {
    const admin = createAdminClient();
    const { data: mod } = await admin
      .from('custom_modules')
      .select('id')
      .eq('slug', moduleSlug)
      .eq('published', true)
      .maybeSingle();
    if (!mod) return [];
    const { data } = await admin.from('custom_questions').select('data').eq('module_id', mod.id).order('position');
    return (data ?? []).map((r: any) => r.data as Question).filter((q) => q && q.type && q.prompt);
  } catch {
    return [];
  }
}
