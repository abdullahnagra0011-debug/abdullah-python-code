import { redirect } from 'next/navigation';
import type { User } from '@supabase/supabase-js';
import { createClient } from './supabase/server';
import { isSupabaseConfigured } from './env';

export type Profile = {
  id: string;
  email: string | null;
  full_name: string | null;
  role: 'student' | 'admin';
  marketing_consent: boolean;
  created_at: string;
};

export type Subscription = {
  user_id: string;
  stripe_customer_id: string | null;
  stripe_subscription_id: string | null;
  status: string;
  price_id: string | null;
  current_period_end: string | null;
  cancel_at_period_end: boolean;
};

export async function getUser(): Promise<User | null> {
  if (!isSupabaseConfigured()) return null;
  const supabase = (await createClient());
  const { data } = await supabase.auth.getUser();
  return data.user ?? null;
}

export async function getProfile(userId: string): Promise<Profile | null> {
  const supabase = (await createClient());
  const { data } = await supabase.from('profiles').select('*').eq('id', userId).maybeSingle();
  return (data as Profile) ?? null;
}

export async function getSubscription(userId: string): Promise<Subscription | null> {
  const supabase = (await createClient());
  const { data } = await supabase.from('subscriptions').select('*').eq('user_id', userId).maybeSingle();
  return (data as Subscription) ?? null;
}

/** Premium only while Stripe reports the subscription as active/trialing and the paid period hasn't ended. */
export function isPremiumSubscription(sub: Subscription | null): boolean {
  if (!sub) return false;
  if (!['active', 'trialing'].includes(sub.status)) return false;
  if (!sub.current_period_end) return false;
  return new Date(sub.current_period_end).getTime() > Date.now();
}

export async function getViewer() {
  const user = await getUser();
  if (!user) return { user: null, profile: null, subscription: null, premium: false, isAdmin: false };
  const [profile, subscription] = await Promise.all([getProfile(user.id), getSubscription(user.id)]);
  return {
    user,
    profile,
    subscription,
    premium: isPremiumSubscription(subscription),
    isAdmin: profile?.role === 'admin',
  };
}

export async function requireUser(next = '/dashboard') {
  const viewer = await getViewer();
  if (!viewer.user) redirect(`/login?next=${encodeURIComponent(next)}`);
  return viewer as typeof viewer & { user: User };
}

export async function requireAdmin() {
  const viewer = await requireUser('/admin');
  if (!viewer.isAdmin) redirect('/dashboard');
  return viewer;
}
