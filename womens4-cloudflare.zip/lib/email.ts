/**
 * Transactional email via Resend's HTTP API. If RESEND_API_KEY is not set,
 * nothing is sent and the function reports that – it never pretends.
 */
export async function sendEmail(to: string, subject: string, html: string): Promise<{ sent: boolean; reason?: string }> {
  const key = process.env.RESEND_API_KEY;
  const from = process.env.EMAIL_FROM;
  if (!key || !from) {
    console.info(`[email] skipped "${subject}" to ${to}: RESEND_API_KEY / EMAIL_FROM not configured`);
    return { sent: false, reason: 'not-configured' };
  }
  try {
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from, to, subject, html }),
    });
    if (!res.ok) return { sent: false, reason: `resend-${res.status}` };
    return { sent: true };
  } catch (e) {
    return { sent: false, reason: (e as Error).message };
  }
}

const wrap = (body: string) => `
<div style="font-family:Inter,Segoe UI,Arial,sans-serif;max-width:560px;margin:0 auto;color:#101828">
  <div style="font-weight:700;font-size:20px;color:#027a48;margin-bottom:16px">womens4.com</div>
  ${body}
  <p style="color:#667085;font-size:12px;margin-top:32px">You receive this email because you have a womens4.com account.</p>
</div>`;

export const emails = {
  subscriptionStarted: (siteUrl: string, periodEnd: string) =>
    wrap(`<h2>Welcome to womens4.com Premium 🎉</h2>
    <p>Your payment was successful and your Premium subscription (€6.99/month) is now active.</p>
    <p>It renews automatically on <b>${periodEnd}</b>. You can cancel any time from
    <a href="${siteUrl}/dashboard/billing">Billing</a> – you keep access until the end of the paid period.</p>
    <p><a href="${siteUrl}/courses" style="background:#039855;color:#fff;padding:10px 16px;border-radius:8px;text-decoration:none">Continue learning</a></p>`),
  paymentFailed: (siteUrl: string) =>
    wrap(`<h2>We couldn't process your payment</h2>
    <p>Your latest womens4.com Premium payment failed. Stripe will retry automatically, but please update your payment method to avoid losing access.</p>
    <p><a href="${siteUrl}/dashboard/billing">Update payment method</a></p>`),
  subscriptionCanceled: (siteUrl: string) =>
    wrap(`<h2>Your Premium subscription has ended</h2>
    <p>You still have access to all free lessons and your progress is saved. You can re-subscribe any time at <a href="${siteUrl}/pricing">${siteUrl}/pricing</a>.</p>`),
};
