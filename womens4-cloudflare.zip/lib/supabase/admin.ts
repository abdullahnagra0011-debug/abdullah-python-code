import { createClient } from '@supabase/supabase-js';

/**
 * Service-role client. SERVER ONLY – bypasses RLS.
 * Never import this file from a 'use client' component.
 */
export function createAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error('SUPABASE_SERVICE_ROLE_KEY / NEXT_PUBLIC_SUPABASE_URL are not configured');
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}

export function hasServiceRole() {
  return Boolean(process.env.SUPABASE_SERVICE_ROLE_KEY && process.env.NEXT_PUBLIC_SUPABASE_URL);
}
