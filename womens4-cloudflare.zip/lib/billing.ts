import type Stripe from 'stripe';
import { getStripe } from './stripe';
import { createAdminClient } from './supabase/admin';

/** Returns the Stripe customer for a user, creating and storing one if needed. */
export async function getOrCreateCustomer(userId: string, email: string | undefined) {
  const admin = createAdminClient();
  const { data: existing } = await admin
    .from('subscriptions')
    .select('stripe_customer_id')
    .eq('user_id', userId)
    .maybeSingle();
  if (existing?.stripe_customer_id) return existing.stripe_customer_id as string;

  const customer = await getStripe().customers.create({ email, metadata: { user_id: userId } });
  await admin
    .from('subscriptions')
    .upsert({ user_id: userId, stripe_customer_id: customer.id, status: 'none', updated_at: new Date().toISOString() });
  return customer.id;
}

/** Mirrors a Stripe subscription into our database. Stripe is the source of truth. */
export async function syncSubscription(sub: Stripe.Subscription) {
  const admin = createAdminClient();
  const customerId = typeof sub.customer === 'string' ? sub.customer : sub.customer.id;

  let userId = sub.metadata?.user_id as string | undefined;
  if (!userId) {
    const { data } = await admin.from('subscriptions').select('user_id').eq('stripe_customer_id', customerId).maybeSingle();
    userId = data?.user_id;
  }
  if (!userId) throw new Error(`No user found for Stripe customer ${customerId}`);

  // `current_period_end` lives on the subscription in older API versions and on items in newer ones.
  const periodEnd =
    (sub as any).current_period_end ?? (sub.items?.data?.[0] as any)?.current_period_end ?? null;

  const row = {
    user_id: userId,
    stripe_customer_id: customerId,
    stripe_subscription_id: sub.id,
    status: sub.status,
    price_id: sub.items.data[0]?.price.id ?? null,
    current_period_end: periodEnd ? new Date(periodEnd * 1000).toISOString() : null,
    cancel_at_period_end: sub.cancel_at_period_end,
    updated_at: new Date().toISOString(),
  };
  const { error } = await admin.from('subscriptions').upsert(row);
  if (error) throw error;
  return { userId, row };
}

export async function userIdForCustomer(customerId: string) {
  const admin = createAdminClient();
  const { data } = await admin.from('subscriptions').select('user_id').eq('stripe_customer_id', customerId).maybeSingle();
  return (data?.user_id as string | undefined) ?? null;
}

export async function emailForUser(userId: string) {
  const admin = createAdminClient();
  const { data } = await admin.auth.admin.getUserById(userId);
  return data.user?.email ?? null;
}
