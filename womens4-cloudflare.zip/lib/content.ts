import { isSupabaseConfigured } from './env';
// Generated at build time by scripts/build-content.mjs (no file system on Cloudflare Workers).
import courseFiles from '@/content/course-data.generated.json';

export type Lesson = {
  slug: string;
  title: string;
  body: string;
  moduleSlug: string;
  index: number;
};

export type Module = {
  slug: string;
  title: string;
  description: string;
  free: boolean;
  number: number;
  stage: string;
  lessons: Lesson[];
  custom?: boolean;
};

let staticCache: Module[] | null = null;

/**
 * Lessons live in content/course/*.md using simple markers:
 *   @@module <slug> | <Title> | <free|premium> | <Stage>
 *   (description lines)
 *   @@lesson <slug> | <Title>
 *   (markdown body)
 */
export function loadStaticModules(): Module[] {
  if (staticCache) return staticCache;
  const files = courseFiles as { name: string; text: string }[];
  const modules: Module[] = [];

  let mod: Module | null = null;
  let lessonSlug = '';
  let lessonTitle = '';
  let lessonLines: string[] = [];
  let descLines: string[] = [];
  let inLesson = false;

  const pushLesson = (m: Module | null) => {
    if (m && inLesson) {
      m.lessons.push({
        slug: lessonSlug,
        title: lessonTitle,
        body: lessonLines.join('\n').trim(),
        moduleSlug: m.slug,
        index: m.lessons.length,
      });
    }
    inLesson = false;
    lessonLines = [];
  };
  const finishDescription = (m: Module | null) => {
    if (m && !m.description) m.description = descLines.join(' ').trim();
    descLines = [];
  };

  for (const { text } of files) {
    for (const line of text.split(/\r?\n/)) {
      if (line.startsWith('@@module ')) {
        pushLesson(mod);
        finishDescription(mod);
        const [slug, title, access, stage] = line.slice(9).split('|').map((s) => s.trim());
        mod = {
          slug,
          title,
          free: access === 'free',
          stage: stage || 'Core',
          description: '',
          number: modules.length + 1,
          lessons: [],
        };
        modules.push(mod);
      } else if (line.startsWith('@@lesson ')) {
        pushLesson(mod);
        finishDescription(mod);
        const [slug, title] = line.slice(9).split('|').map((s) => s.trim());
        lessonSlug = slug;
        lessonTitle = title;
        inLesson = true;
      } else if (inLesson) {
        lessonLines.push(line);
      } else if (mod) {
        descLines.push(line);
      }
    }
    pushLesson(mod);
  }
  finishDescription(mod);
  staticCache = modules;
  return modules;
}

/** Published admin-authored modules from Supabase (empty if not configured). */
async function loadCustomModules(startNumber: number): Promise<Module[]> {
  if (!isSupabaseConfigured()) return [];
  try {
    const { createClient } = await import('@supabase/supabase-js');
    const sb = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
      auth: { persistSession: false },
    });
    const { data: mods } = await sb
      .from('custom_modules')
      .select('id, slug, title, description, position, is_free')
      .order('position');
    if (!mods?.length) return [];
    const { data: lessons } = await sb
      .from('custom_lessons')
      .select('module_id, slug, title, body_md, position')
      .order('position');
    return mods.map((m: any, i: number) => {
      const own = (lessons ?? []).filter((l: any) => l.module_id === m.id);
      return {
        slug: m.slug,
        title: m.title,
        description: m.description,
        free: m.is_free,
        stage: 'New content',
        number: startNumber + i,
        custom: true,
        lessons: own.map((l: any, idx: number) => ({
          slug: l.slug,
          title: l.title,
          body: l.body_md,
          moduleSlug: m.slug,
          index: idx,
        })),
      } satisfies Module;
    });
  } catch {
    return [];
  }
}

export async function getCurriculum(): Promise<Module[]> {
  const base = loadStaticModules();
  const custom = await loadCustomModules(base.length + 1);
  const taken = new Set(base.map((m) => m.slug));
  return [...base, ...custom.filter((m) => !taken.has(m.slug) && m.lessons.length > 0)];
}

export async function getModule(slug: string) {
  return (await getCurriculum()).find((m) => m.slug === slug) ?? null;
}

export const lessonKey = (moduleSlug: string, lessonSlug: string) => `${moduleSlug}/${lessonSlug}`;

export function flattenLessons(modules: Module[]) {
  return modules.flatMap((m) => m.lessons.map((l) => ({ ...l, module: m })));
}

export function stripForPreview(md: string, max = 180) {
  const text = md
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/[#>*_`\[\]()|-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  return text.length > max ? `${text.slice(0, max).trim()}…` : text;
}
