import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';
import { createAdminClient, hasServiceRole } from './supabase/admin';
import { getCourse } from '@/content/courses';
import { SITE_URL } from './env';

export type Certificate = {
  id: string;
  user_id: string;
  course_slug: string;
  recipient_name: string;
  issued_at: string;
  revoked: boolean;
};

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export async function getCertificate(id: string): Promise<Certificate | null> {
  if (!UUID.test(id) || !hasServiceRole()) return null;
  const { data } = await createAdminClient().from('certificates').select('*').eq('id', id).maybeSingle();
  return (data as Certificate) ?? null;
}

export async function renderCertificatePdf(cert: Certificate) {
  const course = getCourse(cert.course_slug);
  const pdf = await PDFDocument.create();
  pdf.setTitle(`womens4.com Certificate – ${cert.recipient_name}`);
  const page = pdf.addPage([842, 595]); // A4 landscape
  const { width, height } = page.getSize();
  const serif = await pdf.embedFont(StandardFonts.TimesRomanBold);
  const sans = await pdf.embedFont(StandardFonts.Helvetica);
  const sansBold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const green = rgb(0.012, 0.596, 0.333);
  const dark = rgb(0.06, 0.09, 0.16);
  const grey = rgb(0.4, 0.44, 0.52);

  page.drawRectangle({ x: 0, y: 0, width, height, color: rgb(1, 1, 1) });
  page.drawRectangle({ x: 24, y: 24, width: width - 48, height: height - 48, borderColor: green, borderWidth: 3 });
  page.drawRectangle({ x: 34, y: 34, width: width - 68, height: height - 68, borderColor: rgb(0.82, 0.98, 0.87), borderWidth: 1 });

  const center = (text: string, y: number, size: number, font = sans, color = dark) => {
    const w = font.widthOfTextAtSize(text, size);
    page.drawText(text, { x: (width - w) / 2, y, size, font, color });
  };

  // Logo mark
  // Logo mark: Venus symbol on a green square, then the wordmark
  const word = 'womens4.com';
  const wordW = sansBold.widthOfTextAtSize(word, 22);
  const markX = (width - (26 + 10 + wordW)) / 2;
  page.drawRectangle({ x: markX, y: 490, width: 26, height: 26, color: green });
  const white = rgb(1, 1, 1);
  page.drawCircle({ x: markX + 13, y: 507, size: 5, borderColor: white, borderWidth: 2 });
  page.drawLine({ start: { x: markX + 13, y: 502 }, end: { x: markX + 13, y: 494 }, thickness: 2, color: white });
  page.drawLine({ start: { x: markX + 9.5, y: 497.5 }, end: { x: markX + 16.5, y: 497.5 }, thickness: 2, color: white });
  page.drawText(word, { x: markX + 36, y: 495, size: 22, font: sansBold, color: dark });

  center('CERTIFICATE OF COMPLETION', 440, 14, sansBold, green);
  center('This certifies that', 395, 13, sans, grey);
  center(cert.recipient_name, 345, 40, serif, dark);
  center('has successfully completed the course', 305, 13, sans, grey);
  center(course?.title ?? cert.course_slug, 265, 26, sansBold, dark);
  if (course) center(`${course.modules.length} modules · ${course.level} level · lessons and graded exercises`, 238, 11, sans, grey);

  const date = new Date(cert.issued_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
  page.drawText('Completion date', { x: 110, y: 140, size: 10, font: sans, color: grey });
  page.drawText(date, { x: 110, y: 120, size: 14, font: sansBold, color: dark });
  page.drawText('Certificate ID', { x: width - 380, y: 140, size: 10, font: sans, color: grey });
  page.drawText(cert.id, { x: width - 380, y: 120, size: 10, font: sansBold, color: dark });
  center(`Verify at ${SITE_URL}/certificates/${cert.id}`, 70, 9, sans, grey);

  return pdf.save();
}
