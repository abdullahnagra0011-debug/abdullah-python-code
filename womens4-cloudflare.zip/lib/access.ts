import type { Module } from './content';

/** Server-side decision: may this viewer open the module's lessons and exercises? */
export function canAccessModule(mod: Module, premium: boolean) {
  return mod.free || premium;
}
