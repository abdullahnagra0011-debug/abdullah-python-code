export type Level = 'Beginner' | 'Intermediate' | 'Advanced';

export type McqQuestion = {
  type: 'mcq';
  level: Level;
  prompt: string;
  options: string[];
  answer: number;
  explain: string;
};

export type FillQuestion = {
  type: 'fill';
  level: Level;
  prompt: string;
  /** Code shown to the learner; `___` marks the blank. */
  code: string;
  /** Accepted answers (compared ignoring surrounding whitespace and quote style). */
  answer: string[];
  explain: string;
};

export type CodeQuestion = {
  type: 'code';
  level: Level;
  prompt: string;
  starter: string;
  /** Python run after the learner's code. `_output` holds captured stdout. Use assert. */
  tests: string;
  explain: string;
  hint?: string;
};

export type Question = McqQuestion | FillQuestion | CodeQuestion;

/** What the browser receives – never contains answers. */
export type PublicQuestion =
  | Omit<McqQuestion, 'answer' | 'explain'>
  | Omit<FillQuestion, 'answer' | 'explain'>
  | Omit<CodeQuestion, 'explain'>;

export function toPublic(q: Question): PublicQuestion {
  if (q.type === 'mcq') {
    const { answer: _a, explain: _e, ...rest } = q;
    return rest;
  }
  if (q.type === 'fill') {
    const { answer: _a, explain: _e, ...rest } = q;
    return rest;
  }
  const { explain: _e, ...rest } = q;
  return rest;
}

const normalize = (s: string) =>
  s
    .trim()
    .replace(/["']/g, '"')
    .replace(/\s+/g, ' ')
    .toLowerCase();

export function gradeAnswer(q: Question, given: unknown): boolean {
  if (q.type === 'mcq') return Number(given) === q.answer;
  if (q.type === 'fill') return typeof given === 'string' && q.answer.some((a) => normalize(a) === normalize(given));
  return given === true; // code challenges are verified in the browser sandbox
}
