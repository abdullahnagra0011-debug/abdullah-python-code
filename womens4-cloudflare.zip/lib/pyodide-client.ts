'use client';

export type RunResult = {
  stdout: string;
  error: string | null;
  passed?: boolean;
  testError?: string;
  timedOut?: boolean;
};

type Pending = (r: RunResult) => void;

let worker: Worker | null = null;
let readyPromise: Promise<void> | null = null;
let seq = 0;
const pending = new Map<number, Pending>();
const listeners = new Set<(s: 'loading' | 'ready' | 'error') => void>();
let status: 'idle' | 'loading' | 'ready' | 'error' = 'idle';

const TIMEOUT_MS = 10_000;

function setStatus(s: 'loading' | 'ready' | 'error') {
  status = s;
  listeners.forEach((l) => l(s));
}

export function onPythonStatus(fn: (s: 'loading' | 'ready' | 'error') => void) {
  listeners.add(fn);
  if (status !== 'idle') fn(status as any);
  return () => {
    listeners.delete(fn);
  };
}

function boot() {
  if (worker && readyPromise) return readyPromise;
  setStatus('loading');
  worker = new Worker('/pyodide-worker.js');
  readyPromise = new Promise<void>((resolve, reject) => {
    worker!.onmessage = (e: MessageEvent) => {
      const { id, ...rest } = e.data;
      if (id === 'ready') {
        setStatus('ready');
        resolve();
        return;
      }
      if (id === 'load-error') {
        setStatus('error');
        reject(new Error(rest.error));
        return;
      }
      const p = pending.get(id);
      if (p) {
        pending.delete(id);
        p(rest as RunResult);
      }
    };
  });
  return readyPromise;
}

/** Warm up Python in the background (e.g. when an editor scrolls into view). */
export function preloadPython() {
  if (typeof window !== 'undefined') boot().catch(() => {});
}

export async function runPython(code: string, opts: { stdin?: string; tests?: string } = {}): Promise<RunResult> {
  try {
    await boot();
  } catch (e) {
    return { stdout: '', error: `Could not load Python in your browser: ${(e as Error).message}` };
  }
  const w = worker!;
  const id = ++seq;
  return new Promise<RunResult>((resolve) => {
    const timer = setTimeout(() => {
      pending.delete(id);
      w.terminate();
      worker = null;
      readyPromise = null;
      status = 'idle';
      resolve({
        stdout: '',
        error: `Stopped after ${TIMEOUT_MS / 1000} seconds. Does your code have an infinite loop?`,
        timedOut: true,
      });
    }, TIMEOUT_MS);
    pending.set(id, (r) => {
      clearTimeout(timer);
      resolve(r);
    });
    w.postMessage({ id, code, stdin: opts.stdin ?? '', tests: opts.tests ?? '' });
  });
}
