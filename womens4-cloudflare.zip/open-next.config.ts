import { defineCloudflareConfig } from '@opennextjs/cloudflare';

// Default config. Pages are rendered per request (user-specific), so no
// incremental cache binding is needed.
export default defineCloudflareConfig();
