-- ════════════════════════════════════════════════════════════════════
-- womens4.com database schema – run once in Supabase → SQL Editor
-- Every table has Row Level Security enabled. Writes that must not be
-- forgeable by a user (subscriptions, payments, exercise scores,
-- certificates) are performed only by the server with the service-role key.
-- ════════════════════════════════════════════════════════════════════

create extension if not exists "pgcrypto";

-- ─── Profiles ──────────────────────────────────────────────────────
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  email text,
  full_name text,
  role text not null default 'student' check (role in ('student', 'admin')),
  marketing_consent boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.profiles enable row level security;

drop policy if exists "profiles: read own" on public.profiles;
create policy "profiles: read own" on public.profiles
  for select using (auth.uid() = id);

drop policy if exists "profiles: update own" on public.profiles;
create policy "profiles: update own" on public.profiles
  for update using (auth.uid() = id) with check (auth.uid() = id);

-- Users may only change these columns (never `role`).
revoke update on public.profiles from authenticated, anon;
grant update (full_name, marketing_consent, updated_at) on public.profiles to authenticated;

-- Create a profile automatically on sign-up.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data ->> 'full_name', ''));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ─── Subscriptions (written only by the Stripe webhook) ──────────
create table if not exists public.subscriptions (
  user_id uuid primary key references auth.users (id) on delete cascade,
  stripe_customer_id text unique,
  stripe_subscription_id text unique,
  status text not null default 'none',          -- active | trialing | past_due | canceled | incomplete | unpaid | none
  price_id text,
  current_period_end timestamptz,
  cancel_at_period_end boolean not null default false,
  updated_at timestamptz not null default now()
);
alter table public.subscriptions enable row level security;
drop policy if exists "subscriptions: read own" on public.subscriptions;
create policy "subscriptions: read own" on public.subscriptions
  for select using (auth.uid() = user_id);

-- ─── Payment history (Stripe invoices) ───────────────────────────
create table if not exists public.payments (
  id text primary key,                            -- Stripe invoice id
  user_id uuid not null references auth.users (id) on delete cascade,
  amount integer not null,                        -- in cents
  currency text not null default 'eur',
  status text not null,                           -- paid | failed
  invoice_url text,
  created_at timestamptz not null default now()
);
create index if not exists payments_user_idx on public.payments (user_id, created_at desc);
alter table public.payments enable row level security;
drop policy if exists "payments: read own" on public.payments;
create policy "payments: read own" on public.payments
  for select using (auth.uid() = user_id);

-- ─── Lesson progress ─────────────────────────────────────────────
create table if not exists public.lesson_progress (
  user_id uuid not null references auth.users (id) on delete cascade,
  lesson_key text not null,                       -- "<module-slug>/<lesson-slug>"
  completed_at timestamptz not null default now(),
  primary key (user_id, lesson_key)
);
alter table public.lesson_progress enable row level security;
drop policy if exists "progress: read own" on public.lesson_progress;
create policy "progress: read own" on public.lesson_progress
  for select using (auth.uid() = user_id);
drop policy if exists "progress: insert own" on public.lesson_progress;
create policy "progress: insert own" on public.lesson_progress
  for insert with check (auth.uid() = user_id);
drop policy if exists "progress: delete own" on public.lesson_progress;
create policy "progress: delete own" on public.lesson_progress
  for delete using (auth.uid() = user_id);

-- ─── Exercise / quiz results (graded on the server) ──────────────
create table if not exists public.exercise_results (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  module_slug text not null,
  score integer not null,
  total integer not null,
  created_at timestamptz not null default now()
);
create index if not exists exercise_results_user_idx on public.exercise_results (user_id, module_slug);
alter table public.exercise_results enable row level security;
drop policy if exists "results: read own" on public.exercise_results;
create policy "results: read own" on public.exercise_results
  for select using (auth.uid() = user_id);

-- ─── Certificates (issued by the server after criteria check) ────
create table if not exists public.certificates (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users (id) on delete cascade,
  course_slug text not null,
  recipient_name text not null,
  issued_at timestamptz not null default now(),
  revoked boolean not null default false,
  unique (user_id, course_slug)
);
alter table public.certificates enable row level security;
drop policy if exists "certificates: read own" on public.certificates;
create policy "certificates: read own" on public.certificates
  for select using (auth.uid() = user_id);

-- ─── Admin-authored content (merged with the built-in curriculum) ─
create table if not exists public.custom_modules (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  title text not null,
  description text not null default '',
  position integer not null default 100,
  is_free boolean not null default false,
  published boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.custom_modules enable row level security;
drop policy if exists "custom_modules: read published" on public.custom_modules;
create policy "custom_modules: read published" on public.custom_modules
  for select using (published);

create table if not exists public.custom_lessons (
  id uuid primary key default gen_random_uuid(),
  module_id uuid not null references public.custom_modules (id) on delete cascade,
  slug text not null,
  title text not null,
  body_md text not null default '',
  position integer not null default 0,
  published boolean not null default false,
  created_at timestamptz not null default now(),
  unique (module_id, slug)
);
alter table public.custom_lessons enable row level security;
drop policy if exists "custom_lessons: read published" on public.custom_lessons;
create policy "custom_lessons: read published" on public.custom_lessons
  for select using (
    published and exists (select 1 from public.custom_modules m where m.id = module_id and m.published)
  );

-- Questions contain answers, so there is no public read policy:
-- the server reads them with the service role and strips answers.
create table if not exists public.custom_questions (
  id uuid primary key default gen_random_uuid(),
  module_id uuid not null references public.custom_modules (id) on delete cascade,
  position integer not null default 0,
  data jsonb not null,
  created_at timestamptz not null default now()
);
alter table public.custom_questions enable row level security;

-- ─── Make yourself admin (replace the email, then run) ───────────
-- update public.profiles set role = 'admin' where email = 'you@example.com';
