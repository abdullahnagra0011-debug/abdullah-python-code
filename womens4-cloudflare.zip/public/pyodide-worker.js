/* Runs learner code with Pyodide inside a Web Worker – entirely in the browser.
   Nothing is executed on the server. The page terminates this worker on timeout. */
importScripts('https://cdn.jsdelivr.net/pyodide/v0.26.4/full/pyodide.js');

let pyodide = null;
const ready = (async () => {
  pyodide = await loadPyodide();
  self.postMessage({ id: 'ready' });
})().catch((err) => self.postMessage({ id: 'load-error', error: String(err) }));

const decoder = new TextDecoder();

self.onmessage = async (event) => {
  const { id, code, stdin = '', tests = '' } = event.data;
  await ready;
  if (!pyodide) return self.postMessage({ id, stdout: '', error: 'Python failed to load. Check your connection and reload.' });

  let out = '';
  pyodide.setStdout({ write: (buf) => { out += decoder.decode(buf); return buf.length; } });
  pyodide.setStderr({ write: (buf) => { out += decoder.decode(buf); return buf.length; } });
  const lines = stdin.length ? stdin.split('\n') : [];
  let i = 0;
  pyodide.setStdin({ stdin: () => (i < lines.length ? lines[i++] : undefined) });

  const globals = pyodide.toPy({});
  const clean = (msg) => {
    // Hide Pyodide's internal frames, keep the learner's part of the traceback.
    const s = String(msg);
    const idx = s.indexOf('File "<exec>"');
    return idx >= 0 ? 'Traceback (most recent call last):\n  ' + s.slice(idx) : s;
  };

  try {
    await pyodide.loadPackagesFromImports(code);
    await pyodide.runPythonAsync(code, { globals });
  } catch (err) {
    globals.destroy();
    return self.postMessage({ id, stdout: out, error: clean(err.message || err) });
  }

  if (!tests) {
    globals.destroy();
    return self.postMessage({ id, stdout: out, error: null });
  }

  const userOutput = out;
  try {
    globals.set('_output', userOutput);
    await pyodide.runPythonAsync(tests, { globals });
    self.postMessage({ id, stdout: userOutput, error: null, passed: true });
  } catch (err) {
    const m = String(err.message || err).trim().split('\n').pop();
    self.postMessage({ id, stdout: userOutput, error: null, passed: false, testError: m.replace(/^AssertionError:?\s*/, '') || 'A test failed.' });
  } finally {
    globals.destroy();
  }
};
