// Creates the "womens4.com Premium" product with a €6.99 monthly recurring price.
// Usage:  STRIPE_SECRET_KEY=sk_test_... node scripts/create-stripe-price.mjs
import Stripe from 'stripe';

const key = process.env.STRIPE_SECRET_KEY;
if (!key) {
  console.error('Set STRIPE_SECRET_KEY first.');
  process.exit(1);
}
const stripe = new Stripe(key);

const product = await stripe.products.create({
  name: 'womens4.com Premium',
  description: 'Full access to every womens4.com Python course, exercise, project and certificate.',
});
const price = await stripe.prices.create({
  product: product.id,
  currency: 'eur',
  unit_amount: 699,
  recurring: { interval: 'month' },
  tax_behavior: 'inclusive',
});
console.log('\nCreated product:', product.id);
console.log('Created price:  ', price.id);
console.log(`\nAdd this to your environment:\nSTRIPE_PRICE_ID=${price.id}\n`);
