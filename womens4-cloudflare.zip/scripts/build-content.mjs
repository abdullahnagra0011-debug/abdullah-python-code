// Bundles content/course/*.md into content/course-data.generated.json.
// Cloudflare Workers have no file system at runtime, so lessons are
// compiled into the app at build time. Runs automatically before
// `npm run dev`, `npm run build`, `npm run preview` and `npm run deploy`.
import fs from 'node:fs';
import path from 'node:path';

const dir = path.join(process.cwd(), 'content', 'course');
const files = fs
  .readdirSync(dir)
  .filter((f) => f.endsWith('.md'))
  .sort()
  .map((name) => ({ name, text: fs.readFileSync(path.join(dir, name), 'utf8') }));

const out = path.join(process.cwd(), 'content', 'course-data.generated.json');
fs.writeFileSync(out, JSON.stringify(files));
console.log(`Bundled ${files.length} course files into ${path.relative(process.cwd(), out)}`);
