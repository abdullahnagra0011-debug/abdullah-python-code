export type Course = {
  slug: string;
  title: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  description: string;
  hours: number;
  modules: string[];
};

export const FUNDAMENTALS = [
  'introduction',
  'setup',
  'syntax',
  'variables-data-types',
  'numbers-strings',
  'operators',
  'conditionals',
  'loops',
  'lists-tuples',
  'dictionaries-sets',
  'functions',
];

export const INTERMEDIATE = [
  'oop',
  'modules-packages',
  'file-handling',
  'error-handling',
  'libraries',
  'apis',
  'databases',
  'projects',
  'advanced',
];

export const PROFESSIONAL = ['git-github', 'testing', 'web-development', 'data-analysis', 'career'];

export const COURSES: Course[] = [
  {
    slug: 'python-fundamentals',
    title: 'Python Fundamentals',
    level: 'Beginner',
    description:
      'Start from absolute zero: install Python, write your first program and master variables, strings, loops, collections and functions.',
    hours: 30,
    modules: FUNDAMENTALS,
  },
  {
    slug: 'intermediate-python',
    title: 'Intermediate & Advanced Python',
    level: 'Intermediate',
    description:
      'Think like a developer: classes, modules, files, errors, libraries, APIs, SQL databases, real projects and advanced language features.',
    hours: 40,
    modules: INTERMEDIATE,
  },
  {
    slug: 'job-ready-python-developer',
    title: 'Job-Ready Python Developer',
    level: 'Advanced',
    description:
      'The complete path: everything above plus Git, testing, web APIs with Flask & FastAPI, data analysis with pandas, a portfolio and interview prep.',
    hours: 100,
    modules: [...FUNDAMENTALS, ...INTERMEDIATE, ...PROFESSIONAL],
  },
];

export const getCourse = (slug: string) => COURSES.find((c) => c.slug === slug) ?? null;

/** Minimum share of correct answers in each module's exercises to earn a certificate. */
export const PASS_RATE = 0.7;
