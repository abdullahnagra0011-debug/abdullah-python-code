@@module git-github | Git and GitHub | premium | Professional
Version-control your code like a professional: commits, branches, merges, GitHub, pull requests and collaboration.

@@lesson git-basics | Why Git and First Commits
**Git** records the history of your code. You can go back in time, try ideas safely and work with others. Every development job uses it.

```bash
git --version                 # check it's installed
git config --global user.name "Your Name"
git config --global user.email "you@example.com"

mkdir my-project && cd my-project
git init                      # start tracking this folder
echo "print('hi')" > app.py
git status                    # what changed?
git add app.py                # stage the change
git commit -m "Add hello script"
git log --oneline             # history
```

The workflow is always: **edit → `git add` → `git commit`**.

> Write commit messages in the imperative: "Add login form", "Fix rounding bug".

@@lesson branches | Branches and Merging
A **branch** is a separate line of work. Keep `main` stable and build features on branches.

```bash
git switch -c feature/discounts     # create and switch to a branch
# ... edit files ...
git add .
git commit -m "Add discount codes"
git switch main
git merge feature/discounts
git branch -d feature/discounts
```

## Merge conflicts

If two branches change the same lines, Git asks you to choose:

```text
<<<<<<< HEAD
price = 10
=======
price = 12
>>>>>>> feature/discounts
```

Edit the file to the correct version, remove the markers, then `git add` and `git commit`.

@@lesson github | GitHub and Remote Repositories
**GitHub** hosts Git repositories online – it's your public portfolio as a developer.

```bash
git remote add origin https://github.com/<you>/my-project.git
git push -u origin main      # upload
git pull                     # download others' changes
git clone https://github.com/<user>/<repo>.git
```

## .gitignore

List files that must never be committed:

```text
.venv/
__pycache__/
.env
*.sqlite3
```

> **Never** commit passwords or API keys. If you do, revoke the key immediately – deleting the commit is not enough.

@@lesson pull-requests | Pull Requests and Collaboration
In teams, changes go through a **pull request (PR)**:

1. Create a branch and push it: `git push -u origin feature/x`.
2. Open a PR on GitHub describing **what** and **why**.
3. Teammates review the code and automated tests run.
4. Fix feedback with new commits, then merge.

## Good PR habits

- Keep PRs small and focused on one change.
- Add screenshots for UI changes.
- Link the issue it solves ("Closes #42").
- Respond to review comments politely – reviews are about code, not people.

Contributing a small fix to an open-source project is an excellent way to show employers you can collaborate.

@@module testing | Testing and Code Quality | premium | Professional
Prove your code works with automated tests using assert and pytest, and keep it clean with PEP 8, linters and formatters.

@@lesson why-testing | Why Automated Tests?
A test is code that checks other code. Tests let you change things confidently because they warn you instantly when something breaks.

```python
def is_palindrome(text: str) -> bool:
    cleaned = "".join(c.lower() for c in text if c.isalnum())
    return cleaned == cleaned[::-1]

# simple tests with assert
assert is_palindrome("racecar")
assert is_palindrome("A man, a plan, a canal: Panama")
assert not is_palindrome("python")
print("All tests passed!")
```

`assert condition` does nothing if the condition is True and raises `AssertionError` otherwise.

@@lesson pytest | Testing with pytest
**pytest** is the industry-standard test runner.

```bash
pip install pytest
```

`calculator.py`:

```python-norun
def divide(a, b):
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b
```

`test_calculator.py`:

```python-norun
import pytest
from calculator import divide

def test_divide():
    assert divide(10, 2) == 5

def test_divide_by_zero():
    with pytest.raises(ValueError):
        divide(1, 0)

@pytest.mark.parametrize("a, b, expected", [(9, 3, 3), (1, 4, 0.25), (-6, 2, -3)])
def test_divide_many(a, b, expected):
    assert divide(a, b) == expected
```

```bash
pytest -v
```

pytest finds files named `test_*.py` and functions named `test_*` automatically.

@@lesson tdd-mocking | Fixtures, Mocks and TDD
## Fixtures – reusable test setup

```python-norun
import pytest

@pytest.fixture
def cart():
    return {"apple": 2, "bread": 1}

def test_cart_has_items(cart):
    assert sum(cart.values()) == 3
```

## Mocking – replace slow or external things

```python-norun
from unittest.mock import patch
import weather

def test_forecast_uses_api():
    with patch("weather.requests.get") as fake_get:
        fake_get.return_value.json.return_value = {"temp": 20}
        assert weather.current_temp("Milan") == 20
```

## Test-Driven Development (TDD)

1. **Red:** write a failing test for the behaviour you want.
2. **Green:** write the simplest code that passes.
3. **Refactor:** clean up while tests stay green.

@@lesson code-quality | PEP 8, Linters and Formatters
**PEP 8** is Python's official style guide. Consistent style makes code easier for teams to read.

| Rule | Example |
|---|---|
| 4 spaces per indent | not tabs |
| `snake_case` names | `total_price`, `get_user()` |
| `PascalCase` classes | `class ShoppingCart:` |
| `UPPER_CASE` constants | `MAX_RETRIES = 3` |
| Lines ≤ 88–99 chars | split long expressions |

## Tools that do it for you

```bash
pip install ruff
ruff check .        # find bugs and style issues
ruff format .       # auto-format the code
```

Professional projects run these tools automatically before every commit (with `pre-commit`) and in CI pipelines such as GitHub Actions.

@@module web-development | Web Development with Python | premium | Professional
Build web applications and REST APIs with Flask and FastAPI, use templates, validate data and deploy to the cloud.

@@lesson how-web-works | How the Web Works
When you open a website:

1. The **browser** (client) sends an HTTP request to a **server**.
2. Server code (Python!) runs, maybe reads a database.
3. The server returns a **response**: HTML for pages or JSON for APIs.

## Python web frameworks

| Framework | Best for |
|---|---|
| **Flask** | Small to medium apps; simple and flexible |
| **FastAPI** | Modern, fast JSON APIs with automatic docs and validation |
| **Django** | Large apps with batteries included: ORM, admin, auth |

Backend developer job ads usually ask for at least one of these – learning FastAPI or Django deeply is a strong choice.

@@lesson flask | Your First Flask App
```bash
pip install flask
```

`app.py`:

```python-norun
from flask import Flask, jsonify, request, render_template_string

app = Flask(__name__)
tasks = [{"id": 1, "title": "Learn Flask", "done": False}]

@app.get("/")
def home():
    return render_template_string(
        "<h1>Tasks</h1><ul>{% for t in tasks %}<li>{{ t.title }}</li>{% endfor %}</ul>",
        tasks=tasks,
    )

@app.get("/api/tasks")
def list_tasks():
    return jsonify(tasks)

@app.post("/api/tasks")
def create_task():
    data = request.get_json()
    task = {"id": len(tasks) + 1, "title": data["title"], "done": False}
    tasks.append(task)
    return jsonify(task), 201

if __name__ == "__main__":
    app.run(debug=True)
```

Run `python app.py` and open `http://127.0.0.1:5000`. In real apps you'd use template files in a `templates/` folder and a database instead of a list.

@@lesson fastapi | REST APIs with FastAPI
```bash
pip install "fastapi[standard]"
```

`main.py`:

```python-norun
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="Books API")

class BookIn(BaseModel):
    title: str = Field(min_length=1)
    author: str
    year: int = Field(ge=1450, le=2100)

class Book(BookIn):
    id: int

books: dict[int, Book] = {}

@app.get("/books")
def list_books() -> list[Book]:
    return list(books.values())

@app.post("/books", status_code=201)
def create_book(data: BookIn) -> Book:
    book = Book(id=len(books) + 1, **data.model_dump())
    books[book.id] = book
    return book

@app.get("/books/{book_id}")
def get_book(book_id: int) -> Book:
    if book_id not in books:
        raise HTTPException(status_code=404, detail="Book not found")
    return books[book_id]
```

```bash
fastapi dev main.py
```

Open `http://127.0.0.1:8000/docs` – FastAPI generates interactive documentation from your type hints. Invalid data (e.g. `year: "abc"`) is rejected automatically with a clear 422 error.

@@lesson deployment | Deploying Your App
Deployment puts your app on the internet. A typical path:

1. Pin dependencies in `requirements.txt`.
2. Read secrets and settings from **environment variables**.
3. Use a production server: `gunicorn app:app` (Flask) or `uvicorn main:app --host 0.0.0.0` (FastAPI).
4. Deploy to a platform such as **Render**, **Railway**, **Fly.io** or a cloud provider.

## Docker in 30 seconds

A `Dockerfile` packages your app and its dependencies so it runs the same everywhere:

```text
FROM python:3.13-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

A deployed project with a live link on your CV is worth far more to employers than code that only runs on your laptop.

@@module data-analysis | Data Analysis with pandas | premium | Professional
Load, clean, analyse and visualise data with pandas and Matplotlib – the core toolkit for data analyst and data-heavy developer roles.

@@lesson pandas-intro | pandas DataFrames
**pandas** gives you the `DataFrame`: a table with rows and columns, like a spreadsheet you control with code.

```python
import pandas as pd

df = pd.DataFrame({
    "name": ["Ada", "Linus", "Grace", "Alan", "Guido"],
    "country": ["UK", "FI", "US", "UK", "NL"],
    "score": [95, 82, 99, 74, 88],
    "hours": [40, 25, 42, 18, 30],
})
print(df.head())
print(df.shape)
print(df.describe())
```

(First run downloads pandas into your browser – give it a few seconds.)

In real projects you load data with `pd.read_csv("file.csv")`, `pd.read_excel(...)` or `pd.read_sql(...)`.

@@lesson selecting-filtering | Selecting and Filtering
```python
import pandas as pd
df = pd.DataFrame({
    "name": ["Ada", "Linus", "Grace", "Alan", "Guido"],
    "country": ["UK", "FI", "US", "UK", "NL"],
    "score": [95, 82, 99, 74, 88],
    "hours": [40, 25, 42, 18, 30],
})

print(df["score"].mean())
print(df[["name", "score"]])
print(df[df["score"] > 85])
print(df[(df["country"] == "UK") & (df["hours"] > 20)])
print(df.sort_values("score", ascending=False).head(3))
df["points_per_hour"] = (df["score"] / df["hours"]).round(2)
print(df)
```

@@lesson cleaning-grouping | Cleaning and Grouping Data
Real data is messy. Cleaning is often 80% of the work.

```python
import pandas as pd
import numpy as np

sales = pd.DataFrame({
    "region": ["North", "south", "North", "East", None, "South"],
    "product": ["A", "B", "A", "C", "B", "A"],
    "amount": [120, 80, np.nan, 200, 50, 95],
})
print(sales.isna().sum())

sales = sales.dropna(subset=["region"])
sales["region"] = sales["region"].str.title()
sales["amount"] = sales["amount"].fillna(sales["amount"].median())

summary = sales.groupby("region")["amount"].agg(["count", "sum", "mean"]).round(1)
print(summary)
print(sales.pivot_table(index="region", columns="product", values="amount", aggfunc="sum", fill_value=0))
```

@@lesson visualisation | Visualising Data with Matplotlib
```python-norun
import pandas as pd
import matplotlib.pyplot as plt

monthly = pd.DataFrame({
    "month": ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
    "revenue": [12.1, 13.4, 12.8, 15.2, 16.9, 18.3],
})

fig, ax = plt.subplots(figsize=(8, 4))
ax.plot(monthly["month"], monthly["revenue"], marker="o", color="#039855")
ax.set_title("Monthly revenue (k€)")
ax.set_ylabel("k€")
ax.grid(alpha=0.3)
fig.tight_layout()
fig.savefig("revenue.png", dpi=150)
plt.show()
```

## Choosing a chart

| Question | Chart |
|---|---|
| How does it change over time? | Line |
| How do categories compare? | Bar |
| How are two numbers related? | Scatter |
| How are values distributed? | Histogram |

A data analysis project for your portfolio: download a public dataset (e.g. from Kaggle or your city's open-data portal), clean it, answer three questions and publish the notebook on GitHub.

@@module career | Getting Hired as a Python Developer | premium | Professional
Turn your skills into a job: choose a path, build a portfolio, write a strong CV, prepare for technical interviews and apply effectively.

@@lesson career-paths | Python Career Paths
Python opens several doors. Pick one direction to focus your projects:

| Role | Key skills beyond core Python |
|---|---|
| Backend developer | FastAPI/Django, SQL, REST, Git, Docker, testing |
| Data analyst | pandas, SQL, visualisation, statistics, Excel |
| Automation / QA engineer | pytest, Selenium/Playwright, CI, scripting |
| Data engineer | SQL, pipelines, cloud, Airflow |
| ML engineer (later step) | NumPy, scikit-learn, PyTorch, maths |

## What "job-ready" means for a junior

- You can build a small app end to end without a tutorial.
- You read errors and documentation to solve problems yourself.
- You use Git, write basic tests and understand SQL.
- You can explain your code and decisions clearly.

@@lesson portfolio | Building Your Portfolio
Employers hire based on **evidence**. Aim for **3–4 polished projects** rather than 20 half-finished ones.

A strong junior portfolio:

1. **A REST API** (FastAPI/Flask) with a database, authentication and tests – deployed with a live URL.
2. **An automation tool** that solves a real problem (e.g. a report generator).
3. **A data project** that answers questions with a real dataset.
4. **Your choice** – something you're genuinely interested in.

## Every project needs

- A clear **README**: what it does, screenshot/GIF, how to run it, tech used.
- Clean commit history and code formatted with ruff.
- Tests and a GitHub Actions workflow that runs them.

Pin your best repositories on your GitHub profile and add a short profile README introducing yourself.

@@lesson cv-linkedin | CV, LinkedIn and Applications
## Your CV (1 page)

- **Headline:** "Junior Python Developer – FastAPI, SQL, pandas".
- **Projects first** if you have no developer experience: 2–3 bullet points each with results ("Built an API serving 10k requests/day").
- **Skills:** group them (Languages, Frameworks, Tools) and only list what you can discuss.
- Link to GitHub, LinkedIn and your womens4.com certificates.

## LinkedIn

Use the same headline, add projects to "Featured", add certificates, and post short updates about what you build.

## Applying

- Tailor your CV to each job's keywords.
- Apply consistently: e.g. 5–10 quality applications per week.
- Referrals work best – join local Python meetups and online communities.
- Track applications in a spreadsheet and follow up after a week.

@@lesson interviews | Technical Interview Preparation
Most junior Python interviews include some of these stages:

1. **Screening call** – motivation and background.
2. **Coding exercise** – small problems with lists, strings, dictionaries.
3. **Take-home or live project** – e.g. build a small API.
4. **Technical discussion** – your projects and core concepts.

## Common questions to practise

- Difference between a list and a tuple? Between `==` and `is`?
- What are `*args` and `**kwargs`? A decorator? A generator?
- How does a dictionary lookup work, and why is it fast?
- How do you prevent SQL injection?
- What happens when you type a URL in the browser?

## Solving a coding problem out loud

```python
# "Return the first non-repeating character in a string."
from collections import Counter

def first_unique(s: str):
    counts = Counter(s)          # O(n)
    for ch in s:                 # O(n)
        if counts[ch] == 1:
            return ch
    return None

print(first_unique("swiss"))     # w
print(first_unique("aabb"))      # None
```

Clarify the question, talk through your approach, write the code, then test with edge cases (empty string, all repeating). Practise on platforms like LeetCode (easy level), Exercism or Codewars.

> **You've reached the end of the path.** Keep building, keep applying – and congratulations on getting this far!
