@@module oop | Object-Oriented Programming | premium | Intermediate
Model real-world things with classes and objects: attributes, methods, inheritance, encapsulation, special methods and dataclasses.

@@lesson classes-objects | Classes and Objects
A **class** is a blueprint. An **object** (instance) is a thing built from that blueprint.

```python
class Dog:
    def __init__(self, name, age):
        self.name = name      # attribute
        self.age = age

    def bark(self):           # method
        return f"{self.name} says woof!"

rex = Dog("Rex", 3)
luna = Dog("Luna", 5)
print(rex.bark())
print(luna.name, luna.age)
```

- `__init__` runs when you create an object and sets up its attributes.
- `self` refers to the specific object the method is working on.

@@lesson methods-attributes | Methods and Class Attributes
```python
class BankAccount:
    bank_name = "PyBank"          # class attribute, shared by all accounts

    def __init__(self, owner, balance=0):
        self.owner = owner        # instance attributes
        self.balance = balance

    def deposit(self, amount):
        if amount <= 0:
            raise ValueError("Amount must be positive")
        self.balance += amount
        return self.balance

    def withdraw(self, amount):
        if amount > self.balance:
            return "Insufficient funds"
        self.balance -= amount
        return self.balance

acct = BankAccount("Ada", 100)
acct.deposit(50)
print(acct.withdraw(30))
print(acct.withdraw(500))
print(acct.bank_name)
```

Objects bundle **data** (attributes) with the **behaviour** (methods) that works on that data.

@@lesson inheritance | Inheritance and Polymorphism
**Inheritance** lets a class reuse and extend another class.

```python
class Animal:
    def __init__(self, name):
        self.name = name

    def speak(self):
        return "..."

    def introduce(self):
        return f"I am {self.name} and I say {self.speak()}"

class Cat(Animal):
    def speak(self):
        return "meow"

class Cow(Animal):
    def speak(self):
        return "moo"

for animal in [Cat("Tom"), Cow("Bella")]:
    print(animal.introduce())
```

The same method call (`speak()`) behaves differently per class – that's **polymorphism**.

## super()

```python
class Employee:
    def __init__(self, name, salary):
        self.name, self.salary = name, salary

class Manager(Employee):
    def __init__(self, name, salary, team):
        super().__init__(name, salary)   # reuse parent setup
        self.team = team

m = Manager("Grace", 90000, ["Ada", "Linus"])
print(m.name, len(m.team))
```

@@lesson encapsulation-properties | Encapsulation and Properties
By convention, attributes starting with `_` are "internal – don't touch from outside". **Properties** let you control access with normal attribute syntax.

```python
class Temperature:
    def __init__(self, celsius):
        self._celsius = celsius

    @property
    def celsius(self):
        return self._celsius

    @celsius.setter
    def celsius(self, value):
        if value < -273.15:
            raise ValueError("Below absolute zero!")
        self._celsius = value

    @property
    def fahrenheit(self):
        return self._celsius * 9 / 5 + 32

t = Temperature(25)
print(t.fahrenheit)
t.celsius = 30
print(t.celsius, t.fahrenheit)
```

@@lesson dunder-dataclasses | Special Methods and Dataclasses
Special ("dunder") methods let your objects work with Python's built-in syntax.

```python
class Vector:
    def __init__(self, x, y):
        self.x, self.y = x, y
    def __repr__(self):
        return f"Vector({self.x}, {self.y})"
    def __add__(self, other):
        return Vector(self.x + other.x, self.y + other.y)
    def __eq__(self, other):
        return (self.x, self.y) == (other.x, other.y)

print(Vector(1, 2) + Vector(3, 4))
print(Vector(1, 1) == Vector(1, 1))
```

## Dataclasses

For classes that mainly hold data, `@dataclass` writes `__init__`, `__repr__` and `__eq__` for you:

```python
from dataclasses import dataclass, field

@dataclass
class Product:
    name: str
    price: float
    tags: list = field(default_factory=list)

    def with_vat(self, rate=0.22):
        return round(self.price * (1 + rate), 2)

p = Product("Keyboard", 49.9, ["hardware"])
print(p)
print(p.with_vat())
```

@@module modules-packages | Modules and Packages | premium | Intermediate
Organise code into modules and packages, use the standard library, install packages with pip and isolate projects with virtual environments.

@@lesson importing | Importing Modules
A **module** is a `.py` file with code you can reuse. Python ships with a huge **standard library**.

```python
import math
import random
from datetime import date
import statistics as stats

print(math.factorial(5))
print(random.randint(1, 6))
print(date.today().year)
print(stats.median([3, 1, 4, 1, 5]))
```

## Import styles

| Style | Use |
|---|---|
| `import math` | Clear where names come from: `math.sqrt` |
| `from math import sqrt` | Shorter, import specific names |
| `import pandas as pd` | Alias for long names |
| `from math import *` | Avoid – hides where names come from |

@@lesson own-modules | Creating Your Own Modules and Packages
Any `.py` file is a module. Suppose your project looks like this:

```text
shop/
├── main.py
└── utils/
    ├── __init__.py
    └── pricing.py
```

`utils/pricing.py`:

```python-norun
VAT = 0.22

def with_vat(price):
    return round(price * (1 + VAT), 2)
```

`main.py`:

```python-norun
from utils.pricing import with_vat

print(with_vat(10))
```

A folder with an `__init__.py` file is a **package**.

## The `__name__` guard

```python-norun
def main():
    print("Running as a script")

if __name__ == "__main__":
    main()
```

Code under this guard runs when the file is executed directly, but not when it's imported. You'll see it in almost every professional Python script.

@@lesson pip-venv | pip and Virtual Environments
**pip** installs third-party packages from PyPI (the Python Package Index). A **virtual environment** keeps each project's packages separate.

```bash
# create and activate a virtual environment
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS / Linux
source .venv/bin/activate

# install packages
pip install requests pandas

# save exact versions for others
pip freeze > requirements.txt
# reinstall on another machine
pip install -r requirements.txt
```

> **Rule of thumb:** create a new virtual environment for every project, and never commit the `.venv` folder to Git.

Modern alternatives like **uv** and **Poetry** do the same job faster with extra features – worth learning once you're comfortable.

@@lesson standard-library | Tour of the Standard Library
"Batteries included" – these modules solve common problems without installing anything:

```python
from collections import Counter, defaultdict
from datetime import datetime, timedelta
import json, os, random, itertools

words = "to be or not to be".split()
print(Counter(words).most_common(2))

groups = defaultdict(list)
for name in ["Ada", "Alan", "Bob"]:
    groups[name[0]].append(name)
print(dict(groups))

deadline = datetime(2026, 12, 31) - timedelta(days=7)
print(deadline.strftime("%d %B %Y"))

print(json.dumps({"ok": True, "items": [1, 2]}))
print(list(itertools.combinations("ABC", 2)))
print(random.choice(["rock", "paper", "scissors"]))
```

| Module | For |
|---|---|
| `os`, `pathlib`, `shutil` | Files and folders |
| `datetime`, `time` | Dates and times |
| `json`, `csv` | Data formats |
| `re` | Regular expressions |
| `logging` | Application logs |
| `argparse` | Command-line tools |

@@module file-handling | File Handling | premium | Intermediate
Read and write text files, work with CSV and JSON, and manage paths with pathlib.

@@lesson reading-writing | Reading and Writing Files
Always open files with `with` – it closes the file automatically, even if an error happens.

```python
# write (creates or overwrites the file)
with open("notes.txt", "w", encoding="utf-8") as f:
    f.write("First line\n")
    f.write("Second line\n")

# append
with open("notes.txt", "a", encoding="utf-8") as f:
    f.write("Added later\n")

# read everything
with open("notes.txt", encoding="utf-8") as f:
    print(f.read())
```

| Mode | Meaning |
|---|---|
| `"r"` | read (default) |
| `"w"` | write – replaces content |
| `"a"` | append to the end |
| `"x"` | create, fail if it exists |
| `"b"` | binary, e.g. `"rb"` for images |

> In the browser editor, files live in a temporary in-memory file system – perfect for practice.

@@lesson lines | Working Line by Line
Large files should be processed one line at a time:

```python
with open("log.txt", "w") as f:
    f.write("INFO start\nERROR disk full\nINFO retry\nERROR timeout\n")

errors = []
with open("log.txt") as f:
    for line in f:
        line = line.strip()
        if line.startswith("ERROR"):
            errors.append(line)
print(errors)
print(f"{len(errors)} errors found")
```

`readlines()` returns all lines as a list – fine for small files, but iterating directly uses far less memory.

@@lesson csv-json | CSV and JSON Files
## CSV – spreadsheet-like data

```python
import csv

rows = [["name", "score"], ["Ada", 95], ["Linus", 88]]
with open("scores.csv", "w", newline="") as f:
    csv.writer(f).writerows(rows)

with open("scores.csv", newline="") as f:
    for row in csv.DictReader(f):
        print(row["name"], int(row["score"]))
```

## JSON – the language of web APIs

```python
import json

config = {"theme": "dark", "languages": ["python", "sql"], "beta": False}
with open("config.json", "w") as f:
    json.dump(config, f, indent=2)

with open("config.json") as f:
    loaded = json.load(f)
print(loaded["languages"])
print(json.dumps(loaded, indent=2))
```

`json.dumps` / `json.loads` convert to and from **strings**; `dump` / `load` work with **files**.

@@lesson pathlib | Paths with pathlib
`pathlib` is the modern way to work with file paths on any operating system.

```python
from pathlib import Path

folder = Path("reports")
folder.mkdir(exist_ok=True)
(folder / "jan.txt").write_text("January report")
(folder / "feb.txt").write_text("February report")

for path in sorted(folder.glob("*.txt")):
    print(path.name, path.stem, path.suffix, len(path.read_text()))

print(Path("data/2026/sales.csv").parent)
print(Path("photo.JPG").suffix.lower())
```

The `/` operator joins paths correctly on Windows, macOS and Linux.

@@module error-handling | Error Handling | premium | Intermediate
Understand exceptions, handle them with try/except/else/finally, raise your own errors and debug systematically.

@@lesson exceptions | Understanding Exceptions
When something goes wrong at runtime, Python raises an **exception**. If nobody handles it, the program crashes with a traceback.

```python
numbers = [1, 2, 3]
print(numbers[10])
```

## Common exceptions

| Exception | Typical cause |
|---|---|
| `SyntaxError` | Invalid code (missing colon, bracket) |
| `NameError` | Using a name that doesn't exist |
| `TypeError` | Wrong type, e.g. `"a" + 1` |
| `ValueError` | Right type, wrong value: `int("abc")` |
| `IndexError` | List index out of range |
| `KeyError` | Missing dictionary key |
| `ZeroDivisionError` | Dividing by zero |
| `FileNotFoundError` | Opening a file that doesn't exist |

@@lesson try-except | try, except, else, finally
```python
def safe_divide(a, b):
    try:
        result = a / b
    except ZeroDivisionError:
        print("Can't divide by zero!")
        return None
    except TypeError as err:
        print("Bad input:", err)
        return None
    else:
        print("Division worked")      # runs only if no exception
        return result
    finally:
        print("This always runs")     # cleanup

print(safe_divide(10, 2))
print(safe_divide(10, 0))
print(safe_divide(10, "x"))
```

## Validating user input

```python
for raw in ["42", "forty-two", "7"]:
    try:
        number = int(raw)
        print("Got", number)
    except ValueError:
        print(f"'{raw}' is not a whole number")
```

> **Never** write a bare `except:` that silently swallows everything – you'll hide real bugs. Catch the specific exceptions you expect.

@@lesson raising | Raising Your Own Exceptions
Use `raise` when your function receives something it can't work with:

```python
def set_age(age):
    if not isinstance(age, int):
        raise TypeError("age must be an integer")
    if age < 0:
        raise ValueError("age cannot be negative")
    return age

try:
    set_age(-5)
except ValueError as e:
    print("Error:", e)
```

## Custom exception classes

```python
class InsufficientFundsError(Exception):
    pass

def withdraw(balance, amount):
    if amount > balance:
        raise InsufficientFundsError(f"Need {amount - balance} more")
    return balance - amount

try:
    withdraw(50, 80)
except InsufficientFundsError as e:
    print("Payment declined:", e)
```

@@lesson debugging | Debugging Like a Pro
Bugs are normal. A systematic approach finds them fast:

1. **Read the traceback** from the bottom: exception type, message, then the line.
2. **Reproduce** the bug with the smallest possible input.
3. **Inspect values** with `print(f"{variable=}")` or a debugger.
4. **Form a hypothesis**, change one thing, test again.

```python
def average(values):
    total = 0
    for v in values:
        total += v
    print(f"{total=} {len(values)=}")   # debug print
    return total / len(values)

print(average([4, 8, 6]))
```

## Using a debugger

In VS Code, click left of a line number to set a **breakpoint**, then press **F5**. The program pauses there so you can inspect every variable and step line by line. You can also put `breakpoint()` in your code to open Python's built-in debugger.

## Logging instead of print

```python
import logging
logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logging.info("Starting import")
logging.warning("3 rows skipped")
```

@@module libraries | Python Libraries | premium | Intermediate
Discover the Python ecosystem: how to find, evaluate and use popular libraries for HTTP, data, dates, and more.

@@lesson ecosystem | The Python Ecosystem
Python's superpower is its ecosystem: over 500,000 packages on **PyPI**. Knowing what exists saves you from reinventing the wheel.

| Area | Popular libraries |
|---|---|
| HTTP & APIs | `requests`, `httpx` |
| Web frameworks | `Django`, `Flask`, `FastAPI` |
| Data | `pandas`, `NumPy`, `polars` |
| Visualisation | `matplotlib`, `seaborn`, `plotly` |
| Machine learning | `scikit-learn`, `PyTorch` |
| Databases | `SQLAlchemy`, `psycopg` |
| Testing | `pytest` |
| Automation | `openpyxl`, `selenium`, `playwright` |
| CLI tools | `typer`, `click`, `rich` |

## Choosing a library

Before you `pip install`, check: Is it actively maintained (recent releases)? Is the documentation good? How many projects use it? Does its licence allow your use?

@@lesson numpy-intro | NumPy: Fast Numbers
NumPy provides fast arrays for numerical work and underpins pandas and most of data science.

```python
import numpy as np

prices = np.array([19.99, 5.49, 3.20, 12.00])
print(prices * 1.22)          # maths on every element at once
print(prices.mean(), prices.max())
print(prices[prices > 5])     # boolean filtering

matrix = np.arange(1, 10).reshape(3, 3)
print(matrix)
print(matrix.sum(axis=0))     # column sums
```

(The first run downloads NumPy into your browser, so it takes a few seconds.)

@@lesson regex | Regular Expressions with re
Regular expressions find patterns in text – emails, phone numbers, dates.

```python
import re

text = "Contact ada@example.com or grace@navy.mil before 2026-12-01."
emails = re.findall(r"[\w.+-]+@[\w-]+\.\w+", text)
print(emails)

match = re.search(r"(\d{4})-(\d{2})-(\d{2})", text)
if match:
    year, month, day = match.groups()
    print(year, month, day)

print(re.sub(r"\d", "#", "Card 1234 5678"))
```

| Pattern | Matches |
|---|---|
| `\d` | a digit |
| `\w` | letter, digit or `_` |
| `\s` | whitespace |
| `+` / `*` / `?` | 1+, 0+, 0 or 1 times |
| `{4}` | exactly 4 times |
| `( )` | capture group |

@@lesson automation | Automating Everyday Tasks
Python excels at automation. A typical script combines several libraries:

```python-norun
# rename all photos in a folder to date-based names
from pathlib import Path
from datetime import datetime

folder = Path("photos")
for i, photo in enumerate(sorted(folder.glob("*.jpg")), start=1):
    taken = datetime.fromtimestamp(photo.stat().st_mtime)
    new_name = f"{taken:%Y-%m-%d}_{i:03}.jpg"
    photo.rename(folder / new_name)
    print("Renamed", photo.name, "->", new_name)
```

Other popular automation jobs: generating Excel reports with `openpyxl`, sending emails with `smtplib`, filling web forms with `playwright`, and scheduling scripts with cron or Windows Task Scheduler.

@@module apis | Working with APIs | premium | Intermediate
Understand HTTP and REST, call real web APIs with requests, handle JSON, authentication, errors and rate limits.

@@lesson http-rest | HTTP and REST APIs
An **API** (Application Programming Interface) lets programs talk to each other. Most web APIs use **HTTP** and return **JSON**.

A request has:

| Part | Example |
|---|---|
| Method | `GET` (read), `POST` (create), `PUT`/`PATCH` (update), `DELETE` |
| URL | `https://api.example.com/users/42` |
| Headers | `Authorization: Bearer <token>` |
| Body | JSON data for POST/PUT |

The response has a **status code**:

| Code | Meaning |
|---|---|
| 200 | OK |
| 201 | Created |
| 400 | Bad request (your data is wrong) |
| 401 / 403 | Not authenticated / not allowed |
| 404 | Not found |
| 429 | Too many requests |
| 500 | Server error |

@@lesson requests-library | Calling APIs with requests
Install with `pip install requests`, then:

```python-norun
import requests

response = requests.get(
    "https://api.github.com/repos/python/cpython",
    timeout=10,
)
response.raise_for_status()          # raise an error for 4xx/5xx
data = response.json()               # parse JSON into dicts/lists
print(data["full_name"], "has", data["stargazers_count"], "stars")
```

## Query parameters and POST

```python-norun
params = {"q": "language:python", "sort": "stars"}
r = requests.get("https://api.github.com/search/repositories", params=params, timeout=10)
for repo in r.json()["items"][:5]:
    print(repo["name"])

new_post = {"title": "Hello", "body": "From Python", "userId": 1}
r = requests.post("https://jsonplaceholder.typicode.com/posts", json=new_post, timeout=10)
print(r.status_code, r.json())
```

> Always pass a `timeout` – without it your program can hang forever if a server doesn't respond.

@@lesson json-processing | Processing API Data
API responses are nested dictionaries and lists. Here's a realistic (offline) example of transforming one:

```python
import json

raw = '''{"city": "Milan", "forecast": [
  {"day": "Mon", "temp": 18, "rain": 0.0},
  {"day": "Tue", "temp": 21, "rain": 2.5},
  {"day": "Wed", "temp": 16, "rain": 8.1}]}'''

data = json.loads(raw)
rainy = [d["day"] for d in data["forecast"] if d["rain"] > 1]
avg = sum(d["temp"] for d in data["forecast"]) / len(data["forecast"])
print(f"{data['city']}: avg {avg:.1f}°C, take an umbrella on {', '.join(rainy)}")
```

@@lesson api-auth-errors | Authentication, Secrets and Errors
Most APIs need a key. **Never hard-code secrets** in your code or commit them to Git – load them from environment variables:

```python-norun
import os
import time
import requests

API_KEY = os.environ["WEATHER_API_KEY"]   # set in your shell or a .env file

def get_with_retry(url, retries=3):
    for attempt in range(1, retries + 1):
        try:
            r = requests.get(url, headers={"Authorization": f"Bearer {API_KEY}"}, timeout=10)
            if r.status_code == 429:               # rate limited
                time.sleep(2 ** attempt)           # exponential back-off
                continue
            r.raise_for_status()
            return r.json()
        except requests.RequestException as e:
            print(f"Attempt {attempt} failed: {e}")
            time.sleep(1)
    raise RuntimeError("API unavailable")
```

Use the `python-dotenv` package to load a local `.env` file during development, and add `.env` to `.gitignore`.

@@module databases | Database Basics | premium | Intermediate
Store data permanently with SQL: tables, CRUD queries, joins, using SQLite from Python safely, and an introduction to ORMs.

@@lesson sql-intro | Databases and SQL
A **relational database** stores data in **tables** made of rows and columns. You talk to it with **SQL**.

```sql
CREATE TABLE students (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    country TEXT,
    score INTEGER
);
```

The four basic operations are called **CRUD**:

| Operation | SQL |
|---|---|
| Create | `INSERT INTO students (name, score) VALUES ('Ada', 95);` |
| Read | `SELECT name, score FROM students WHERE score > 80 ORDER BY score DESC;` |
| Update | `UPDATE students SET score = 97 WHERE name = 'Ada';` |
| Delete | `DELETE FROM students WHERE id = 3;` |

Popular databases: **PostgreSQL** and **MySQL** for servers, **SQLite** built into Python for small apps and learning.

@@lesson sqlite-python | Using SQLite from Python
```python
import sqlite3

conn = sqlite3.connect(":memory:")       # a database in memory
cur = conn.cursor()
cur.execute("CREATE TABLE students (id INTEGER PRIMARY KEY, name TEXT, score INTEGER)")

students = [("Ada", 95), ("Linus", 82), ("Grace", 99), ("Alan", 74)]
cur.executemany("INSERT INTO students (name, score) VALUES (?, ?)", students)
conn.commit()

for row in cur.execute("SELECT name, score FROM students WHERE score >= ? ORDER BY score DESC", (80,)):
    print(row)

cur.execute("SELECT AVG(score), COUNT(*) FROM students")
print(cur.fetchone())
conn.close()
```

## Always use placeholders

```python-norun
# DANGEROUS – SQL injection
cur.execute(f"SELECT * FROM users WHERE name = '{user_input}'")
# SAFE
cur.execute("SELECT * FROM users WHERE name = ?", (user_input,))
```

Placeholders (`?`) stop attackers from injecting SQL through user input. This is a classic interview question.

@@lesson joins | Relationships and JOINs
Real apps split data into related tables and combine them with `JOIN`.

```python
import sqlite3
db = sqlite3.connect(":memory:")
db.executescript("""
CREATE TABLE customers (id INTEGER PRIMARY KEY, name TEXT);
CREATE TABLE orders (id INTEGER PRIMARY KEY, customer_id INTEGER, total REAL,
                     FOREIGN KEY (customer_id) REFERENCES customers(id));
INSERT INTO customers VALUES (1, 'Ada'), (2, 'Linus'), (3, 'Grace');
INSERT INTO orders VALUES (1, 1, 25.0), (2, 1, 40.0), (3, 3, 15.5);
""")

query = """
SELECT c.name, COUNT(o.id) AS orders, COALESCE(SUM(o.total), 0) AS spent
FROM customers c
LEFT JOIN orders o ON o.customer_id = c.id
GROUP BY c.id
ORDER BY spent DESC
"""
for name, orders, spent in db.execute(query):
    print(f"{name:<6} {orders} orders  €{spent:.2f}")
```

`INNER JOIN` keeps only matches; `LEFT JOIN` keeps every row from the left table (Linus appears with 0 orders).

@@lesson orm-intro | ORMs and SQLAlchemy
An **ORM** (Object-Relational Mapper) lets you work with database rows as Python objects. **SQLAlchemy** is the most popular one; Django has its own.

```python-norun
from sqlalchemy import create_engine, String
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, Session

class Base(DeclarativeBase):
    pass

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True)

engine = create_engine("sqlite:///app.db")
Base.metadata.create_all(engine)

with Session(engine) as session:
    session.add(User(email="ada@example.com"))
    session.commit()
    print(session.query(User).count())
```

ORMs speed up development, but you should still understand the SQL they generate – employers expect both.
