@@module introduction | Introduction to Python | free | Foundations
What programming is, what Python is, what you can build with it, and your very first program.

@@lesson what-is-python | What is Python?
**Python** is a programming language: a way to give a computer precise instructions in text that both humans and computers can read.

It was created by Guido van Rossum and released in 1991. Today it is one of the most popular languages in the world because it is **easy to read**, **free**, and **useful for almost everything**.

## What is a program?

A program is a list of instructions the computer follows from top to bottom. Here is a complete Python program:

```python
print("Hello, World!")
```

Press **Try it Yourself**, then **Run**. The computer *prints* (shows) the text between the quotes. You just ran your first program!

## What can you build with Python?

| Area | Examples |
|---|---|
| Web development | Websites and APIs with Django, Flask, FastAPI |
| Data & AI | Data analysis, machine learning, chatbots |
| Automation | Renaming files, filling spreadsheets, sending reports |
| Testing | Automatically checking that software works |
| Science & finance | Simulations, statistics, trading tools |

## Why Python is great for beginners

- The code looks almost like English: `if age >= 18: print("adult")`.
- There is very little "noise" – no semicolons or curly braces.
- A huge community means answers to almost every question already exist.

> **How to use this course:** read a lesson, run every example, change something, run it again. Breaking code on purpose is one of the fastest ways to learn.

@@lesson how-python-runs | How Python Runs Your Code
When you press Run, a program called the **Python interpreter** reads your code **line by line** and carries out each instruction.

```python
print("Line 1 runs first")
print("Line 2 runs second")
print("Line 3 runs third")
```

## Source code and the interpreter

- **Source code** is the text you write, saved in files ending in `.py`.
- The **interpreter** (the `python` program) translates and executes that code.

Because Python is *interpreted*, you can run code immediately without a separate "build" step. That's why it's great for experimenting.

## Errors are normal

If the interpreter can't understand a line, it stops and shows an **error message**. Try running this:

```python
print("This line works")
prnt("This line has a typo")
```

You'll see a `NameError: name 'prnt' is not defined`. The message tells you **what** went wrong and **on which line**. Reading error messages calmly is a core developer skill – you'll practise it throughout the course.

## In your browser

On womens4.com your code runs in a real Python interpreter inside your web browser, so you don't need to install anything yet.

@@lesson first-program | Your First Real Program
Let's write a program that does a bit more than one line.

```python
print("Welcome to womens4.com!")
print("Today I start learning Python.")
print("2 + 3 =", 2 + 3)
```

Notice three things:

1. Text must be inside quotes: `"like this"` or `'like this'`.
2. Numbers and calculations are written **without** quotes: `2 + 3`.
3. `print()` can show several things separated by commas – it puts a space between them.

## Printing on several lines

```python
print("Line one")
print()            # an empty print() gives a blank line
print("Line three")
```

## Your turn

Change the program below so it prints **your name** and **your goal**. Then run it.

```python
print("My name is ...")
print("My goal is to become a Python developer")
```

@@lesson learning-plan | How to Learn Programming Effectively
Learning to code is a skill like learning a language or an instrument. A few habits make a huge difference.

## 1. Practise a little every day

Thirty focused minutes every day beats five hours once a week. Your dashboard tracks your **learning streak** to help you build the habit.

## 2. Type the code – don't just read it

Re-typing examples (instead of copy-pasting) builds muscle memory and helps you notice details like brackets and quotes.

## 3. Break things on purpose

After running an example, change it. What happens if you remove a quote? Use a different number? Predict the result first, then check.

## 4. Read error messages from the bottom

The last line of an error says what went wrong. The lines above show where.

## 5. Build small projects early

As soon as you know a few concepts, combine them into tiny programs: a tip calculator, a quiz game, a to-do list. Module 19 is all about projects.

## 6. Learn to search

Professional developers search constantly. Good searches include the language and the error, for example: `python TypeError can only concatenate str`.

> **Your path:** Foundations → Core Python → Intermediate → Projects → Professional skills. Follow the [roadmap](/roadmap) and you will have a clear plan from today to your first job application.

@@module setup | Installing Python and Setting Up | free | Foundations
Install Python on your computer, choose a code editor, run scripts from the terminal and use the interactive shell.

@@lesson install-python | Installing Python
You can do the whole beginner part of this course in the browser, but real projects run on your own computer. Let's install Python 3.

## Windows

1. Go to **python.org/downloads** and download the latest Python 3 installer.
2. Run it and **tick "Add python.exe to PATH"** at the bottom of the first screen – this is important.
3. Click **Install Now**.

## macOS

Download the macOS installer from python.org, or with [Homebrew](https://brew.sh):

```bash
brew install python
```

## Linux

Python 3 is usually pre-installed. If not (Ubuntu/Debian):

```bash
sudo apt update
sudo apt install python3 python3-pip python3-venv
```

## Check that it works

Open a terminal (Command Prompt / PowerShell on Windows, Terminal on macOS/Linux) and type:

```bash
python --version
```

On macOS/Linux you may need `python3 --version`. You should see something like `Python 3.13.0`.

@@lesson code-editor | Choosing a Code Editor
A code editor is where you write your programs. We recommend **Visual Studio Code (VS Code)** – free, fast and used by millions of developers.

## Setting up VS Code

1. Download it from **code.visualstudio.com** and install it.
2. Open VS Code, click the **Extensions** icon on the left and install the **Python** extension (by Microsoft).
3. Create a folder for your projects, e.g. `python-projects`, and open it with **File → Open Folder**.

## Other good choices

| Editor | Good for |
|---|---|
| PyCharm Community | A full Python IDE with powerful refactoring |
| Thonny | Very simple editor made for absolute beginners |
| Jupyter Notebook | Data analysis and experiments |

> Whatever you choose, learn its keyboard shortcuts for saving, running code and searching. Small time savings add up quickly.

@@lesson running-scripts | Running Python Files
Create a new file called `hello.py` in your project folder and write:

```python-norun
name = "Ada"
print("Hello,", name)
print("This program runs from a file!")
```

Save it, then open a terminal **in that folder** and run:

```bash
python hello.py
```

(Use `python3 hello.py` on macOS/Linux if `python` doesn't work.)

## Useful terminal commands

| Task | Windows | macOS / Linux |
|---|---|---|
| Show current folder | `cd` | `pwd` |
| List files | `dir` | `ls` |
| Enter a folder | `cd projects` | `cd projects` |
| Go up one folder | `cd ..` | `cd ..` |

In VS Code you can also press the **▶ Run** button in the top-right corner, which runs the current file in the built-in terminal.

@@lesson interactive-shell | The Interactive Shell (REPL)
Type `python` in a terminal with nothing after it and you enter the **interactive shell**, also called the **REPL** (Read–Eval–Print Loop):

```text
>>> 2 + 2
4
>>> "py" * 3
'pypypy'
>>> exit()
```

The `>>>` prompt waits for a line of Python, runs it, and immediately shows the result. It's perfect for quick experiments.

## Shell vs script

- **Shell:** quick tests, one line at a time, nothing is saved.
- **Script (`.py` file):** real programs you can save, share and run again.

## Getting help inside Python

```python
help(len)
```

`help()` shows the documentation for any function. `dir("text")` lists everything you can do with a value. Try both!

@@module syntax | Python Syntax | free | Foundations
The rules of writing Python: statements, indentation, comments, print and input.

@@lesson statements-indentation | Statements and Indentation
A **statement** is one instruction. In Python each statement normally sits on its own line.

```python
x = 5
y = 10
print(x + y)
```

## Indentation matters

Many languages use `{ }` to group code. Python uses **indentation** – spaces at the start of a line. Code that belongs to an `if`, loop or function is indented by **4 spaces**:

```python
temperature = 30
if temperature > 25:
    print("It's hot!")
    print("Drink water.")
print("This line always runs.")
```

If the indentation is wrong, Python stops with an `IndentationError`:

```python
if True:
print("Not indented")
```

## Case sensitivity

Python is case-sensitive: `name`, `Name` and `NAME` are three different things, and `Print("hi")` is an error because the function is called `print`.

@@lesson comments | Comments
Comments are notes for humans. Python ignores everything after `#` on a line.

```python
# Calculate the total price
price = 20
quantity = 3
total = price * quantity  # multiply price by quantity
print(total)
```

## Good comments explain *why*

```python-norun
# Bad: adds 1 to count
count = count + 1

# Good: the first item is the header row, so skip it
count = count + 1
```

## Multi-line notes

Python has no special multi-line comment, but you can start several lines with `#`. Triple-quoted strings (`"""..."""`) are used for **docstrings** – documentation for functions – which you'll meet in Module 11.

> **Tip:** You can temporarily "comment out" a line of code with `#` to stop it running while you debug.

@@lesson print-function | Output with print()
`print()` is the function you'll use most while learning.

```python
print("Python", "is", "fun")          # separated by spaces
print("Python", "is", "fun", sep="-") # custom separator
print("No newline", end=" ")
print("at the end")
```

## Special characters

| Code | Meaning |
|---|---|
| `\n` | New line |
| `\t` | Tab |
| `\"` | A double quote inside a string |
| `\\` | A backslash |

```python
print("Line 1\nLine 2")
print("Name:\tAda")
print("She said \"hi\"")
```

## Printing variables and text together

The cleanest way is an **f-string** – put `f` before the quotes and variables inside `{ }`:

```python
name = "Ada"
age = 36
print(f"{name} is {age} years old.")
```

@@lesson input-function | Input with input()
`input()` pauses the program and waits for the user to type something.

```python
name = input("What is your name? ")
print(f"Nice to meet you, {name}!")
```

> In the womens4.com editor, click **Input** and type the values (one per line) *before* you press Run.

## input() always returns text

Even if the user types `25`, you get the string `"25"`. To do maths you must **convert** it:

```python
age = int(input("How old are you? "))
print(f"Next year you will be {age + 1}.")
```

`int()` converts to a whole number, `float()` to a decimal number. If the user types something that isn't a number, Python raises a `ValueError` – you'll learn to handle that in Module 15.

@@module variables-data-types | Variables and Data Types | free | Foundations
Store data in variables and understand Python's basic types: str, int, float, bool and None.

@@lesson variables | Variables
A **variable** is a name that refers to a value. You create one with `=` (the *assignment* operator).

```python
city = "Milan"
population = 1_370_000
print(city, population)
```

Think of a variable as a **label** stuck on a value. You can move the label to a new value at any time:

```python
score = 10
score = score + 5   # take the old value, add 5, store it again
print(score)
```

## Naming rules

- Letters, digits and `_` only; can't start with a digit.
- No spaces: use `snake_case` like `first_name`.
- Don't use Python keywords like `if`, `for`, `class`.

```python-norun
user_name = "ok"     # ✓
userName = "works"   # ✓ but not the Python style
2nd_place = "no"     # ✗ SyntaxError
```

## Multiple assignment

```python
x, y, z = 1, 2, 3
a = b = 0
print(x, y, z, a, b)
```

Choose **descriptive names**. `total_price` is much clearer than `tp`.

@@lesson data-types | Data Types
Every value in Python has a **type**. Use `type()` to see it.

```python
print(type("hello"))   # str  – text
print(type(42))        # int  – whole number
print(type(3.14))      # float – decimal number
print(type(True))      # bool – True or False
print(type(None))      # NoneType – "nothing"
```

## The basic types

| Type | Example | Used for |
|---|---|---|
| `str` | `"Python"` | Text |
| `int` | `2026` | Counting, whole numbers |
| `float` | `19.99` | Measurements, prices |
| `bool` | `True` | Yes/no answers |
| `NoneType` | `None` | "No value yet" |

Later you'll learn collection types: `list`, `tuple`, `dict` and `set`.

## Dynamic typing

A variable can point to a value of any type, and that can change:

```python
thing = 5
print(type(thing))
thing = "five"
print(type(thing))
```

This flexibility is convenient, but in larger projects developers add **type hints** (Module 20) to keep things clear.

@@lesson type-conversion | Type Conversion (Casting)
Converting a value from one type to another is called **casting**.

```python
age_text = "29"
age = int(age_text)        # str -> int
price = float("4.50")      # str -> float
label = str(100)           # int -> str
print(age + 1, price * 2, label + "%")
```

## Common conversions

```python
print(int(7.9))      # 7  (cuts off the decimals)
print(round(7.9))    # 8  (rounds)
print(float(3))      # 3.0
print(bool(0), bool(1), bool(""), bool("hi"))
```

## Why it matters

You can't add a number to text directly:

```python
print("Age: " + 30)
```

That raises `TypeError: can only concatenate str (not "int") to str`. Fix it with `str(30)` or, better, an f-string: `f"Age: {30}"`.

@@lesson none-and-booleans | Booleans and None
## Booleans

A **boolean** is either `True` or `False` (capital T and F). Comparisons produce booleans:

```python
print(5 > 3)
print(10 == 11)
is_logged_in = True
print(is_logged_in)
```

## Truthy and falsy

Every value can be treated as a boolean. These are **falsy**: `False`, `0`, `0.0`, `""` (empty string), `None`, and empty collections. Everything else is **truthy**.

```python
name = ""
if name:
    print("Hello", name)
else:
    print("Name is empty")
```

## None

`None` means "no value". It is often used as a placeholder:

```python
result = None
print(result is None)   # use 'is' to compare with None
```

@@module numbers-strings | Numbers and Strings | free | Foundations
Do maths with Python and master text: indexing, slicing, methods and f-strings.

@@lesson numbers-math | Numbers and Math
Python is a powerful calculator.

```python
print(7 + 3)    # 10  addition
print(7 - 3)    # 4   subtraction
print(7 * 3)    # 21  multiplication
print(7 / 2)    # 3.5 division (always returns a float)
print(7 // 2)   # 3   floor division (whole part)
print(7 % 2)    # 1   modulo (remainder)
print(2 ** 10)  # 1024 power
```

## Useful built-in functions

```python
print(abs(-8))          # 8
print(round(3.14159, 2))# 3.14
print(max(4, 9, 2))     # 9
print(min(4, 9, 2))     # 2
```

## The math module

```python
import math
print(math.sqrt(81))
print(math.pi)
print(math.ceil(4.1), math.floor(4.9))
```

## A note about floats

Computers store decimals in binary, so tiny rounding errors happen:

```python
print(0.1 + 0.2)
print(round(0.1 + 0.2, 2))
```

For money, use `round()` for display or the `decimal` module for exact calculations.

@@lesson strings-basics | Strings
A **string** is text inside quotes. Single and double quotes work the same.

```python
greeting = "Hello"
name = 'Ada'
message = greeting + ", " + name + "!"   # joining = concatenation
print(message)
print("ha" * 3)
print(len(message))   # number of characters
```

## Multi-line strings

```python
poem = """Roses are red,
Python is great,
Learn it today,
Don't hesitate."""
print(poem)
```

## Strings are immutable

You can't change a character inside a string – you create a new string instead:

```python
word = "cat"
word = "b" + word[1:]
print(word)   # bat
```

@@lesson indexing-slicing | Indexing and Slicing
Each character in a string has a position called an **index**, starting at **0**.

```text
 P  y  t  h  o  n
 0  1  2  3  4  5
-6 -5 -4 -3 -2 -1
```

```python
lang = "Python"
print(lang[0])    # P
print(lang[5])    # n
print(lang[-1])   # n  (negative = count from the end)
```

## Slicing: `[start:stop:step]`

The `stop` index is **not included**.

```python
lang = "Python"
print(lang[0:2])   # Py
print(lang[2:])    # thon
print(lang[:4])    # Pyth
print(lang[::2])   # Pto  (every second char)
print(lang[::-1])  # nohtyP (reversed)
```

Slicing works the same way on lists, which you'll learn in Module 9.

@@lesson string-methods | String Methods
**Methods** are functions that belong to a value. You call them with a dot.

```python
text = "  Learn Python Today  "
print(text.strip())          # remove spaces at both ends
print(text.lower())
print(text.upper())
print(text.replace("Today", "Now"))
print("Python" in text)      # True – membership test
```

## Searching and splitting

```python
sentence = "red,green,blue"
colors = sentence.split(",")
print(colors)                 # ['red', 'green', 'blue']
print(" | ".join(colors))     # red | green | blue
print(sentence.find("green")) # 4
print(sentence.count("e"))
print("python".startswith("py"), "data.csv".endswith(".csv"))
```

## Checking content

```python
print("2026".isdigit(), "abc".isalpha(), "Hello".istitle())
```

@@lesson f-strings | Formatting with f-strings
f-strings are the modern, readable way to build text from values.

```python
name = "Ada"
balance = 1234.5678
items = 3
print(f"Hi {name}, you have {items} items.")
print(f"Balance: €{balance:.2f}")          # 2 decimal places
print(f"Big number: {1234567:,}")          # thousands separator
print(f"Percent: {0.756:.1%}")             # 75.6%
print(f"{'left':<10}|{'right':>10}|")      # alignment
print(f"2 + 3 = {2 + 3}")                  # any expression
```

## Debugging trick

Add `=` inside the braces to print the expression and its value:

```python
x = 42
print(f"{x=}")
```

@@module operators | Operators | free | Foundations
Arithmetic, assignment, comparison, logical, membership and identity operators – and how Python decides which runs first.

@@lesson arithmetic-assignment | Arithmetic and Assignment Operators
You've met the arithmetic operators: `+ - * / // % **`. **Assignment operators** combine maths with storing the result:

```python
score = 10
score += 5    # score = score + 5
score -= 2    # score = score - 2
score *= 3    # score = score * 3
score //= 2   # score = score // 2
print(score)
```

## Real example: modulo

`%` gives the remainder – perfect for checking even/odd numbers or wrapping around:

```python
number = 17
print(number % 2)          # 1 -> odd
minutes = 135
print(minutes // 60, "h", minutes % 60, "min")
```

@@lesson comparison-logical | Comparison and Logical Operators
Comparison operators compare two values and return `True` or `False`.

| Operator | Meaning |
|---|---|
| `==` | equal to |
| `!=` | not equal to |
| `>` `<` | greater / less than |
| `>=` `<=` | greater / less than or equal |

```python
age = 20
print(age >= 18)
print(age == 21)
print("apple" < "banana")   # strings compare alphabetically
print(1 < age < 30)         # chained comparison
```

## Logical operators: and, or, not

```python
age = 20
has_ticket = True
print(age >= 18 and has_ticket)   # both must be True
print(age < 12 or age > 65)       # at least one True
print(not has_ticket)             # flips the value
```

> `=` **assigns** a value, `==` **compares** values. Mixing them up is one of the most common beginner bugs.

@@lesson membership-identity | Membership and Identity Operators
## Membership: in, not in

```python
fruits = ["apple", "banana", "cherry"]
print("banana" in fruits)
print("grape" not in fruits)
print("py" in "python")
```

## Identity: is, is not

`is` checks whether two names point to **the very same object**, not just equal values.

```python
a = [1, 2, 3]
b = [1, 2, 3]
c = a
print(a == b)   # True  – same contents
print(a is b)   # False – different objects
print(a is c)   # True  – same object
```

Use `is` mainly with `None`: `if result is None:`.

@@lesson precedence | Operator Precedence
When an expression has several operators, Python follows an order – like maths at school.

| Priority | Operators |
|---|---|
| 1 (highest) | `()` parentheses |
| 2 | `**` |
| 3 | `*`, `/`, `//`, `%` |
| 4 | `+`, `-` |
| 5 | comparisons `==`, `<`, `in`, `is` … |
| 6 | `not` |
| 7 | `and` |
| 8 (lowest) | `or` |

```python
print(2 + 3 * 4)      # 14, not 20
print((2 + 3) * 4)    # 20
print(2 ** 3 ** 2)    # 512 – ** goes right to left
print(True or False and False)  # True – 'and' first
```

> **Best practice:** when in doubt, add parentheses. They make code easier to read even when they're not strictly needed.
