@@module conditionals | Conditional Statements (If, Else, Elif) | premium | Core Python
Make decisions in your programs with if, elif and else, combine conditions and use match.

@@lesson if-statement | The if Statement
An `if` statement runs code **only when a condition is True**.

```python
temperature = 31
if temperature > 30:
    print("It's a hot day.")
    print("Remember sunscreen!")
print("Have a good day.")
```

Structure:

1. The keyword `if`
2. A condition that is `True` or `False`
3. A colon `:`
4. An **indented** block of code

Try changing `temperature` to `20` and run again – the indented lines are skipped.

@@lesson else-elif | else and elif
`else` runs when the `if` condition is False. `elif` ("else if") lets you check several conditions in order.

```python
score = 74
if score >= 90:
    grade = "A"
elif score >= 80:
    grade = "B"
elif score >= 70:
    grade = "C"
else:
    grade = "F"
print("Grade:", grade)
```

Python checks from top to bottom and runs **only the first** matching block.

## A real example

```python
password = "pythonista2026"
if len(password) < 8:
    print("Too short")
elif password.isalpha():
    print("Add some numbers")
else:
    print("Password accepted")
```

@@lesson nested-combined | Combining and Nesting Conditions
Use `and`, `or` and `not` to combine conditions:

```python
age = 25
member = True
if age >= 18 and member:
    print("Welcome to the members' area")

day = "Sunday"
if day == "Saturday" or day == "Sunday":
    print("Weekend!")
```

You can also put an `if` inside another `if` (nesting), but keep it shallow – more than 2–3 levels gets hard to read.

```python
logged_in = True
is_admin = False
if logged_in:
    if is_admin:
        print("Admin dashboard")
    else:
        print("User dashboard")
else:
    print("Please log in")
```

## Conditional expression (ternary)

```python
age = 15
status = "adult" if age >= 18 else "minor"
print(status)
```

@@lesson match-case | Pattern Matching with match
Python 3.10 added `match`, a clean way to compare one value against many options:

```python
command = "stop"
match command:
    case "start":
        print("Starting engine")
    case "stop":
        print("Stopping engine")
    case "pause" | "wait":
        print("Pausing")
    case _:
        print("Unknown command")
```

`case _` is the default when nothing else matches. `match` can also unpack structures:

```python
point = (0, 5)
match point:
    case (0, 0):
        print("Origin")
    case (0, y):
        print(f"On the Y axis at {y}")
    case (x, y):
        print(f"Point at {x}, {y}")
```

@@module loops | While and For Loops | premium | Core Python
Repeat work automatically with while and for loops, range(), break, continue and nested loops.

@@lesson while-loop | The while Loop
A `while` loop repeats as long as its condition is True.

```python
count = 1
while count <= 5:
    print("Count:", count)
    count += 1
print("Done!")
```

> **Danger:** if the condition never becomes False you get an **infinite loop**. Always make sure something inside the loop moves it towards the end. (womens4.com stops code after 10 seconds to protect your browser.)

## A practical example

```python
balance = 1000
years = 0
while balance < 2000:
    balance *= 1.07   # 7% growth per year
    years += 1
print(f"It takes {years} years to double the money.")
```

@@lesson for-loop-range | The for Loop and range()
A `for` loop goes through each item of a sequence.

```python
for letter in "Python":
    print(letter)

for fruit in ["apple", "banana", "cherry"]:
    print("I like", fruit)
```

## range()

`range()` generates numbers – ideal when you need to repeat something a fixed number of times.

```python
for i in range(5):          # 0 to 4
    print(i, end=" ")
print()
for i in range(2, 11, 2):   # start, stop (excluded), step
    print(i, end=" ")
print()
for i in range(5, 0, -1):   # count down
    print(i, end=" ")
```

## Summing with a loop

```python
total = 0
for n in range(1, 101):
    total += n
print("Sum of 1..100 =", total)
```

@@lesson break-continue | break, continue and else
- `break` exits the loop immediately.
- `continue` skips to the next iteration.

```python
for n in range(1, 10):
    if n == 3:
        continue      # skip 3
    if n == 7:
        break         # stop at 7
    print(n)
```

## The loop else

A loop's `else` block runs only if the loop **was not** stopped by `break` – handy for searches:

```python
numbers = [4, 8, 15, 16]
for n in numbers:
    if n % 2 != 0:
        print("Found an odd number:", n)
        break
else:
    print("All numbers are even")
```

@@lesson nested-loops-enumerate | Nested Loops, enumerate() and zip()
A loop inside a loop runs the inner loop completely for each outer iteration:

```python
for row in range(1, 4):
    for col in range(1, 4):
        print(row * col, end="\t")
    print()
```

## enumerate(): index and value together

```python
tasks = ["learn loops", "practise", "build project"]
for number, task in enumerate(tasks, start=1):
    print(f"{number}. {task}")
```

## zip(): loop over several lists in parallel

```python
names = ["Ada", "Linus", "Grace"]
scores = [92, 85, 97]
for name, score in zip(names, scores):
    print(f"{name}: {score}")
```

@@module lists-tuples | Lists and Tuples | premium | Core Python
Store many values in ordered collections: create, change, sort and loop through lists; use tuples for fixed data.

@@lesson lists-basics | Creating and Accessing Lists
A **list** stores many values in order, inside square brackets.

```python
fruits = ["apple", "banana", "cherry"]
numbers = [3, 1, 4, 1, 5]
mixed = ["Ada", 36, True]
print(fruits[0], fruits[-1])
print(len(numbers))
print(numbers[1:3])
```

Lists are **mutable** – you can change them:

```python
fruits = ["apple", "banana", "cherry"]
fruits[1] = "blueberry"
print(fruits)
```

@@lesson list-methods | Changing Lists
```python
todo = ["email Bob"]
todo.append("buy milk")          # add to the end
todo.insert(0, "wake up")        # add at a position
todo.extend(["code", "sleep"])   # add many
print(todo)

todo.remove("buy milk")          # remove by value
last = todo.pop()                # remove and return the last item
print("Popped:", last)
del todo[0]                      # remove by index
print(todo)
```

## Sorting and searching

```python
scores = [70, 95, 82, 61]
scores.sort()                       # sorts in place
print(scores)
print(sorted(scores, reverse=True)) # returns a new sorted list
print(scores.index(82), scores.count(70))
print(sum(scores), max(scores), min(scores))
```

@@lesson list-comprehensions | Looping and List Comprehensions
The classic way to build a new list:

```python
numbers = [1, 2, 3, 4, 5]
squares = []
for n in numbers:
    squares.append(n * n)
print(squares)
```

A **list comprehension** does the same in one readable line:

```python
numbers = [1, 2, 3, 4, 5, 6]
squares = [n * n for n in numbers]
evens = [n for n in numbers if n % 2 == 0]
words = [w.upper() for w in ["py", "path"]]
print(squares, evens, words)
```

Pattern: `[expression for item in iterable if condition]`.

## Copying lists – a common trap

```python
a = [1, 2, 3]
b = a          # NOT a copy – both names point to the same list
b.append(4)
print(a)       # [1, 2, 3, 4]
c = a.copy()   # a real copy
c.append(5)
print(a, c)
```

@@lesson tuples | Tuples
A **tuple** is like a list but **immutable** (can't be changed). Use round brackets.

```python
point = (10, 20)
rgb = (255, 128, 0)
print(point[0], len(rgb))
```

Use tuples for data that shouldn't change: coordinates, RGB colours, database rows.

## Unpacking

```python
person = ("Ada", "Lovelace", 1815)
first, last, year = person
print(first, year)

a, b = 1, 2
a, b = b, a      # swap two variables
print(a, b)
```

## Returning several values

Functions often return tuples:

```python
def min_max(values):
    return min(values), max(values)

low, high = min_max([4, 9, 1, 7])
print(low, high)
```

@@module dictionaries-sets | Dictionaries and Sets | premium | Core Python
Store data as key–value pairs with dictionaries and work with unique values using sets.

@@lesson dict-basics | Dictionaries
A **dictionary** stores **key: value** pairs – like a real dictionary that maps words to definitions.

```python
student = {
    "name": "Ada",
    "age": 21,
    "courses": ["Python", "SQL"],
}
print(student["name"])
student["age"] = 22            # change
student["email"] = "ada@example.com"  # add
print(student)
```

## Safe access with get()

```python
student = {"name": "Ada"}
print(student.get("phone"))              # None instead of an error
print(student.get("phone", "unknown"))   # default value
```

Keys must be immutable (strings, numbers, tuples) and unique.

@@lesson dict-methods | Looping and Dictionary Methods
```python
prices = {"apple": 0.5, "bread": 2.2, "milk": 1.1}
for item, price in prices.items():
    print(f"{item}: €{price:.2f}")

print(list(prices.keys()))
print(list(prices.values()))
print("milk" in prices)
removed = prices.pop("bread")
print(prices, removed)
```

## Counting with dictionaries

A very common pattern in interviews and real code:

```python
text = "the cat and the hat"
counts = {}
for word in text.split():
    counts[word] = counts.get(word, 0) + 1
print(counts)
```

## Dictionary comprehension

```python
squares = {n: n * n for n in range(1, 6)}
print(squares)
```

@@lesson nested-data | Nested Data Structures
Real data (like JSON from an API) is usually lists of dictionaries:

```python
users = [
    {"name": "Ada", "skills": ["python", "math"], "active": True},
    {"name": "Linus", "skills": ["c", "git"], "active": False},
    {"name": "Grace", "skills": ["cobol", "python"], "active": True},
]

for user in users:
    if user["active"]:
        print(user["name"], "knows", ", ".join(user["skills"]))

python_devs = [u["name"] for u in users if "python" in u["skills"]]
print(python_devs)
```

Learning to read and transform nested data is one of the most useful job skills you can have.

@@lesson sets | Sets
A **set** is an unordered collection of **unique** values.

```python
tags = {"python", "web", "python", "api"}
print(tags)             # duplicates removed
tags.add("data")
tags.discard("web")
print("api" in tags)    # very fast membership test
```

## Removing duplicates

```python
emails = ["a@x.com", "b@x.com", "a@x.com"]
unique = list(set(emails))
print(unique)
```

## Set operations

```python
backend = {"python", "sql", "docker"}
data = {"python", "sql", "pandas"}
print(backend | data)   # union
print(backend & data)   # intersection – in both
print(backend - data)   # difference
```

@@module functions | Python Functions | premium | Core Python
Write reusable code with functions: parameters, return values, scope, default and keyword arguments, *args, **kwargs and lambdas.

@@lesson defining-functions | Defining Functions
A **function** is a named, reusable block of code. Define it with `def`, call it with `()`.

```python
def greet():
    print("Hello from a function!")

greet()
greet()
```

## Parameters and return values

```python
def add(a, b):
    return a + b

result = add(3, 4)
print(result)
print(add(10, 20) * 2)
```

- **Parameters** are the names in the definition (`a`, `b`).
- **Arguments** are the values you pass in (`3`, `4`).
- `return` sends a value back. A function without `return` returns `None`.

> **Why functions?** They avoid repetition (DRY – Don't Repeat Yourself), make code easier to test and give names to ideas.

@@lesson arguments | Default and Keyword Arguments
```python
def make_coffee(size="medium", sugar=0):
    return f"{size} coffee with {sugar} sugar"

print(make_coffee())
print(make_coffee("large"))
print(make_coffee(sugar=2))              # keyword argument
print(make_coffee(sugar=1, size="small"))
```

## *args and **kwargs

```python
def total(*numbers):              # any number of positional arguments
    return sum(numbers)

def profile(**info):              # any number of keyword arguments
    for key, value in info.items():
        print(f"{key}: {value}")

print(total(1, 2, 3, 4))
profile(name="Ada", role="engineer")
```

> **Trap:** never use a mutable default like `def f(items=[])` – the same list is shared between calls. Use `items=None` and create the list inside.

@@lesson scope-docstrings | Scope and Docstrings
Variables created inside a function are **local** – they don't exist outside it.

```python
message = "global"

def show():
    message = "local"
    print("Inside:", message)

show()
print("Outside:", message)
```

Prefer passing values in as parameters and returning results instead of changing global variables.

## Docstrings

Document what a function does with a triple-quoted string right below `def`:

```python
def area(width, height):
    """Return the area of a rectangle."""
    return width * height

print(area(3, 4))
help(area)
```

@@lesson lambda-higher-order | Lambdas and Higher-Order Functions
A **lambda** is a tiny anonymous function written in one line:

```python
double = lambda x: x * 2
print(double(5))
```

Lambdas shine when passed to other functions:

```python
people = [("Ada", 36), ("Linus", 28), ("Grace", 45)]
by_age = sorted(people, key=lambda p: p[1])
print(by_age)

numbers = [1, 2, 3, 4, 5]
print(list(map(lambda n: n ** 2, numbers)))
print(list(filter(lambda n: n % 2 == 0, numbers)))
```

## Functions are values

```python
def shout(text):
    return text.upper() + "!"

def apply(func, value):
    return func(value)

print(apply(shout, "hello"))
```

## Recursion

A function can call itself – useful for tree-like problems:

```python
def factorial(n):
    if n <= 1:
        return 1
    return n * factorial(n - 1)

print(factorial(5))
```
