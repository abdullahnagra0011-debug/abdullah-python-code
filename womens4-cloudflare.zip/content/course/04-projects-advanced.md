@@module projects | Practical Python Projects | premium | Projects & Advanced
Build real programs step by step: a number-guessing game, an expense tracker, a contact book, a password generator and a weather CLI.

@@lesson project-guessing-game | Project 1: Number Guessing Game
Combine variables, loops, conditionals and input into a complete game.

**Requirements:** the computer picks a number from 1–100; the player guesses; the program says "higher" or "lower" and counts attempts.

```python
import random

secret = random.randint(1, 100)
attempts = 0
guesses = [50, 75, 62, 56, 59, 57, 58]   # simulated player – replace with input()

for guess in guesses:
    attempts += 1
    if guess < secret:
        print(f"{guess}: higher!")
    elif guess > secret:
        print(f"{guess}: lower!")
    else:
        print(f"Correct! The number was {secret}. Attempts: {attempts}")
        break
else:
    print(f"Out of guesses – it was {secret}")
```

**Make it yours:** replace the list with `int(input("Guess: "))` in a `while` loop, add difficulty levels, and handle non-numeric input with `try/except`.

@@lesson project-expense-tracker | Project 2: Expense Tracker
A program that records expenses, summarises them by category and saves them to a file.

```python
import json
from collections import defaultdict
from datetime import date

expenses = []

def add_expense(amount, category, note=""):
    expenses.append({"date": date.today().isoformat(), "amount": round(amount, 2),
                     "category": category.lower(), "note": note})

def summary():
    totals = defaultdict(float)
    for e in expenses:
        totals[e["category"]] += e["amount"]
    for cat, total in sorted(totals.items(), key=lambda kv: -kv[1]):
        print(f"{cat:<12} €{total:>8.2f}")
    print(f"{'TOTAL':<12} €{sum(totals.values()):>8.2f}")

def save(path="expenses.json"):
    with open(path, "w") as f:
        json.dump(expenses, f, indent=2)

add_expense(12.5, "Food", "lunch")
add_expense(45, "Transport", "monthly pass")
add_expense(8.2, "food", "coffee")
summary()
save()
print(open("expenses.json").read()[:80], "...")
```

**Extend it:** load existing expenses at start-up, add a menu with `input()`, export to CSV, and chart spending per month with matplotlib.

@@lesson project-contact-book | Project 3: Contact Book with Classes
Practise OOP by modelling contacts and a contact book.

```python
from dataclasses import dataclass, asdict
import re

@dataclass
class Contact:
    name: str
    email: str
    phone: str = ""

class ContactBook:
    def __init__(self):
        self._contacts: dict[str, Contact] = {}

    def add(self, contact: Contact):
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.\w+", contact.email):
            raise ValueError(f"Invalid email: {contact.email}")
        self._contacts[contact.name.lower()] = contact

    def find(self, text: str):
        text = text.lower()
        return [c for c in self._contacts.values() if text in c.name.lower() or text in c.email]

    def remove(self, name: str):
        return self._contacts.pop(name.lower(), None) is not None

    def __len__(self):
        return len(self._contacts)

book = ContactBook()
book.add(Contact("Ada Lovelace", "ada@example.com", "+39 333 000"))
book.add(Contact("Alan Turing", "alan@bletchley.uk"))
print(len(book), "contacts")
print([asdict(c) for c in book.find("ada")])
try:
    book.add(Contact("Bad", "not-an-email"))
except ValueError as e:
    print(e)
```

@@lesson project-password-generator | Project 4: Secure Password Generator
Use the `secrets` module (made for security) rather than `random`.

```python
import secrets
import string

def generate_password(length=16, symbols=True):
    if length < 8:
        raise ValueError("Use at least 8 characters")
    alphabet = string.ascii_letters + string.digits + (string.punctuation if symbols else "")
    while True:
        pwd = "".join(secrets.choice(alphabet) for _ in range(length))
        if (any(c.islower() for c in pwd) and any(c.isupper() for c in pwd)
                and any(c.isdigit() for c in pwd)):
            return pwd

def strength(pwd):
    score = sum([len(pwd) >= 12, any(c.isupper() for c in pwd), any(c.isdigit() for c in pwd),
                 any(c in string.punctuation for c in pwd)])
    return ["weak", "weak", "fair", "good", "strong"][score]

for _ in range(3):
    p = generate_password()
    print(p, "->", strength(p))
```

@@lesson project-weather-cli | Project 5: Weather Command-Line App
A portfolio-worthy tool that combines APIs, error handling and a command-line interface. Run it on your own computer.

```python-norun
"""weather.py – usage: python weather.py Milan"""
import argparse
import requests

GEO = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST = "https://api.open-meteo.com/v1/forecast"

def get_coordinates(city: str):
    r = requests.get(GEO, params={"name": city, "count": 1}, timeout=10)
    r.raise_for_status()
    results = r.json().get("results")
    if not results:
        raise SystemExit(f"City not found: {city}")
    return results[0]["latitude"], results[0]["longitude"], results[0]["name"]

def get_forecast(lat, lon):
    params = {"latitude": lat, "longitude": lon,
              "daily": "temperature_2m_max,temperature_2m_min", "timezone": "auto"}
    r = requests.get(FORECAST, params=params, timeout=10)
    r.raise_for_status()
    return r.json()["daily"]

def main():
    parser = argparse.ArgumentParser(description="3-day weather forecast")
    parser.add_argument("city")
    args = parser.parse_args()
    lat, lon, name = get_coordinates(args.city)
    daily = get_forecast(lat, lon)
    print(f"Forecast for {name}")
    for day, hi, lo in list(zip(daily["time"], daily["temperature_2m_max"], daily["temperature_2m_min"]))[:3]:
        print(f"  {day}: {lo:.0f}°C – {hi:.0f}°C")

if __name__ == "__main__":
    main()
```

**Portfolio checklist for every project:** a README with screenshots, clear setup instructions, a `requirements.txt`, tests (Module 22) and a link on your GitHub profile.

@@module advanced | Advanced Python Concepts | premium | Projects & Advanced
Write idiomatic, professional Python: comprehensions, iterators and generators, decorators, context managers, type hints, async and concurrency.

@@lesson comprehensions-advanced | Advanced Comprehensions
```python
matrix = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
flat = [n for row in matrix for n in row]
transposed = [[row[i] for row in matrix] for i in range(3)]
words = ["apple", "Banana", "cherry", "avocado"]
by_letter = {w[0].lower(): [x for x in words if x[0].lower() == w[0].lower()] for w in words}
lengths = {len(w) for w in words}
print(flat)
print(transposed)
print(by_letter)
print(lengths)
```

Comprehensions are great when they fit on one or two lines. If it gets complicated, a normal loop is more readable – readability wins.

@@lesson iterators-generators | Iterators and Generators
A **generator** produces values lazily, one at a time, using `yield`. It uses almost no memory, even for huge or infinite sequences.

```python
def countdown(n):
    while n > 0:
        yield n
        n -= 1

for x in countdown(3):
    print(x)

def fibonacci():
    a, b = 0, 1
    while True:
        yield a
        a, b = b, a + b

fib = fibonacci()
print([next(fib) for _ in range(10)])

# generator expression – like a list comprehension with ()
total = sum(n * n for n in range(1_000_000))
print(total)
```

Generators are how you process large files or data streams efficiently.

@@lesson decorators | Decorators
A **decorator** wraps a function to add behaviour – logging, timing, caching, access control – without changing its code.

```python
import time
from functools import wraps, lru_cache

def timer(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = func(*args, **kwargs)
        print(f"{func.__name__} took {time.perf_counter() - start:.4f}s")
        return result
    return wrapper

@timer
def slow_sum(n):
    return sum(range(n))

print(slow_sum(1_000_000))

@lru_cache(maxsize=None)        # built-in caching decorator
def fib(n):
    return n if n < 2 else fib(n - 1) + fib(n - 2)

print(fib(80))
```

You've already used decorators: `@property`, `@dataclass` – and web frameworks use them for routes, like `@app.get("/")`.

@@lesson context-managers | Context Managers
`with` guarantees setup and cleanup. You can write your own:

```python
from contextlib import contextmanager
import time

@contextmanager
def timed(label):
    start = time.perf_counter()
    try:
        yield
    finally:
        print(f"{label}: {time.perf_counter() - start:.3f}s")

with timed("building list"):
    data = [i ** 2 for i in range(300_000)]

class Transaction:
    def __enter__(self):
        print("BEGIN")
        return self
    def __exit__(self, exc_type, exc, tb):
        print("ROLLBACK" if exc_type else "COMMIT")
        return False   # don't swallow exceptions

with Transaction():
    print("updating rows...")
```

@@lesson type-hints | Type Hints
Type hints document what a function expects and returns. Tools like **mypy** and your editor use them to catch bugs before running the code.

```python
from typing import Optional

def greet(name: str, times: int = 1) -> str:
    return " ".join([f"Hello {name}!"] * times)

def find_user(users: dict[int, str], user_id: int) -> Optional[str]:
    return users.get(user_id)

scores: list[float] = [9.5, 7.0]
print(greet("Ada", 2))
print(find_user({1: "Ada"}, 2))
```

Python doesn't enforce hints at runtime – they're for humans and tools. Most professional codebases use them, and FastAPI uses them to validate data automatically.

@@lesson async-concurrency | Async and Concurrency
Programs often wait – for networks, disks or databases. **Concurrency** does other work while waiting.

```python
import asyncio
import time

async def fetch(name, delay):
    await asyncio.sleep(delay)          # simulates a network call
    return f"{name} done after {delay}s"

async def main():
    start = time.perf_counter()
    results = await asyncio.gather(fetch("A", 1), fetch("B", 1), fetch("C", 1))
    print(results)
    print(f"Total: {time.perf_counter() - start:.1f}s (not 3s!)")

await main()   # in a normal .py file use: asyncio.run(main())
```

| Tool | Best for |
|---|---|
| `asyncio` | Many network calls (web servers, scrapers) |
| `threading` | I/O-bound work with blocking libraries |
| `multiprocessing` | CPU-heavy calculations on several cores |
