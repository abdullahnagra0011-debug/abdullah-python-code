# womens4.com – Cloudflare Workers edition

This version of the project is set up to run on **Cloudflare Workers** using the OpenNext adapter (`@opennextjs/cloudflare`). It uses **Next.js 15**.

What changed compared to the Vercel version:
- `wrangler.jsonc` and `open-next.config.ts` configure the Worker.
- Lessons in `content/course/*.md` are bundled at build time into `content/course-data.generated.json` (Workers have no file system). This happens automatically in every `npm run` script.
- Stripe uses `fetch` and Web Crypto (`constructEventAsync`), which Workers require.
- Next.js 15 / React 19: page `params`, `searchParams` and `cookies()` are awaited.

## Deploy to Cloudflare – quick guide

### A) From GitHub (no command line)
1. Upload this project to a GitHub repository (files at the top level, with `package.json` next to `wrangler.jsonc`).
2. Cloudflare dashboard → **Workers & Pages → Create → Import a repository** → pick the repository.
3. Build settings:
   - Build command: `npx opennextjs-cloudflare build`
   - Deploy command: `npx opennextjs-cloudflare deploy`
   - The lessons are bundled automatically after `npm install` (a `postinstall` script), so nothing else is needed.
4. **Build variables** (needed at build time, because `NEXT_PUBLIC_` values are baked into the pages):
   `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `NEXT_PUBLIC_SITE_URL`, `NEXT_PUBLIC_SUPPORT_EMAIL`, `NEXT_PUBLIC_COMPANY_NAME`, `NEXT_PUBLIC_COMPANY_ADDRESS`.
5. After the first deploy: Worker → **Settings → Variables and Secrets** → add as **Secret**:
   `SUPABASE_SERVICE_ROLE_KEY`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_PRICE_ID`, `RESEND_API_KEY` (optional), and as plain text the same `NEXT_PUBLIC_*` values.

### B) From your computer
```bash
npm install
npx wrangler login
npx wrangler secret put SUPABASE_SERVICE_ROLE_KEY   # repeat for each secret
npm run deploy
```
Put the `NEXT_PUBLIC_*` values in `.env.local` before `npm run deploy` so they're baked into the build. Test locally in the real Workers runtime with `npm run preview` (uses `.dev.vars`, see `.dev.vars.example`).

### Connect womens4.com
1. Add womens4.com to Cloudflare (**Add a domain**) and change the nameservers at your registrar to the two Cloudflare gives you.
2. Worker → **Settings → Domains & Routes → Add → Custom domain** → `womens4.com` (and `www.womens4.com`). Or uncomment `routes` in `wrangler.jsonc`.
3. Update Supabase (Site URL + `https://womens4.com/auth/callback`) and the Stripe webhook (`https://womens4.com/api/stripe/webhook`), then redeploy.

### Limits
The Worker must be ≤ 3 MiB (compressed) on the Workers Free plan, 10 MiB on Paid. If deploy reports the Worker is too large, switch to Workers Paid ($5/month).

---

# womens4.com – Learn Python from Zero to Job-Ready

A production-ready Python learning platform: 25 modules / 105 lessons, an in-browser Python editor (Pyodide + Monaco), graded exercises, progress tracking, certificates, a €6.99/month Stripe subscription and an admin dashboard.

**Stack:** Next.js 14 (App Router) · React · Tailwind CSS · Supabase (Postgres + Auth) · Stripe · Pyodide · Monaco Editor · Vercel

---

## 1. Run it locally

```bash
npm install
cp .env.example .env.local      # then fill in the values (see section 3)
npm run dev                      # http://localhost:3000
```

Lessons in the free modules and the "Try it Yourself" editor work even before Supabase and Stripe are configured. Accounts, progress, payments and certificates need the steps below.

## 2. Set up Supabase (accounts + database)

1. Create a project at https://supabase.com.
2. **SQL Editor →** paste and run `supabase/schema.sql`. This creates all tables with Row Level Security.
3. **Authentication → URL Configuration:**
   - Site URL: your domain (e.g. `https://womens4.example.com`, or `http://localhost:3000` in development)
   - Redirect URLs: add `https://YOUR-DOMAIN/auth/callback` (and `http://localhost:3000/auth/callback`)
4. **Authentication → Providers → Email:** keep "Confirm email" on (recommended). Configure custom SMTP under Project Settings → Auth for production email delivery.
5. Copy **Project URL**, **anon key** and **service_role key** from Project Settings → API into your env.
6. Register on your site, then make yourself admin in the SQL editor:
   ```sql
   update public.profiles set role = 'admin' where email = 'you@example.com';
   ```

## 3. Environment variables

| Variable | Where it comes from | Exposed to browser? |
|---|---|---|
| `NEXT_PUBLIC_SITE_URL` | Your public URL | yes |
| `NEXT_PUBLIC_SUPPORT_EMAIL`, `NEXT_PUBLIC_COMPANY_NAME`, `NEXT_PUBLIC_COMPANY_ADDRESS` | Your legal details (footer, legal pages) | yes |
| `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase → Settings → API | yes (safe, RLS-protected) |
| `SUPABASE_SERVICE_ROLE_KEY` | Supabase → Settings → API | **no – server only** |
| `STRIPE_SECRET_KEY` | Stripe → Developers → API keys | **no – server only** |
| `STRIPE_WEBHOOK_SECRET` | Stripe webhook endpoint (see below) | **no – server only** |
| `STRIPE_PRICE_ID` | The €6.99/month price (see below) | no |
| `RESEND_API_KEY`, `EMAIL_FROM` | https://resend.com (optional) | no |

Secrets are only read in server code (`app/api/**`, `lib/stripe.ts`, `lib/supabase/admin.ts`). Never prefix them with `NEXT_PUBLIC_`.

## 4. Set up Stripe (€6.99/month)

1. Create the product and price (or do it in the Stripe dashboard: recurring, monthly, EUR 6.99):
   ```bash
   STRIPE_SECRET_KEY=sk_test_... npm run stripe:create-price
   ```
   Put the printed `price_...` into `STRIPE_PRICE_ID`.
2. **Customer portal:** Stripe → Settings → Billing → Customer portal → enable *cancel subscriptions*, *update payment methods* and *invoice history*. Users manage/cancel through this.
3. **Webhook:** Developers → Webhooks → add endpoint `https://YOUR-DOMAIN/api/stripe/webhook` with events:
   `checkout.session.completed`, `customer.subscription.created`, `customer.subscription.updated`, `customer.subscription.deleted`, `invoice.paid`, `invoice.payment_failed`. Copy the signing secret to `STRIPE_WEBHOOK_SECRET`.
   Locally: `stripe listen --forward-to localhost:3000/api/stripe/webhook`.
4. **Failed payments:** Settings → Billing → Subscriptions and emails → enable Smart Retries and "Send emails about failed payments". Also enable "Email customers about successful payments" for receipts.
5. Test with card `4242 4242 4242 4242`, then switch to live keys.

How access works: Premium is granted **only** from the webhook-synced `subscriptions` table when Stripe reports `active`/`trialing` and the paid period hasn't ended. The success page never grants access by itself – it waits for Stripe's confirmation.

## 5. Deploy to Vercel

1. Push the repo to GitHub and import it in Vercel.
2. Add all env variables (Production + Preview).
3. Update Supabase redirect URLs and the Stripe webhook URL to the production domain.

## 6. Before going live – checklist

- [ ] Replace the legal page templates (`app/privacy`, `app/terms`, `app/cookies`) with lawyer-reviewed text and your company details.
- [ ] Replace the sample testimonials on the home page with real ones (they're labelled as samples).
- [ ] Configure Stripe Tax if you sell to EU consumers (VAT OSS).
- [ ] Custom SMTP in Supabase so auth emails don't hit rate limits.
- [ ] Set yourself as admin and run a full test purchase + cancellation in test mode.

---

## Project structure

```
app/
  page.tsx                 Home (hero, why Python, how it works, courses, live editor, pricing, FAQ)
  courses/ roadmap/        Curriculum overview and zero-to-job-ready roadmap
  learn/[module]/[lesson]  W3Schools-style lesson view with sidebar, Try-it editor, prev/next, mark complete
  learn/[module]/exercises Quizzes, fill-in-the-code and coding challenges
  playground/              Full-page Python editor (Premium)
  pricing/                 Plans and transparent billing terms
  login/ register/ forgot-password/ update-password/   Supabase Auth
  dashboard/               Progress, streak, quiz results, achievements, certificates
  dashboard/profile        Name, marketing consent, data export, account deletion (GDPR)
  dashboard/billing        Subscription status, cancel via Stripe portal, payment history
  certificates/[id]        Public verification page + PDF + LinkedIn share
  admin/                   MRR & stats, users & subscriptions, content editor, certificates
  api/stripe/*             checkout, portal, webhook (signature-verified)
  api/exercises/*          server-side answer checking and score saving
  api/progress, api/certificates, api/account, api/materials
content/
  course/*.md              The 25-module curriculum (lessons in Markdown)
  exercises.ts             Questions per module (answers never sent to the browser)
  courses.ts               Course bundles used for certificates
public/pyodide-worker.js   Runs Python in a Web Worker (with 10 s timeout)
supabase/schema.sql        Tables, RLS policies and triggers
```

## Editing the curriculum

Lessons live in `content/course/*.md`:

```
@@module <slug> | <Title> | free|premium | <Stage>
Module description.

@@lesson <slug> | <Lesson title>
Markdown content…
```

- ` ```python ` blocks get **Copy** and **Try it Yourself** buttons.
- ` ```python-norun ` shows code without the Run button (for code that needs a network, files on disk, or a server).

Admins can also create new modules, lessons and exercises without a deploy at **/admin/content**.

## Security notes

- Learner code runs **only in the browser** (Pyodide in a Web Worker); nothing executes on the server.
- Premium lesson content is rendered on the server and never sent to non-premium visitors.
- Exercise answers stay on the server; scores are re-graded server-side before saving. Coding challenges are verified in the learner's browser sandbox, so their pass/fail is self-reported.
- RLS: users can only read their own rows; subscriptions, payments, scores and certificates can only be written with the service-role key from server routes.
- `profiles.role` cannot be changed by users (column-level grants).
- Stripe webhooks are verified with `STRIPE_WEBHOOK_SECRET`.
