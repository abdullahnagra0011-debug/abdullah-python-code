import Link from 'next/link';
import { ArrowRight, Flag } from 'lucide-react';
import { getCurriculum } from '@/lib/content';

export const metadata = {
  title: 'Python Developer Roadmap: Zero to Job-Ready',
  description: 'A week-by-week plan to go from never having coded to applying for junior Python developer jobs.',
};

const PHASES = [
  {
    weeks: 'Weeks 1–3',
    title: 'Foundations',
    goal: 'Write small programs confidently.',
    stage: 'Foundations',
    outcome: 'You can explain what a program is, install Python, and use variables, strings, numbers and operators.',
  },
  {
    weeks: 'Weeks 4–7',
    title: 'Core Python',
    goal: 'Control flow, collections and functions.',
    stage: 'Core Python',
    outcome: 'You can solve beginner coding challenges using if/else, loops, lists, dictionaries and your own functions.',
  },
  {
    weeks: 'Weeks 8–13',
    title: 'Intermediate Python',
    goal: 'Structure real programs.',
    stage: 'Intermediate',
    outcome: 'You write classes, split code into modules, read/write files, handle errors and use third-party libraries, APIs and SQL.',
  },
  {
    weeks: 'Weeks 14–17',
    title: 'Projects & advanced concepts',
    goal: 'Build things people can use.',
    stage: 'Projects & Advanced',
    outcome: 'You have 3–4 finished projects and understand comprehensions, generators, decorators, type hints and async.',
  },
  {
    weeks: 'Weeks 18–24',
    title: 'Professional skills & job search',
    goal: 'Work like a developer and get hired.',
    stage: 'Professional',
    outcome: 'You use Git daily, write tests, build a FastAPI/Flask API, analyse data with pandas, publish a portfolio and practise interviews.',
  },
];

export default async function RoadmapPage() {
  const modules = await getCurriculum();
  return (
    <div className="container py-14">
      <div className="mx-auto max-w-3xl text-center">
        <p className="eyebrow">Roadmap</p>
        <h1 className="mt-2 text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-5xl">From zero to job-ready Python developer</h1>
        <p className="section-sub">
          A realistic plan of about 6 months at 8–10 hours per week. Go faster or slower – what matters is finishing each step and building projects.
        </p>
      </div>

      <ol className="relative mx-auto mt-16 max-w-4xl space-y-10 before:absolute before:bottom-4 before:left-5 before:top-4 before:w-0.5 before:bg-gradient-to-b before:from-brand-500 before:to-brand-200 dark:before:to-brand-900 sm:before:left-6">
        {PHASES.map((p, i) => {
          const mods = modules.filter((m) => m.stage === p.stage);
          return (
            <li key={p.title} className="relative pl-14 sm:pl-20">
              <span className="absolute left-0 top-0 grid h-10 w-10 place-items-center rounded-full bg-brand-600 font-bold text-white ring-8 ring-white dark:ring-slate-950 sm:h-12 sm:w-12">
                {i + 1}
              </span>
              <div className="card p-6">
                <p className="text-sm font-semibold text-brand-700 dark:text-brand-400">{p.weeks}</p>
                <h2 className="mt-1 text-2xl font-bold text-slate-900 dark:text-white">{p.title}</h2>
                <p className="mt-1 text-slate-600 dark:text-slate-400">{p.goal}</p>
                <div className="mt-5 flex flex-wrap gap-2">
                  {mods.map((m) => (
                    <Link
                      key={m.slug}
                      href={`/learn/${m.slug}/${m.lessons[0]?.slug ?? ''}`}
                      className="rounded-lg border border-slate-200 px-3 py-1.5 text-sm font-medium text-slate-700 transition hover:border-brand-400 hover:bg-brand-50 hover:text-brand-800 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-brand-500/10"
                    >
                      {m.number}. {m.title}
                    </Link>
                  ))}
                </div>
                <p className="mt-5 rounded-xl bg-slate-50 p-4 text-sm leading-6 text-slate-700 dark:bg-slate-800/60 dark:text-slate-300">
                  <b>You&apos;re ready to move on when:</b> {p.outcome}
                </p>
              </div>
            </li>
          );
        })}
        <li className="relative pl-14 sm:pl-20">
          <span className="absolute left-0 top-0 grid h-10 w-10 place-items-center rounded-full bg-amber-500 text-white ring-8 ring-white dark:ring-slate-950 sm:h-12 sm:w-12">
            <Flag className="h-5 w-5" />
          </span>
          <div className="card border-amber-200 bg-amber-50/50 p-6 dark:border-amber-900 dark:bg-amber-500/5">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Apply for junior roles</h2>
            <p className="mt-2 text-slate-600 dark:text-slate-400">
              Typical first titles: Junior Python Developer, Backend Developer (Python), Automation Engineer, Data Analyst, QA Automation Engineer. Keep building and
              applying – consistency wins.
            </p>
          </div>
        </li>
      </ol>

      <div className="mt-14 text-center">
        <Link href="/learn/introduction/what-is-python" className="btn-primary btn-lg">
          Start step 1 now <ArrowRight className="h-5 w-5" />
        </Link>
      </div>
    </div>
  );
}
