'use client';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { Suspense, useState } from 'react';
import { Loader2, MailCheck } from 'lucide-react';
import { createClient, supabaseConfigured } from '@/lib/supabase/client';
import { AuthShell, FormMessage, NotConfigured } from '@/components/AuthShell';

function RegisterForm() {
  const params = useSearchParams();
  const router = useRouter();
  const nextRaw = params.get('next') || '/dashboard';
  const next = nextRaw.startsWith('/') && !nextRaw.startsWith('//') ? nextRaw : '/dashboard';
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [terms, setTerms] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [checkEmail, setCheckEmail] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 8) return setError('Use at least 8 characters for your password.');
    if (!terms) return setError('Please accept the Terms of Service and Privacy Policy.');
    setLoading(true);
    setError('');
    const { data, error } = await createClient().auth.signUp({
      email,
      password,
      options: {
        data: { full_name: name.trim() },
        emailRedirectTo: `${window.location.origin}/auth/callback?next=${encodeURIComponent(next)}`,
      },
    });
    setLoading(false);
    if (error) return setError(error.message);
    if (data.session) {
      router.push(next);
      router.refresh();
    } else {
      // Email confirmation is enabled – the account is not active until the link is clicked.
      setCheckEmail(true);
    }
  };

  if (checkEmail) {
    return (
      <AuthShell title="Check your inbox">
        <div className="text-center">
          <MailCheck className="mx-auto h-12 w-12 text-brand-600" />
          <p className="mt-4 text-slate-700 dark:text-slate-300">
            We sent a confirmation link to <b>{email}</b>. Click it to activate your account – then you can start learning.
          </p>
          <p className="mt-3 text-sm text-slate-500">No email after a few minutes? Check your spam folder.</p>
        </div>
      </AuthShell>
    );
  }

  return (
    <AuthShell
      title="Create your free account"
      subtitle={
        <>
          Already have one?{' '}
          <Link href={`/login?next=${encodeURIComponent(next)}`} className="font-semibold text-brand-700 dark:text-brand-400">
            Log in
          </Link>
        </>
      }
    >
      {!supabaseConfigured ? (
        <NotConfigured />
      ) : (
        <form onSubmit={submit} className="space-y-5">
          {error && <FormMessage type="error">{error}</FormMessage>}
          <div>
            <label htmlFor="name" className="label">
              Full name <span className="font-normal text-slate-400">(shown on certificates)</span>
            </label>
            <input id="name" required autoComplete="name" className="input" placeholder="e.g. Elon Musk" value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div>
            <label htmlFor="email" className="label">
              Email
            </label>
            <input id="email" type="email" required autoComplete="email" className="input" placeholder="you@gmail.com" value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div>
            <label htmlFor="password" className="label">
              Password
            </label>
            <input
              id="password"
              type="password"
              required
              minLength={8}
              autoComplete="new-password"
              className="input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <p className="mt-1 text-xs text-slate-500">At least 8 characters.</p>
          </div>
          <label className="flex items-start gap-2.5 text-sm text-slate-600 dark:text-slate-400">
            <input type="checkbox" className="mt-1 accent-brand-600" checked={terms} onChange={(e) => setTerms(e.target.checked)} />
            <span>
              I agree to the{' '}
              <Link href="/terms" target="_blank" className="font-medium text-brand-700 underline">
                Terms of Service
              </Link>{' '}
              and have read the{' '}
              <Link href="/privacy" target="_blank" className="font-medium text-brand-700 underline">
                Privacy Policy
              </Link>
              .
            </span>
          </label>
          <button className="btn-primary w-full" disabled={loading}>
            {loading && <Loader2 className="h-4 w-4 animate-spin" />} Create account
          </button>
        </form>
      )}
    </AuthShell>
  );
}

export default function RegisterPage() {
  return (
    <Suspense>
      <RegisterForm />
    </Suspense>
  );
}
