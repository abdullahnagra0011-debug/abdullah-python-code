import { getViewer } from '@/lib/auth';
import { Paywall } from '@/components/Paywall';
import { PlaygroundEditor } from '@/components/PlaygroundEditor';

export const metadata = { title: 'Online Python Editor' };

export default async function PlaygroundPage() {
  const viewer = await getViewer();
  return (
    <div className="container py-10">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="eyebrow">Playground</p>
          <h1 className="mt-1 text-3xl font-bold tracking-tight text-slate-900 dark:text-white">Online Python editor</h1>
          <p className="mt-2 text-slate-600 dark:text-slate-400">
            A full Python 3 interpreter in your browser. Libraries like numpy and pandas load automatically when you import them.
          </p>
        </div>
      </div>
      {viewer.premium ? (
        <PlaygroundEditor />
      ) : (
        <div className="mx-auto max-w-2xl">
          <p className="mb-6 text-center text-slate-600 dark:text-slate-400">
            Free members can run code in every free lesson with “Try it Yourself”. The standalone playground with saved scratchpad is a Premium feature.
          </p>
          <Paywall title="The Python playground" signedIn={!!viewer.user} />
        </div>
      )}
    </div>
  );
}
