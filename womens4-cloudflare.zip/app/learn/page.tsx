import { redirect } from 'next/navigation';

export default function LearnIndex() {
  redirect('/learn/introduction/what-is-python');
}
