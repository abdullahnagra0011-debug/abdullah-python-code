import { LessonSidebar, type SidebarModule } from '@/components/LessonSidebar';
import { getCurriculum } from '@/lib/content';
import { getViewer } from '@/lib/auth';
import { getProgress } from '@/lib/progress';
import { EXERCISES } from '@/content/exercises';

export const dynamic = 'force-dynamic';

export default async function LearnLayout({ children }: { children: React.ReactNode }) {
  const [modules, viewer] = await Promise.all([getCurriculum(), getViewer()]);
  const completed = viewer.user ? Array.from((await getProgress(viewer.user.id)).completed.keys()) : [];
  const sidebar: SidebarModule[] = modules.map((m) => ({
    slug: m.slug,
    title: m.title,
    number: m.number,
    free: m.free,
    stage: m.stage,
    hasExercises: Boolean(EXERCISES[m.slug]?.length) || !!m.custom,
    lessons: m.lessons.map((l) => ({ slug: l.slug, title: l.title })),
  }));

  return (
    <div className="mx-auto flex max-w-[1440px]">
      <LessonSidebar modules={sidebar} completed={completed} premium={viewer.premium} />
      <div className="min-w-0 flex-1">{children}</div>
    </div>
  );
}
