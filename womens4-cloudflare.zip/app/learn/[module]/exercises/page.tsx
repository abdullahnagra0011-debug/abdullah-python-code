import Link from 'next/link';
import { notFound } from 'next/navigation';
import { getCurriculum } from '@/lib/content';
import { getViewer } from '@/lib/auth';
import { canAccessModule } from '@/lib/access';
import { getQuestions } from '@/lib/exercises';
import { toPublic } from '@/lib/exercise-types';
import { getProgress } from '@/lib/progress';
import { ExerciseSet } from '@/components/ExerciseSet';
import { Paywall } from '@/components/Paywall';
import { ArrowRight } from 'lucide-react';

export async function generateMetadata({ params: paramsP }: { params: Promise<{ module: string }> }) {
  const params = await paramsP;
  const mod = (await getCurriculum()).find((m) => m.slug === params.module);
  return mod ? { title: `${mod.title} – Exercises & Quiz` } : {};
}

export default async function ExercisesPage({ params: paramsP }: { params: Promise<{ module: string }> }) {
  const params = await paramsP;
  const [modules, viewer] = await Promise.all([getCurriculum(), getViewer()]);
  const idx = modules.findIndex((m) => m.slug === params.module);
  const mod = modules[idx];
  if (!mod) notFound();
  const next = modules[idx + 1];
  const allowed = canAccessModule(mod, viewer.premium);
  const questions = allowed ? await getQuestions(mod.slug) : [];
  const best = viewer.user ? (await getProgress(viewer.user.id)).best.get(mod.slug) : undefined;

  return (
    <div className="mx-auto max-w-3xl px-5 pb-24 pt-8 sm:px-8 lg:pt-10">
      <p className="eyebrow">Module {mod.number} · Practice</p>
      <h1 className="mt-2 text-3xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-4xl">{mod.title}: Exercises & Quiz</h1>
      <p className="mt-3 text-slate-600 dark:text-slate-400">
        Answer each question and press <b>Check</b> for instant feedback. When you&apos;re done, submit to save your score. You need 70% in every module to earn a
        course certificate.
      </p>
      {best && (
        <p className="mt-3 inline-flex rounded-lg bg-brand-50 px-3 py-1.5 text-sm font-medium text-brand-800 dark:bg-brand-500/10 dark:text-brand-300">
          Your best score: {best.score}/{best.total} ({Math.round((best.score / best.total) * 100)}%)
        </p>
      )}

      <div className="mt-8">
        {!allowed ? (
          <Paywall title={`${mod.title} exercises`} signedIn={!!viewer.user} />
        ) : questions.length ? (
          <ExerciseSet moduleSlug={mod.slug} questions={questions.map(toPublic)} signedIn={!!viewer.user} />
        ) : (
          <p className="card p-6 text-slate-600">Exercises for this module are coming soon.</p>
        )}
      </div>

      {next && (
        <Link href={`/learn/${next.slug}/${next.lessons[0]?.slug ?? ''}`} className="card group mt-10 flex items-center justify-between p-5 hover:border-brand-300">
          <span>
            <span className="text-xs font-medium text-slate-500">Next module</span>
            <span className="block font-semibold text-slate-900 group-hover:text-brand-700 dark:text-white">
              {next.number}. {next.title}
            </span>
          </span>
          <ArrowRight className="h-5 w-5 text-brand-600" />
        </Link>
      )}
    </div>
  );
}
