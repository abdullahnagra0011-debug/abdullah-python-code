import { notFound, redirect } from 'next/navigation';
import { getModule } from '@/lib/content';

export default async function ModuleIndex({ params: paramsP }: { params: Promise<{ module: string }> }) {
  const params = await paramsP;
  const mod = await getModule(params.module);
  if (!mod || !mod.lessons.length) notFound();
  redirect(`/learn/${mod.slug}/${mod.lessons[0].slug}`);
}
