import Link from 'next/link';
import { notFound } from 'next/navigation';
import type { Metadata } from 'next';
import { ArrowLeft, ArrowRight, Download, Target } from 'lucide-react';
import { getCurriculum, flattenLessons, lessonKey, stripForPreview } from '@/lib/content';
import { getViewer } from '@/lib/auth';
import { canAccessModule } from '@/lib/access';
import { getProgress, moduleProgress } from '@/lib/progress';
import { Markdown } from '@/components/Markdown';
import { Paywall } from '@/components/Paywall';
import { CompleteButton } from '@/components/CompleteButton';
import { EXERCISES } from '@/content/exercises';

type Props = { params: Promise<{ module: string; lesson: string }> };

export async function generateMetadata({ params: paramsP }: Props): Promise<Metadata> {
  const params = await paramsP;
  const mods = await getCurriculum();
  const mod = mods.find((m) => m.slug === params.module);
  const lesson = mod?.lessons.find((l) => l.slug === params.lesson);
  if (!mod || !lesson) return {};
  return {
    title: `${lesson.title} – ${mod.title}`,
    description: mod.free ? stripForPreview(lesson.body, 155) : mod.description,
  };
}

export default async function LessonPage({ params: paramsP }: Props) {
  const params = await paramsP;
  const [modules, viewer] = await Promise.all([getCurriculum(), getViewer()]);
  const mod = modules.find((m) => m.slug === params.module);
  const lesson = mod?.lessons.find((l) => l.slug === params.lesson);
  if (!mod || !lesson) notFound();

  const all = flattenLessons(modules);
  const pos = all.findIndex((l) => l.moduleSlug === mod.slug && l.slug === lesson.slug);
  const prev = all[pos - 1];
  const next = all[pos + 1];
  const allowed = canAccessModule(mod, viewer.premium);
  const progress = viewer.user ? await getProgress(viewer.user.id) : null;
  const done = progress?.completed.has(lessonKey(mod.slug, lesson.slug)) ?? false;
  const mp = progress ? moduleProgress(mod, progress.completed) : { done: 0, total: mod.lessons.length, pct: 0 };
  const isLastInModule = lesson.index === mod.lessons.length - 1;
  const hasExercises = Boolean(EXERCISES[mod.slug]?.length) || !!mod.custom;

  return (
    <article className="mx-auto max-w-3xl px-5 pb-24 pt-8 sm:px-8 lg:pt-10">
      {/* breadcrumb + progress */}
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <nav className="flex items-center gap-2 text-sm text-slate-500">
          <Link href="/courses" className="hover:text-brand-700">
            Courses
          </Link>
          <span>/</span>
          <span className="font-medium text-slate-700 dark:text-slate-300">
            Module {mod.number}: {mod.title}
          </span>
        </nav>
        <div className="flex items-center gap-2 text-xs text-slate-500">
          <span>
            Lesson {lesson.index + 1} of {mod.lessons.length}
          </span>
          <div className="h-1.5 w-24 overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
            <div className="h-full rounded-full bg-brand-500" style={{ width: `${mp.pct}%` }} />
          </div>
        </div>
      </div>

      <div className="mb-2 flex flex-wrap items-center gap-2">
        {mod.free ? <span className="badge-green">Free lesson</span> : <span className="badge-amber">Premium</span>}
        <span className="badge-slate">{mod.stage}</span>
      </div>
      <h1 className="mb-8 text-3xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-4xl">{lesson.title}</h1>

      {/* top prev/next like W3Schools */}
      <PrevNext prev={prev} next={next} compact />

      {allowed ? (
        <>
          <Markdown source={lesson.body} />
          <div className="mt-12 flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-slate-200 bg-slate-50 p-5 dark:border-slate-800 dark:bg-slate-900/60">
            <div>
              <p className="font-semibold text-slate-900 dark:text-white">Finished this lesson?</p>
              <p className="text-sm text-slate-500">Mark it complete to track your progress and streak.</p>
            </div>
            <div className="flex flex-wrap gap-2">
              <CompleteButton moduleSlug={mod.slug} lessonSlug={lesson.slug} initiallyDone={done} signedIn={!!viewer.user} />
              {viewer.premium && (
                <a href={`/api/materials/${mod.slug}`} className="btn-secondary" download>
                  <Download className="h-4 w-4" /> Study guide
                </a>
              )}
            </div>
          </div>
          {isLastInModule && hasExercises && (
            <Link
              href={`/learn/${mod.slug}/exercises`}
              className="mt-6 flex items-center gap-4 rounded-2xl border-2 border-dashed border-brand-300 p-5 transition hover:border-brand-500 hover:bg-brand-50/60 dark:border-brand-800 dark:hover:bg-brand-500/5"
            >
              <span className="grid h-11 w-11 place-items-center rounded-xl bg-brand-600 text-white">
                <Target className="h-5 w-5" />
              </span>
              <span className="flex-1">
                <span className="block font-semibold text-slate-900 dark:text-white">Test yourself: {mod.title} exercises</span>
                <span className="text-sm text-slate-500">Quiz questions, fill-in-the-code and coding challenges with instant feedback.</span>
              </span>
              <ArrowRight className="h-5 w-5 text-brand-600" />
            </Link>
          )}
        </>
      ) : (
        <>
          <p className="lesson mb-8">{stripForPreview(lesson.body, 260)}</p>
          <Paywall title={mod.title} signedIn={!!viewer.user} />
        </>
      )}

      <div className="mt-12">
        <PrevNext prev={prev} next={next} />
      </div>
    </article>
  );
}

function PrevNext({
  prev,
  next,
  compact,
}: {
  prev?: { slug: string; title: string; moduleSlug: string };
  next?: { slug: string; title: string; moduleSlug: string };
  compact?: boolean;
}) {
  if (compact) {
    return (
      <div className="mb-8 flex justify-between gap-3">
        {prev ? (
          <Link href={`/learn/${prev.moduleSlug}/${prev.slug}`} className="btn-primary !py-2">
            <ArrowLeft className="h-4 w-4" /> Previous
          </Link>
        ) : (
          <span />
        )}
        {next && (
          <Link href={`/learn/${next.moduleSlug}/${next.slug}`} className="btn-primary !py-2">
            Next <ArrowRight className="h-4 w-4" />
          </Link>
        )}
      </div>
    );
  }
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      {prev ? (
        <Link href={`/learn/${prev.moduleSlug}/${prev.slug}`} className="card group p-4 transition hover:border-brand-300 hover:shadow-lift">
          <span className="flex items-center gap-1 text-xs font-medium text-slate-500">
            <ArrowLeft className="h-3.5 w-3.5" /> Previous
          </span>
          <span className="mt-1 block font-semibold text-slate-900 group-hover:text-brand-700 dark:text-white">{prev.title}</span>
        </Link>
      ) : (
        <span />
      )}
      {next && (
        <Link href={`/learn/${next.moduleSlug}/${next.slug}`} className="card group p-4 text-right transition hover:border-brand-300 hover:shadow-lift">
          <span className="flex items-center justify-end gap-1 text-xs font-medium text-slate-500">
            Next <ArrowRight className="h-3.5 w-3.5" />
          </span>
          <span className="mt-1 block font-semibold text-slate-900 group-hover:text-brand-700 dark:text-white">{next.title}</span>
        </Link>
      )}
    </div>
  );
}
