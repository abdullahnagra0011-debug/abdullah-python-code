import { NextResponse } from 'next/server';
import { getViewer } from '@/lib/auth';
import { getStripe } from '@/lib/stripe';
import { SITE_URL } from '@/lib/env';

export const runtime = 'nodejs';

/** Opens the Stripe Customer Portal (update card, invoices, cancel). */
export async function POST() {
  const viewer = await getViewer();
  if (!viewer.user) return NextResponse.redirect(`${SITE_URL}/login?next=/dashboard/billing`, 303);
  const customer = viewer.subscription?.stripe_customer_id;
  if (!customer) return NextResponse.redirect(`${SITE_URL}/pricing`, 303);
  try {
    const portal = await getStripe().billingPortal.sessions.create({
      customer,
      return_url: `${SITE_URL}/dashboard/billing`,
    });
    return NextResponse.redirect(portal.url, 303);
  } catch (e) {
    console.error('[portal]', e);
    return NextResponse.redirect(`${SITE_URL}/dashboard/billing?error=portal`, 303);
  }
}
