import { NextResponse } from 'next/server';
import { getViewer } from '@/lib/auth';
import { getStripe } from '@/lib/stripe';
import { getOrCreateCustomer } from '@/lib/billing';
import { SITE_URL, isStripeConfigured } from '@/lib/env';

export const runtime = 'nodejs';

/** Starts a Stripe Checkout session for the €6.99/month Premium plan. */
export async function POST() {
  const viewer = await getViewer();
  if (!viewer.user) return NextResponse.redirect(`${SITE_URL}/login?next=/pricing`, 303);
  if (!isStripeConfigured()) return NextResponse.redirect(`${SITE_URL}/pricing?error=stripe-not-configured`, 303);
  if (viewer.premium) return NextResponse.redirect(`${SITE_URL}/dashboard/billing`, 303);

  try {
    const customer = await getOrCreateCustomer(viewer.user.id, viewer.user.email);
    const session = await getStripe().checkout.sessions.create({
      mode: 'subscription',
      customer,
      client_reference_id: viewer.user.id,
      line_items: [{ price: process.env.STRIPE_PRICE_ID!, quantity: 1 }],
      subscription_data: { metadata: { user_id: viewer.user.id } },
      metadata: { user_id: viewer.user.id },
      allow_promotion_codes: true,
      billing_address_collection: 'auto',
      success_url: `${SITE_URL}/dashboard/billing?checkout=success`,
      cancel_url: `${SITE_URL}/pricing?checkout=canceled`,
    });
    if (!session.url) throw new Error('Stripe did not return a checkout URL');
    return NextResponse.redirect(session.url, 303);
  } catch (e) {
    console.error('[checkout]', e);
    return NextResponse.redirect(`${SITE_URL}/pricing?error=checkout-failed`, 303);
  }
}
