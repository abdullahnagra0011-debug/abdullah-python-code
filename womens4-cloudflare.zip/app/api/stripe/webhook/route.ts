import { NextResponse } from 'next/server';
import type Stripe from 'stripe';
import { getStripe, webCrypto } from '@/lib/stripe';
import { syncSubscription, userIdForCustomer, emailForUser } from '@/lib/billing';
import { createAdminClient } from '@/lib/supabase/admin';
import { emails, sendEmail } from '@/lib/email';
import { SITE_URL } from '@/lib/env';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * Stripe → database sync. Configure this endpoint in Stripe with the events:
 * checkout.session.completed, customer.subscription.created, customer.subscription.updated,
 * customer.subscription.deleted, invoice.paid, invoice.payment_failed
 */
export async function POST(req: Request) {
  const signature = req.headers.get('stripe-signature');
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!signature || !secret) return NextResponse.json({ error: 'Missing signature' }, { status: 400 });

  const raw = await req.text();
  let event: Stripe.Event;
  try {
    // Async + Web Crypto: required on Cloudflare Workers (no Node crypto.createHmac).
    event = await getStripe().webhooks.constructEventAsync(raw, signature, secret, undefined, webCrypto);
  } catch (e) {
    return NextResponse.json({ error: `Signature verification failed: ${(e as Error).message}` }, { status: 400 });
  }

  const stripe = getStripe();
  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        if (session.mode !== 'subscription' || !session.subscription) break;
        const subId = typeof session.subscription === 'string' ? session.subscription : session.subscription.id;
        const sub = await stripe.subscriptions.retrieve(subId);
        if (!sub.metadata?.user_id && session.client_reference_id) sub.metadata = { ...sub.metadata, user_id: session.client_reference_id };
        const { userId, row } = await syncSubscription(sub);
        if (row.status === 'active' || row.status === 'trialing') {
          const email = session.customer_details?.email ?? (await emailForUser(userId));
          const end = row.current_period_end ? new Date(row.current_period_end).toLocaleDateString('en-GB') : 'next month';
          if (email) await sendEmail(email, 'Your womens4.com Premium subscription is active', emails.subscriptionStarted(SITE_URL, end));
        }
        break;
      }
      case 'customer.subscription.created':
      case 'customer.subscription.updated': {
        await syncSubscription(event.data.object as Stripe.Subscription);
        break;
      }
      case 'customer.subscription.deleted': {
        const { userId } = await syncSubscription(event.data.object as Stripe.Subscription);
        const email = await emailForUser(userId);
        if (email) await sendEmail(email, 'Your womens4.com Premium subscription has ended', emails.subscriptionCanceled(SITE_URL));
        break;
      }
      case 'invoice.paid':
      case 'invoice.payment_failed': {
        const invoice = event.data.object as Stripe.Invoice;
        const customerId = typeof invoice.customer === 'string' ? invoice.customer : invoice.customer?.id;
        if (!customerId || !invoice.id) break;
        const userId = await userIdForCustomer(customerId);
        if (!userId) break;
        const paid = event.type === 'invoice.paid';
        await createAdminClient().from('payments').upsert({
          id: invoice.id,
          user_id: userId,
          amount: paid ? invoice.amount_paid : invoice.amount_due,
          currency: invoice.currency,
          status: paid ? 'paid' : 'failed',
          invoice_url: invoice.hosted_invoice_url ?? null,
          created_at: new Date(invoice.created * 1000).toISOString(),
        });
        if (!paid) {
          const email = invoice.customer_email ?? (await emailForUser(userId));
          if (email) await sendEmail(email, 'Action needed: your womens4.com payment failed', emails.paymentFailed(SITE_URL));
        }
        break;
      }
      default:
        break;
    }
  } catch (e) {
    console.error(`[webhook] ${event.type} failed`, e);
    // 500 makes Stripe retry the event later.
    return NextResponse.json({ error: 'Handler failed' }, { status: 500 });
  }
  return NextResponse.json({ received: true });
}
