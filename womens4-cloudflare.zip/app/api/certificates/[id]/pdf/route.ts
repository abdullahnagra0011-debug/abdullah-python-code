import { NextResponse } from 'next/server';
import { getCertificate, renderCertificatePdf } from '@/lib/certificates';

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const cert = await getCertificate(id);
  if (!cert || cert.revoked) return NextResponse.json({ error: 'Certificate not found' }, { status: 404 });
  const bytes = await renderCertificatePdf(cert);
  return new NextResponse(bytes as unknown as BodyInit, {
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="womens4-certificate-${cert.course_slug}.pdf"`,
    },
  });
}
