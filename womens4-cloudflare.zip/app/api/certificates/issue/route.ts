import { NextResponse } from 'next/server';
import { getViewer } from '@/lib/auth';
import { getCourse } from '@/content/courses';
import { getCurriculum } from '@/lib/content';
import { getProgress, courseStatus } from '@/lib/progress';
import { createAdminClient } from '@/lib/supabase/admin';
import { SITE_URL } from '@/lib/env';

export const runtime = 'nodejs';

/** Issues a certificate only after all course criteria are verified on the server. */
export async function POST(req: Request) {
  const form = await req.formData().catch(() => null);
  const courseSlug = String(form?.get('course') ?? '');
  const viewer = await getViewer();
  if (!viewer.user) return NextResponse.redirect(`${SITE_URL}/login?next=/dashboard`, 303);

  const course = getCourse(courseSlug);
  if (!course) return NextResponse.redirect(`${SITE_URL}/dashboard?cert=unknown-course`, 303);
  if (!viewer.premium) return NextResponse.redirect(`${SITE_URL}/pricing?reason=certificates`, 303);

  const [modules, progress] = await Promise.all([getCurriculum(), getProgress(viewer.user.id)]);
  const status = courseStatus(course, modules, progress);
  if (!status.eligible) return NextResponse.redirect(`${SITE_URL}/dashboard?cert=not-eligible`, 303);

  const name = (viewer.profile?.full_name || '').trim();
  if (!name) return NextResponse.redirect(`${SITE_URL}/dashboard/profile?need=name`, 303);

  const admin = createAdminClient();
  const { data: existing } = await admin
    .from('certificates')
    .select('id')
    .eq('user_id', viewer.user.id)
    .eq('course_slug', course.slug)
    .maybeSingle();
  if (existing) return NextResponse.redirect(`${SITE_URL}/certificates/${existing.id}`, 303);

  const { data, error } = await admin
    .from('certificates')
    .insert({ user_id: viewer.user.id, course_slug: course.slug, recipient_name: name })
    .select('id')
    .single();
  if (error || !data) return NextResponse.redirect(`${SITE_URL}/dashboard?cert=error`, 303);
  return NextResponse.redirect(`${SITE_URL}/certificates/${data.id}`, 303);
}
