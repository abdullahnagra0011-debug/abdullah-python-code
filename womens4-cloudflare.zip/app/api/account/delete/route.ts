import { NextResponse } from 'next/server';
import { getViewer } from '@/lib/auth';
import { getStripe } from '@/lib/stripe';
import { createAdminClient } from '@/lib/supabase/admin';
import { createClient } from '@/lib/supabase/server';
import { SITE_URL } from '@/lib/env';

export const runtime = 'nodejs';

/** GDPR Art. 17 – cancel any subscription and permanently delete the account. */
export async function POST(req: Request) {
  const form = await req.formData().catch(() => null);
  if (String(form?.get('confirm') ?? '') !== 'DELETE') {
    return NextResponse.redirect(`${SITE_URL}/dashboard/profile?error=confirm`, 303);
  }
  const viewer = await getViewer();
  if (!viewer.user) return NextResponse.redirect(`${SITE_URL}/login`, 303);

  try {
    const subId = viewer.subscription?.stripe_subscription_id;
    if (subId && ['active', 'trialing', 'past_due', 'unpaid'].includes(viewer.subscription!.status)) {
      await getStripe().subscriptions.cancel(subId);
    }
    // Cascades to profile, progress, results, certificates, payments, subscriptions.
    const { error } = await createAdminClient().auth.admin.deleteUser(viewer.user.id);
    if (error) throw error;
    await (await createClient()).auth.signOut();
  } catch (e) {
    console.error('[account/delete]', e);
    return NextResponse.redirect(`${SITE_URL}/dashboard/profile?error=delete-failed`, 303);
  }
  return NextResponse.redirect(`${SITE_URL}/?account=deleted`, 303);
}
