import { NextResponse } from 'next/server';
import { getViewer } from '@/lib/auth';
import { getModule, lessonKey } from '@/lib/content';
import { canAccessModule } from '@/lib/access';
import { createClient } from '@/lib/supabase/server';

export async function POST(req: Request) {
  const viewer = await getViewer();
  if (!viewer.user) return NextResponse.json({ error: 'Please log in to save progress.' }, { status: 401 });

  const body = await req.json().catch(() => null);
  const moduleSlug = String(body?.moduleSlug ?? '');
  const lessonSlug = String(body?.lessonSlug ?? '');
  const completed = Boolean(body?.completed);

  const mod = await getModule(moduleSlug);
  const lesson = mod?.lessons.find((l) => l.slug === lessonSlug);
  if (!mod || !lesson) return NextResponse.json({ error: 'Lesson not found' }, { status: 404 });
  if (!canAccessModule(mod, viewer.premium)) return NextResponse.json({ error: 'Premium required' }, { status: 403 });

  const sb = (await createClient());
  const key = lessonKey(moduleSlug, lessonSlug);
  const { error } = completed
    ? await sb.from('lesson_progress').upsert({ user_id: viewer.user.id, lesson_key: key }, { onConflict: 'user_id,lesson_key', ignoreDuplicates: true })
    : await sb.from('lesson_progress').delete().eq('user_id', viewer.user.id).eq('lesson_key', key);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true, completed });
}
