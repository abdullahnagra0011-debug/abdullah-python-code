import { NextResponse } from 'next/server';
import { getViewer } from '@/lib/auth';
import { getModule } from '@/lib/content';
import { canAccessModule } from '@/lib/access';
import { getQuestions } from '@/lib/exercises';
import { gradeAnswer } from '@/lib/exercise-types';
import { createAdminClient } from '@/lib/supabase/admin';

/** Grades the whole set on the server and stores the score. */
export async function POST(req: Request) {
  const viewer = await getViewer();
  if (!viewer.user) return NextResponse.json({ error: 'Log in to save your score.' }, { status: 401 });

  const body = await req.json().catch(() => null);
  const moduleSlug = String(body?.moduleSlug ?? '');
  const answers: Record<string, unknown> = body?.answers ?? {};
  const mod = await getModule(moduleSlug);
  if (!mod) return NextResponse.json({ error: 'Module not found' }, { status: 404 });
  if (!canAccessModule(mod, viewer.premium)) return NextResponse.json({ error: 'Premium required' }, { status: 403 });

  const questions = await getQuestions(moduleSlug);
  if (!questions.length) return NextResponse.json({ error: 'No exercises' }, { status: 404 });
  const score = questions.reduce((n, q, i) => n + (gradeAnswer(q, answers[String(i)]) ? 1 : 0), 0);

  try {
    const admin = createAdminClient();
    const { error } = await admin
      .from('exercise_results')
      .insert({ user_id: viewer.user.id, module_slug: moduleSlug, score, total: questions.length });
    if (error) throw error;
  } catch (e) {
    return NextResponse.json({ error: `Score could not be saved: ${(e as Error).message}` }, { status: 500 });
  }
  return NextResponse.json({ ok: true, score, total: questions.length });
}
