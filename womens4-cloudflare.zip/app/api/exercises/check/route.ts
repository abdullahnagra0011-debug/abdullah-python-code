import { NextResponse } from 'next/server';
import { getViewer } from '@/lib/auth';
import { getModule } from '@/lib/content';
import { canAccessModule } from '@/lib/access';
import { getQuestions } from '@/lib/exercises';
import { gradeAnswer } from '@/lib/exercise-types';

/** Instant feedback for one question. Answers never leave the server until checked. */
export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const moduleSlug = String(body?.moduleSlug ?? '');
  const index = Number(body?.index);
  const mod = await getModule(moduleSlug);
  if (!mod) return NextResponse.json({ error: 'Module not found' }, { status: 404 });

  const viewer = await getViewer();
  if (!canAccessModule(mod, viewer.premium)) return NextResponse.json({ error: 'Premium required' }, { status: 403 });

  const questions = await getQuestions(moduleSlug);
  const q = questions[index];
  if (!q) return NextResponse.json({ error: 'Question not found' }, { status: 404 });

  const correct = gradeAnswer(q, body?.answer);
  const correctAnswer = q.type === 'mcq' ? q.options[q.answer] : q.type === 'fill' ? q.answer[0] : null;
  return NextResponse.json({ correct, explanation: q.explain, correctAnswer });
}
