'use client';
import Link from 'next/link';
import { useState } from 'react';
import { Loader2 } from 'lucide-react';
import { createClient, supabaseConfigured } from '@/lib/supabase/client';
import { AuthShell, FormMessage, NotConfigured } from '@/components/AuthShell';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    const { error } = await createClient().auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/auth/callback?next=/update-password`,
    });
    setLoading(false);
    if (error) return setError(error.message);
    setSent(true);
  };

  return (
    <AuthShell title="Reset your password" subtitle="We'll email you a secure link to choose a new password.">
      {!supabaseConfigured ? (
        <NotConfigured />
      ) : sent ? (
        <FormMessage type="success">If an account exists for {email}, a reset link is on its way. The link is valid for a limited time.</FormMessage>
      ) : (
        <form onSubmit={submit} className="space-y-5">
          {error && <FormMessage type="error">{error}</FormMessage>}
          <div>
            <label htmlFor="email" className="label">
              Email
            </label>
            <input id="email" type="email" required autoComplete="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <button className="btn-primary w-full" disabled={loading}>
            {loading && <Loader2 className="h-4 w-4 animate-spin" />} Send reset link
          </button>
          <p className="text-center text-sm">
            <Link href="/login" className="font-medium text-brand-700 dark:text-brand-400">
              Back to log in
            </Link>
          </p>
        </form>
      )}
    </AuthShell>
  );
}
