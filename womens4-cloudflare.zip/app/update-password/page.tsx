'use client';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { Loader2 } from 'lucide-react';
import { createClient, supabaseConfigured } from '@/lib/supabase/client';
import { AuthShell, FormMessage, NotConfigured } from '@/components/AuthShell';

export default function UpdatePasswordPage() {
  const router = useRouter();
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 8) return setError('Use at least 8 characters.');
    if (password !== confirm) return setError('The passwords do not match.');
    setLoading(true);
    setError('');
    const { error } = await createClient().auth.updateUser({ password });
    setLoading(false);
    if (error) return setError(error.message.includes('session') ? 'Your reset link has expired. Request a new one.' : error.message);
    setDone(true);
    setTimeout(() => router.push('/dashboard'), 1500);
  };

  return (
    <AuthShell title="Choose a new password">
      {!supabaseConfigured ? (
        <NotConfigured />
      ) : done ? (
        <FormMessage type="success">Password updated. Taking you to your dashboard…</FormMessage>
      ) : (
        <form onSubmit={submit} className="space-y-5">
          {error && <FormMessage type="error">{error}</FormMessage>}
          <div>
            <label htmlFor="pw" className="label">
              New password
            </label>
            <input id="pw" type="password" minLength={8} required autoComplete="new-password" className="input" value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          <div>
            <label htmlFor="pw2" className="label">
              Confirm new password
            </label>
            <input id="pw2" type="password" required autoComplete="new-password" className="input" value={confirm} onChange={(e) => setConfirm(e.target.value)} />
          </div>
          <button className="btn-primary w-full" disabled={loading}>
            {loading && <Loader2 className="h-4 w-4 animate-spin" />} Update password
          </button>
        </form>
      )}
    </AuthShell>
  );
}
