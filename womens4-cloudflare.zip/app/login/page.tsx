'use client';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { Suspense, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { createClient, supabaseConfigured } from '@/lib/supabase/client';
import { AuthShell, FormMessage, NotConfigured } from '@/components/AuthShell';

function LoginForm() {
  const params = useSearchParams();
  const router = useRouter();
  const nextRaw = params.get('next') || '/dashboard';
  const next = nextRaw.startsWith('/') && !nextRaw.startsWith('//') ? nextRaw : '/dashboard';
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(params.get('error') === 'link-expired' ? 'That link has expired. Please request a new one.' : '');
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    const { error } = await createClient().auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) {
      setError(error.message === 'Invalid login credentials' ? 'Wrong email or password.' : error.message);
      return;
    }
    router.push(next);
    router.refresh();
  };

  return (
    <AuthShell
      title="Welcome back"
      subtitle={
        <>
          New to womens4.com?{' '}
          <Link href={`/register?next=${encodeURIComponent(next)}`} className="font-semibold text-brand-700 dark:text-brand-400">
            Create a free account
          </Link>
        </>
      }
    >
      {!supabaseConfigured ? (
        <NotConfigured />
      ) : (
        <form onSubmit={submit} className="space-y-5">
          {error && <FormMessage type="error">{error}</FormMessage>}
          <div>
            <label htmlFor="email" className="label">
              Email
            </label>
            <input id="email" type="email" required autoComplete="email" className="input" placeholder="you@gmail.com" value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div>
            <div className="flex items-center justify-between">
              <label htmlFor="password" className="label">
                Password
              </label>
              <Link href="/forgot-password" className="mb-1.5 text-xs font-medium text-brand-700 dark:text-brand-400">
                Forgot password?
              </Link>
            </div>
            <input
              id="password"
              type="password"
              required
              autoComplete="current-password"
              className="input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <button className="btn-primary w-full" disabled={loading}>
            {loading && <Loader2 className="h-4 w-4 animate-spin" />} Log in
          </button>
        </form>
      )}
    </AuthShell>
  );
}

export default function LoginPage() {
  return (
    <Suspense>
      <LoginForm />
    </Suspense>
  );
}
