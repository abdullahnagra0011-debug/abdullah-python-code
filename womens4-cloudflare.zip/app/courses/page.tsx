import Link from 'next/link';
import { ArrowRight, CheckCircle2, Lock, Clock, Layers } from 'lucide-react';
import { COURSES } from '@/content/courses';
import { getCurriculum } from '@/lib/content';
import { getViewer } from '@/lib/auth';
import { getProgress, moduleProgress } from '@/lib/progress';

export const metadata = { title: 'Python Courses & Full Curriculum' };

export default async function CoursesPage() {
  const [modules, viewer] = await Promise.all([getCurriculum(), getViewer()]);
  const progress = viewer.user ? await getProgress(viewer.user.id) : null;
  const custom = modules.filter((m) => m.custom);

  return (
    <div className="container py-14">
      <div className="max-w-2xl">
        <p className="eyebrow">Curriculum</p>
        <h1 className="mt-2 text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-5xl">Python courses</h1>
        <p className="section-sub">
          {modules.length} modules and {modules.reduce((n, m) => n + m.lessons.length, 0)} lessons that take you from your very first line of code to a job-ready
          developer. Modules marked <span className="badge-green">Free</span> are open to everyone.
        </p>
      </div>

      <div className="mt-12 space-y-16">
        {COURSES.map((c) => {
          const mods = c.modules.map((s) => modules.find((m) => m.slug === s)).filter(Boolean) as typeof modules;
          // The job-ready course shows only the extra modules to avoid repeating the list.
          const shown = c.slug === 'job-ready-python-developer' ? mods.filter((m) => m.stage === 'Professional') : mods;
          return (
            <section key={c.slug} id={c.slug} className="scroll-mt-24">
              <div className="flex flex-wrap items-end justify-between gap-4 border-b border-slate-200 pb-5 dark:border-slate-800">
                <div className="max-w-2xl">
                  <span className={c.level === 'Beginner' ? 'badge-green' : 'badge-slate'}>{c.level}</span>
                  <h2 className="mt-2 text-2xl font-bold text-slate-900 dark:text-white">{c.title}</h2>
                  <p className="mt-1 text-slate-600 dark:text-slate-400">{c.description}</p>
                </div>
                <div className="flex gap-4 text-sm text-slate-500">
                  <span className="flex items-center gap-1.5">
                    <Layers className="h-4 w-4" /> {c.modules.length} modules
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Clock className="h-4 w-4" /> ~{c.hours} h
                  </span>
                </div>
              </div>
              {c.slug === 'job-ready-python-developer' && (
                <p className="mt-4 text-sm text-slate-500">Includes every module above, plus these professional modules:</p>
              )}
              <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {shown.map((m) => {
                  const mp = progress ? moduleProgress(m, progress.completed) : null;
                  const locked = !m.free && !viewer.premium;
                  return (
                    <Link
                      key={m.slug}
                      href={`/learn/${m.slug}/${m.lessons[0]?.slug ?? ''}`}
                      className="card group flex flex-col p-5 transition hover:-translate-y-0.5 hover:border-brand-300 hover:shadow-lift"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-400">MODULE {m.number}</span>
                        {m.free ? (
                          <span className="badge-green">Free</span>
                        ) : locked ? (
                          <span className="badge-amber">
                            <Lock className="h-3 w-3" /> Premium
                          </span>
                        ) : (
                          <span className="badge-slate">Premium</span>
                        )}
                      </div>
                      <h3 className="mt-2 font-semibold text-slate-900 group-hover:text-brand-700 dark:text-white">{m.title}</h3>
                      <p className="mt-1 line-clamp-2 flex-1 text-sm text-slate-600 dark:text-slate-400">{m.description}</p>
                      <div className="mt-4 flex items-center gap-2 text-xs text-slate-500">
                        {mp && mp.pct === 100 ? <CheckCircle2 className="h-4 w-4 text-brand-500" /> : null}
                        <span>{m.lessons.length} lessons</span>
                        {mp && mp.done > 0 && (
                          <>
                            <div className="ml-2 h-1.5 flex-1 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                              <div className="h-full bg-brand-500" style={{ width: `${mp.pct}%` }} />
                            </div>
                            <span>{mp.pct}%</span>
                          </>
                        )}
                        {!mp?.done && <ArrowRight className="ml-auto h-4 w-4 text-brand-600 opacity-0 transition group-hover:opacity-100" />}
                      </div>
                    </Link>
                  );
                })}
              </div>
            </section>
          );
        })}
        {custom.length > 0 && (
          <section>
            <h2 className="border-b border-slate-200 pb-4 text-2xl font-bold dark:border-slate-800">New content</h2>
            <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {custom.map((m) => (
                <Link key={m.slug} href={`/learn/${m.slug}/${m.lessons[0].slug}`} className="card p-5 hover:border-brand-300">
                  <h3 className="font-semibold">{m.title}</h3>
                  <p className="mt-1 text-sm text-slate-500">{m.description}</p>
                </Link>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
