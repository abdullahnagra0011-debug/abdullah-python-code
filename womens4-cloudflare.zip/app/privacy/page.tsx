import { LegalPage } from '@/components/LegalPage';
import { COMPANY_ADDRESS, COMPANY_NAME, SUPPORT_EMAIL } from '@/lib/env';

export const metadata = { title: 'Privacy Policy' };

export default function Privacy() {
  const md = `
## 1. Who we are
The controller responsible for your personal data is **${COMPANY_NAME}**, ${COMPANY_ADDRESS} ("womens4.com", "we"). Contact: [${SUPPORT_EMAIL}](mailto:${SUPPORT_EMAIL}).

## 2. What data we process and why

| Data | Purpose | Legal basis (GDPR) |
|---|---|---|
| Email, password (hashed), name | Creating and securing your account, certificates | Art. 6(1)(b) – contract |
| Lesson progress, exercise scores, streaks | Providing the learning service and dashboard | Art. 6(1)(b) – contract |
| Subscription status, invoices | Billing and accounting obligations | Art. 6(1)(b) and (c) – contract, legal obligation |
| Technical logs (IP address, browser) | Security and abuse prevention | Art. 6(1)(f) – legitimate interest |
| Marketing email preference | Optional newsletters, only if you opt in | Art. 6(1)(a) – consent |

**Code you run in the editor** is executed entirely in your own browser (Pyodide). It is not sent to or stored on our servers.

## 3. Processors
We use carefully selected service providers under data processing agreements:
- **Supabase** – database and authentication hosting.
- **Stripe** – payment processing. Card details go directly to Stripe; we never see or store them.
- **Vercel** – website hosting.
- **Resend** (if enabled) – sending transactional emails.
- **jsDelivr CDN** – delivers the in-browser Python runtime and code editor files.

Some providers may process data outside the EU/EEA. In that case transfers are protected by the EU Standard Contractual Clauses or an adequacy decision.

## 4. Retention
Account data is kept while your account exists. When you delete your account, we delete your profile, progress, scores and certificates immediately. Invoice records are kept by Stripe and us for the period required by tax law (typically up to 10 years).

## 5. Your rights
You have the right to access, rectify, erase, restrict and object to processing, and to data portability. You can withdraw consent at any time.
- **Download your data:** Dashboard → Profile & privacy → "Download my data".
- **Delete your account:** Dashboard → Profile & privacy → "Delete account".
- For anything else, email [${SUPPORT_EMAIL}](mailto:${SUPPORT_EMAIL}).

You may also lodge a complaint with your local data protection supervisory authority.

## 6. Cookies
We only use strictly necessary cookies and browser storage. See our [Cookie Policy](/cookies).

## 7. Children
womens4.com is intended for users aged 16 and over. Younger users need the consent of a parent or guardian.

## 8. Changes
We will announce material changes to this policy by email or on the website.
`;
  return <LegalPage title="Privacy Policy" updated="31 October 2026" source={md} />;
}
