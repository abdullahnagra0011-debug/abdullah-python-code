import Link from 'next/link';
import {
  ArrowRight,
  BookOpen,
  Briefcase,
  Code2,
  Cpu,
  Database,
  GraduationCap,
  LineChart,
  MousePointerClick,
  PlayCircle,
  Rocket,
  Sparkles,
  Target,
  Trophy,
  Users,
  Globe,
  Quote,
} from 'lucide-react';
import { COURSES } from '@/content/courses';
import { getCurriculum } from '@/lib/content';
import { getViewer } from '@/lib/auth';
import { DemoEditor } from '@/components/DemoEditor';
import { PricingCards } from '@/components/PricingCards';
import { Faq } from '@/components/Faq';

export default async function Home() {
  const [modules, viewer] = await Promise.all([getCurriculum(), getViewer()]);
  const lessonCount = modules.reduce((n, m) => n + m.lessons.length, 0);

  return (
    <>
      {/* ─── Hero ─────────────────────────────── */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0 -z-10 bg-[radial-gradient(60rem_30rem_at_70%_-10%,rgba(18,183,106,.12),transparent)] dark:bg-[radial-gradient(60rem_30rem_at_70%_-10%,rgba(18,183,106,.18),transparent)]" />
        <div className="pointer-events-none absolute inset-0 -z-10 bg-[linear-gradient(to_right,rgba(148,163,184,.08)_1px,transparent_1px),linear-gradient(to_bottom,rgba(148,163,184,.08)_1px,transparent_1px)] bg-[size:44px_44px] [mask-image:radial-gradient(ellipse_at_top,black,transparent_70%)]" />
        <div className="container grid items-center gap-14 py-16 sm:py-24 lg:grid-cols-[1.05fr_1fr]">
          <div className="animate-fade-up">
            <span className="badge-green mb-5 !px-3 !py-1">
              <Sparkles className="h-3.5 w-3.5" /> From zero to job-ready Python developer
            </span>
            <h1 className="text-5xl font-extrabold leading-[1.05] tracking-tight text-slate-900 dark:text-white sm:text-6xl">
              Learn Python.
              <br />
              <span className="bg-gradient-to-r from-brand-600 to-emerald-500 bg-clip-text text-transparent">Build Your Future.</span>
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-8 text-slate-600 dark:text-slate-400">
              Start learning Python from zero with interactive lessons, practical exercises, and real-world projects.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link href={viewer.user ? '/dashboard' : '/register'} className="btn-primary btn-lg">
                Start Learning for Free <ArrowRight className="h-5 w-5" />
              </Link>
              <Link href="/courses" className="btn-secondary btn-lg">
                Explore Python Courses
              </Link>
            </div>
            <dl className="mt-10 grid max-w-md grid-cols-3 gap-6">
              {[
                [String(modules.length), 'modules'],
                [`${lessonCount}+`, 'lessons'],
                ['0', 'installs needed'],
              ].map(([v, l]) => (
                <div key={l}>
                  <dt className="text-2xl font-bold text-slate-900 dark:text-white">{v}</dt>
                  <dd className="text-sm text-slate-500">{l}</dd>
                </div>
              ))}
            </dl>
          </div>

          {/* code editor visual */}
          <div className="relative animate-fade-up [animation-delay:120ms]">
            <div className="absolute -inset-4 -z-10 rounded-[2rem] bg-gradient-to-br from-brand-200/60 to-transparent blur-2xl dark:from-brand-500/20" />
            <div className="overflow-hidden rounded-2xl border border-slate-800 bg-slate-950 shadow-2xl">
              <div className="flex items-center justify-between border-b border-slate-800 px-4 py-3">
                <div className="flex gap-1.5">
                  <span className="h-3 w-3 rounded-full bg-red-400" />
                  <span className="h-3 w-3 rounded-full bg-amber-400" />
                  <span className="h-3 w-3 rounded-full bg-brand-400" />
                </div>
                <span className="font-mono text-xs text-slate-400">first_program.py</span>
                <span className="flex items-center gap-1 rounded-md bg-brand-600 px-2 py-1 text-[11px] font-semibold text-white">
                  <PlayCircle className="h-3 w-3" /> Run
                </span>
              </div>
              <pre className="overflow-x-auto p-5 font-mono text-[13.5px] leading-7 text-slate-300">
                <code>
                  <span className="text-slate-500"># Your journey starts with one line</span>
                  {'\n'}
                  <span className="text-sky-300">def</span> <span className="text-amber-200">greet</span>(name):
                  {'\n'}
                  {'    '}
                  <span className="text-sky-300">return</span> <span className="text-brand-300">f&quot;Hello, {'{'}name{'}'}! Ready to code?&quot;</span>
                  {'\n\n'}
                  goals = [<span className="text-brand-300">&quot;learn&quot;</span>, <span className="text-brand-300">&quot;build&quot;</span>,{' '}
                  <span className="text-brand-300">&quot;get hired&quot;</span>]{'\n'}
                  <span className="text-sky-300">for</span> step, goal <span className="text-sky-300">in</span> <span className="text-amber-200">enumerate</span>(goals, 1):
                  {'\n'}
                  {'    '}
                  <span className="text-amber-200">print</span>(step, goal.title())
                  {'\n\n'}
                  <span className="text-amber-200">print</span>(greet(<span className="text-brand-300">&quot;you&quot;</span>))
                </code>
              </pre>
              <div className="border-t border-slate-800 bg-black/40 px-5 py-4 font-mono text-[13px] leading-6">
                <p className="mb-1 text-[11px] uppercase tracking-wider text-slate-500">Output</p>
                <p className="text-slate-200">1 Learn</p>
                <p className="text-slate-200">2 Build</p>
                <p className="text-slate-200">3 Get Hired</p>
                <p className="text-brand-300">
                  Hello, you! Ready to code?<span className="ml-0.5 inline-block h-4 w-2 translate-y-0.5 animate-blink bg-brand-400" />
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ─── Why Python ─────────────────────── */}
      <section className="border-y border-slate-200 bg-slate-50 py-20 dark:border-slate-800 dark:bg-slate-900/40">
        <div className="container">
          <div className="mx-auto max-w-2xl text-center">
            <p className="eyebrow">Why learn Python?</p>
            <h2 className="section-title mt-2">The most beginner-friendly language is also one of the most in-demand</h2>
            <p className="section-sub">Python reads almost like English, and it powers everything from websites to artificial intelligence.</p>
          </div>
          <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {[
              [BookOpen, 'Easy to read and write', 'Clean syntax with no curly braces or semicolons – you focus on solving problems, not on punctuation.'],
              [Briefcase, 'Great career prospects', 'Python is used by startups and the largest tech companies alike for backend, automation, data and AI roles.'],
              [Cpu, 'AI & machine learning', 'The leading libraries for AI, from NumPy to PyTorch, are written for Python first.'],
              [Globe, 'Web development', 'Build APIs and websites with Flask, FastAPI and Django.'],
              [LineChart, 'Data analysis', 'Clean, analyse and visualise data with pandas and Matplotlib.'],
              [Rocket, 'Automate boring tasks', 'Rename files, fill spreadsheets, scrape websites and send reports – automatically.'],
            ].map(([Icon, title, text]: any) => (
              <div key={title} className="card p-6 transition hover:-translate-y-0.5 hover:shadow-lift">
                <span className="grid h-11 w-11 place-items-center rounded-xl bg-brand-50 text-brand-600 dark:bg-brand-500/10 dark:text-brand-400">
                  <Icon className="h-5 w-5" />
                </span>
                <h3 className="mt-4 font-semibold text-slate-900 dark:text-white">{title}</h3>
                <p className="mt-1.5 text-sm leading-6 text-slate-600 dark:text-slate-400">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── How it works ───────────────────── */}
      <section className="py-20">
        <div className="container">
          <div className="mx-auto max-w-2xl text-center">
            <p className="eyebrow">How it works</p>
            <h2 className="section-title mt-2">Learn by doing, one small step at a time</h2>
          </div>
          <ol className="mt-14 grid gap-6 md:grid-cols-4">
            {[
              [BookOpen, 'Read', 'Short lessons in plain English with clear examples.'],
              [MousePointerClick, 'Try it yourself', 'Edit every example and run it instantly in your browser.'],
              [Target, 'Practise', 'Quizzes, fill-in-the-code and coding challenges with instant feedback.'],
              [Trophy, 'Build & certify', 'Ship real projects, track your streak and earn certificates.'],
            ].map(([Icon, title, text]: any, i) => (
              <li key={title} className="relative text-center">
                <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-brand-600 text-white shadow-lg shadow-brand-600/20">
                  <Icon className="h-6 w-6" />
                </span>
                <span className="mt-4 block text-xs font-bold uppercase tracking-wider text-brand-600">Step {i + 1}</span>
                <h3 className="mt-1 text-lg font-semibold text-slate-900 dark:text-white">{title}</h3>
                <p className="mt-1 text-sm leading-6 text-slate-600 dark:text-slate-400">{text}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* ─── Popular courses ────────────────── */}
      <section className="border-y border-slate-200 bg-slate-50 py-20 dark:border-slate-800 dark:bg-slate-900/40">
        <div className="container">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="eyebrow">Popular Python courses</p>
              <h2 className="section-title mt-2">A clear path from beginner to professional</h2>
            </div>
            <Link href="/courses" className="btn-secondary">
              See full curriculum <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="mt-10 grid gap-6 lg:grid-cols-3">
            {COURSES.map((c, i) => {
              const Icon = [Code2, Database, GraduationCap][i];
              const first = modules.find((m) => m.slug === c.modules[0]);
              return (
                <Link key={c.slug} href={`/courses#${c.slug}`} className="card group flex flex-col p-6 transition hover:-translate-y-1 hover:border-brand-300 hover:shadow-lift">
                  <div className="flex items-center justify-between">
                    <span className="grid h-12 w-12 place-items-center rounded-xl bg-slate-900 text-white dark:bg-white dark:text-slate-900">
                      <Icon className="h-6 w-6" />
                    </span>
                    <span className={c.level === 'Beginner' ? 'badge-green' : 'badge-slate'}>{c.level}</span>
                  </div>
                  <h3 className="mt-5 text-xl font-bold text-slate-900 group-hover:text-brand-700 dark:text-white">{c.title}</h3>
                  <p className="mt-2 flex-1 text-sm leading-6 text-slate-600 dark:text-slate-400">{c.description}</p>
                  <div className="mt-5 flex items-center gap-4 border-t border-slate-100 pt-4 text-xs font-medium text-slate-500 dark:border-slate-800">
                    <span>{c.modules.length} modules</span>
                    <span>~{c.hours} hours</span>
                    <span className="ml-auto flex items-center gap-1 text-brand-700 dark:text-brand-400">
                      Start with {first?.title ?? 'lesson 1'} <ArrowRight className="h-3.5 w-3.5" />
                    </span>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* ─── Interactive demo ───────────────── */}
      <section className="py-20">
        <div className="container grid items-center gap-12 lg:grid-cols-[0.9fr_1.1fr]">
          <div>
            <p className="eyebrow">Interactive coding</p>
            <h2 className="section-title mt-2">Write real Python right here – no setup</h2>
            <p className="section-sub">
              Every lesson has a “Try it Yourself” editor powered by a full Python interpreter running safely in your browser. Change the code on the right and press{' '}
              <b>Run</b>.
            </p>
            <ul className="mt-6 space-y-3 text-slate-700 dark:text-slate-300">
              {['Professional code editor with syntax highlighting', 'Instant output and readable error messages', 'Works on laptop, tablet and phone'].map((t) => (
                <li key={t} className="flex items-center gap-3">
                  <span className="grid h-6 w-6 place-items-center rounded-full bg-brand-100 text-brand-700 dark:bg-brand-500/20 dark:text-brand-300">✓</span>
                  {t}
                </li>
              ))}
            </ul>
          </div>
          <DemoEditor />
        </div>
      </section>

      {/* ─── Pricing ────────────────────────── */}
      <section id="pricing" className="border-y border-slate-200 bg-slate-50 py-20 dark:border-slate-800 dark:bg-slate-900/40">
        <div className="container">
          <div className="mx-auto mb-14 max-w-2xl text-center">
            <p className="eyebrow">Free vs Premium</p>
            <h2 className="section-title mt-2">Start free. Upgrade when you&apos;re ready.</h2>
            <p className="section-sub">One simple plan. No hidden fees. Cancel anytime.</p>
          </div>
          <PricingCards signedIn={!!viewer.user} premiumActive={viewer.premium} />
        </div>
      </section>

      {/* ─── Testimonials (sample) ──────────── */}
      <section className="py-20">
        <div className="container">
          <div className="mx-auto max-w-2xl text-center">
            <p className="eyebrow">Student stories</p>
            <h2 className="section-title mt-2">What learning with womens4.com feels like</h2>
            <p className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-amber-50 px-3 py-1 text-xs font-semibold text-amber-800 dark:bg-amber-500/10 dark:text-amber-300">
              <Users className="h-3.5 w-3.5" /> Sample testimonials – placeholders until real student reviews are collected
            </p>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {[
              ['Sample Student A', 'Career switcher', 'I had never written code. The tiny steps and “Try it Yourself” buttons made it click – I finished the fundamentals in five weeks.'],
              ['Sample Student B', 'University student', 'The exercises explain why my answer was wrong, which helped me far more than just seeing a red cross.'],
              ['Sample Student C', 'Junior developer', 'The Git, testing and FastAPI modules filled exactly the gaps I had before my first technical interview.'],
            ].map(([name, role, quote]) => (
              <figure key={name} className="card p-6">
                <Quote className="h-6 w-6 text-brand-500" />
                <blockquote className="mt-3 leading-7 text-slate-700 dark:text-slate-300">{quote}</blockquote>
                <figcaption className="mt-5 flex items-center gap-3 border-t border-slate-100 pt-4 dark:border-slate-800">
                  <span className="grid h-10 w-10 place-items-center rounded-full bg-slate-100 font-bold text-slate-500 dark:bg-slate-800">{name.slice(-1)}</span>
                  <span>
                    <span className="block text-sm font-semibold text-slate-900 dark:text-white">{name}</span>
                    <span className="text-xs text-slate-500">{role} · sample content</span>
                  </span>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* ─── FAQ ────────────────────────────── */}
      <section id="faq" className="border-t border-slate-200 bg-slate-50 py-20 dark:border-slate-800 dark:bg-slate-900/40">
        <div className="container">
          <div className="mx-auto mb-12 max-w-2xl text-center">
            <p className="eyebrow">FAQ</p>
            <h2 className="section-title mt-2">Frequently asked questions</h2>
          </div>
          <Faq />
        </div>
      </section>

      {/* ─── CTA ────────────────────────────── */}
      <section className="py-20">
        <div className="container">
          <div className="relative overflow-hidden rounded-3xl bg-slate-900 px-6 py-16 text-center dark:bg-brand-950">
            <div className="absolute inset-0 bg-[radial-gradient(40rem_20rem_at_50%_120%,rgba(18,183,106,.35),transparent)]" />
            <h2 className="relative text-3xl font-bold tracking-tight text-white sm:text-4xl">Your first line of Python is one click away.</h2>
            <p className="relative mx-auto mt-3 max-w-xl text-slate-300">Join for free, finish your first lesson in under 10 minutes, and follow a clear plan to your first developer job.</p>
            <div className="relative mt-8 flex flex-col justify-center gap-3 sm:flex-row">
              <Link href="/learn/introduction/what-is-python" className="btn-primary btn-lg">
                Start lesson 1 <ArrowRight className="h-5 w-5" />
              </Link>
              <Link href="/roadmap" className="btn btn-lg border border-white/20 text-white hover:bg-white/10">
                View the roadmap
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
