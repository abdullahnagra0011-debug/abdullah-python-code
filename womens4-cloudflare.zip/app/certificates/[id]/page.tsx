import Link from 'next/link';
import { notFound } from 'next/navigation';
import { Award, Download, Linkedin, ShieldCheck } from 'lucide-react';
import { getCertificate } from '@/lib/certificates';
import { getCourse } from '@/content/courses';
import { LogoMark } from '@/components/Logo';
import { CopyLink } from '@/components/CopyLink';
import { SITE_URL } from '@/lib/env';

export async function generateMetadata({ params: paramsP }: { params: Promise<{ id: string }> }) {
  const params = await paramsP;
  const cert = await getCertificate(params.id);
  if (!cert) return { title: 'Certificate not found' };
  return { title: `${cert.recipient_name} – ${getCourse(cert.course_slug)?.title ?? 'Certificate'}` };
}

export default async function CertificatePage({ params: paramsP }: { params: Promise<{ id: string }> }) {
  const params = await paramsP;
  const cert = await getCertificate(params.id);
  if (!cert) notFound();
  const course = getCourse(cert.course_slug);
  const url = `${SITE_URL}/certificates/${cert.id}`;
  const issued = new Date(cert.issued_at);
  const date = issued.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
  const linkedin = `https://www.linkedin.com/profile/add?startTask=CERTIFICATION_NAME&name=${encodeURIComponent(course?.title ?? 'womens4.com course')}&organizationName=womens4.com&issueYear=${issued.getFullYear()}&issueMonth=${issued.getMonth() + 1}&certUrl=${encodeURIComponent(url)}&certId=${cert.id}`;

  return (
    <div className="container max-w-4xl py-12">
      {cert.revoked ? (
        <div className="card p-10 text-center">
          <h1 className="text-2xl font-bold text-red-700">This certificate has been revoked</h1>
          <p className="mt-2 text-slate-600">It is no longer valid.</p>
        </div>
      ) : (
        <>
          <div className="mb-6 flex items-center gap-2 rounded-xl bg-brand-50 px-4 py-3 text-sm font-medium text-brand-800 dark:bg-brand-500/10 dark:text-brand-300">
            <ShieldCheck className="h-5 w-5" /> Verified: this certificate was issued by womens4.com on {date}.
          </div>

          <div className="relative overflow-hidden rounded-3xl border-4 border-brand-500 bg-white p-8 text-center shadow-lift dark:bg-slate-900 sm:p-14">
            <div className="absolute inset-3 rounded-2xl border border-brand-200 dark:border-brand-900" />
            <div className="relative">
              <div className="flex items-center justify-center gap-2">
                <LogoMark className="h-9 w-9" />
                <span className="text-xl font-extrabold">womens4.com</span>
              </div>
              <p className="mt-8 text-sm font-bold uppercase tracking-[0.25em] text-brand-600">Certificate of completion</p>
              <p className="mt-6 text-slate-500">This certifies that</p>
              <p className="mt-2 font-serif text-4xl font-bold text-slate-900 dark:text-white sm:text-5xl">{cert.recipient_name}</p>
              <p className="mt-5 text-slate-500">has successfully completed the course</p>
              <p className="mt-2 text-2xl font-bold text-slate-900 dark:text-white sm:text-3xl">{course?.title ?? cert.course_slug}</p>
              {course && (
                <p className="mt-2 text-sm text-slate-500">
                  {course.modules.length} modules · {course.level} level · lessons and graded exercises
                </p>
              )}
              <div className="mt-10 flex flex-col items-center justify-between gap-4 text-left sm:flex-row">
                <div>
                  <p className="text-xs text-slate-500">Completion date</p>
                  <p className="font-semibold">{date}</p>
                </div>
                <Award className="h-14 w-14 text-amber-500" />
                <div className="sm:text-right">
                  <p className="text-xs text-slate-500">Certificate ID</p>
                  <p className="font-mono text-xs font-semibold">{cert.id}</p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <a href={`/api/certificates/${cert.id}/pdf`} className="btn-primary">
              <Download className="h-4 w-4" /> Download PDF
            </a>
            <a href={linkedin} target="_blank" rel="noopener noreferrer" className="btn-secondary">
              <Linkedin className="h-4 w-4 text-[#0a66c2]" /> Add to LinkedIn
            </a>
            <CopyLink url={url} />
          </div>
          <p className="mt-6 text-center text-xs text-slate-500">
            A womens4.com certificate of completion. It is not an accredited academic qualification. <Link href="/courses" className="underline">See the curriculum</Link>.
          </p>
        </>
      )}
    </div>
  );
}
