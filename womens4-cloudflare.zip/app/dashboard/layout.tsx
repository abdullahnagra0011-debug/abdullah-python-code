import { DashboardTabs } from '@/components/DashboardTabs';

export const dynamic = 'force-dynamic';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-[calc(100vh-4rem)] bg-slate-50 dark:bg-slate-950">
      <div className="border-b border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-950">
        <div className="container">
          <DashboardTabs />
        </div>
      </div>
      <div className="container py-8">{children}</div>
    </div>
  );
}
