import { LegalPage } from '@/components/LegalPage';
import { COMPANY_ADDRESS, COMPANY_NAME, SUPPORT_EMAIL } from '@/lib/env';

export const metadata = { title: 'Terms of Service' };

export default function Terms() {
  const md = `
## 1. Provider
These terms govern your use of womens4.com, operated by **${COMPANY_NAME}**, ${COMPANY_ADDRESS}. Contact: [${SUPPORT_EMAIL}](mailto:${SUPPORT_EMAIL}).

## 2. Account
You need a free account to save progress. Keep your password confidential. You must provide accurate information, including your real name if you want certificates.

## 3. Free plan
The Free plan gives access to the introductory modules, their exercises and a personal dashboard at no cost. We may change the scope of free content.

## 4. Premium subscription
- **Price:** €6.99 per month, including VAT where applicable.
- **Billing:** charged in advance via Stripe on the day you subscribe and then **automatically every month** on the same date.
- **Renewal:** the subscription renews automatically until you cancel.
- **Access:** Premium features are available only while the subscription is active and paid.

## 5. Cancellation
You can cancel at any time: **Dashboard → Subscription → "Manage or cancel subscription" → Cancel plan**. Cancellation takes effect at the end of the current billing month. You keep Premium until then and will not be charged again. We do not refund partially used months, except where required by law.

## 6. Right of withdrawal (EU consumers)
EU consumers generally have a 14-day right of withdrawal for online contracts. Because Premium gives immediate access to digital content, at checkout you request immediate performance and acknowledge that your right of withdrawal expires once access begins, to the extent permitted by law. If you have not used Premium content, contact us within 14 days for a refund.

## 7. Failed payments
If a payment fails, Stripe retries automatically and we notify you by email. If payment cannot be collected, Premium access is suspended until the balance is paid. Your progress is kept.

## 8. Certificates
Certificates are issued only after all completion criteria for a course are met (all lessons completed and at least 70% in each module's exercises) and only to Premium members. They are certificates of completion, not accredited academic qualifications. We may revoke certificates obtained through misuse.

## 9. Acceptable use
Do not share your account, copy or redistribute course content, attack the service, or attempt to bypass access controls. Downloadable study guides are for personal use only.

## 10. Content and availability
We work hard to keep lessons accurate and the service available, but we do not guarantee uninterrupted availability or that the course will lead to employment.

## 11. Liability
We are liable without limitation for intent and gross negligence and for injury to life, body or health. For slight negligence we are only liable for breach of essential contractual obligations, limited to foreseeable damage. Mandatory consumer law remains unaffected.

## 12. Changes to these terms
We will notify you of changes at least 30 days in advance. If you do not agree, you can cancel before they take effect.

## 13. Law and disputes
The law of the provider's country applies, without depriving consumers of the protection of mandatory provisions of the law of their country of residence. The EU online dispute resolution platform is available at [https://ec.europa.eu/consumers/odr](https://ec.europa.eu/consumers/odr).
`;
  return <LegalPage title="Terms of Service" updated="31 October 2026" source={md} />;
}
