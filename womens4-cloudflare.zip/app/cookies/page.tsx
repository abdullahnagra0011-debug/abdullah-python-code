import { LegalPage } from '@/components/LegalPage';

export const metadata = { title: 'Cookie Policy' };

export default function Cookies() {
  const md = `
## Strictly necessary only
womens4.com does **not** use analytics, advertising or tracking cookies. We only store what is needed to run the service:

| Name | Type | Purpose | Duration |
|---|---|---|---|
| \`sb-*-auth-token\` | Cookie | Keeps you logged in (Supabase Auth) | Session / up to 1 year |
| \`theme\` | Local storage | Remembers light or dark mode | Until cleared |
| \`cookie-notice\` | Local storage | Remembers that you saw the cookie notice | Until cleared |
| \`playground-code\` | Local storage | Saves your playground scratchpad on this device | Until cleared |

When you pay, Stripe sets its own strictly necessary cookies on the Stripe checkout page for fraud prevention.

Because these are strictly necessary, no consent is required under the ePrivacy Directive – but we still tell you about them. You can delete them at any time in your browser settings; you will then be logged out.

If we ever add optional cookies, we will ask for your consent first.
`;
  return <LegalPage title="Cookie Policy" updated="31 October 2026" source={md} />;
}
