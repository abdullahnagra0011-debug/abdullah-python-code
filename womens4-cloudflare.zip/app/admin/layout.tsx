import Link from 'next/link';
import { BarChart3, Users, BookOpenText, Award, ShieldAlert } from 'lucide-react';
import { requireAdmin } from '@/lib/auth';
import { hasServiceRole } from '@/lib/supabase/admin';

export const dynamic = 'force-dynamic';

const nav = [
  { href: '/admin', label: 'Overview', icon: BarChart3 },
  { href: '/admin/users', label: 'Users & subscriptions', icon: Users },
  { href: '/admin/content', label: 'Courses & content', icon: BookOpenText },
  { href: '/admin/certificates', label: 'Certificates', icon: Award },
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  await requireAdmin();
  return (
    <div className="min-h-[calc(100vh-4rem)] bg-slate-50 dark:bg-slate-950">
      <div className="container grid gap-8 py-8 lg:grid-cols-[220px_1fr]">
        <aside>
          <p className="mb-3 flex items-center gap-2 px-3 text-xs font-bold uppercase tracking-wider text-slate-400">
            <ShieldAlert className="h-3.5 w-3.5" /> Admin
          </p>
          <nav className="flex gap-1 overflow-x-auto lg:flex-col">
            {nav.map(({ href, label, icon: Icon }) => (
              <Link key={href} href={href} className="flex items-center gap-2 whitespace-nowrap rounded-lg px-3 py-2 text-sm font-medium text-slate-700 hover:bg-white dark:text-slate-300 dark:hover:bg-slate-900">
                <Icon className="h-4 w-4 text-brand-600" /> {label}
              </Link>
            ))}
          </nav>
        </aside>
        <div className="min-w-0">
          {!hasServiceRole() && (
            <p className="mb-6 rounded-xl bg-red-50 p-4 text-sm text-red-800">SUPABASE_SERVICE_ROLE_KEY is not set – admin data cannot be loaded.</p>
          )}
          {children}
        </div>
      </div>
    </div>
  );
}
