import Link from 'next/link';
import { revalidatePath } from 'next/cache';
import { requireAdmin } from '@/lib/auth';
import { createAdminClient, hasServiceRole } from '@/lib/supabase/admin';
import { getCourse } from '@/content/courses';

export const metadata = { title: 'Admin · Certificates' };

async function toggleRevoke(formData: FormData) {
  'use server';
  await requireAdmin();
  await createAdminClient()
    .from('certificates')
    .update({ revoked: formData.get('revoked') === 'true' })
    .eq('id', String(formData.get('id')));
  revalidatePath('/admin/certificates');
}

export default async function AdminCertificates() {
  await requireAdmin();
  if (!hasServiceRole()) return null;
  const { data } = await createAdminClient().from('certificates').select('*').order('issued_at', { ascending: false }).limit(200);
  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Certificates</h1>
      <p className="text-sm text-slate-500">Certificates are issued automatically when a learner meets all course criteria. Revoked certificates stop verifying.</p>
      <div className="card mt-6 overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-left text-xs uppercase tracking-wider text-slate-500 dark:bg-slate-800/50">
            <tr>
              <th className="px-4 py-3">Recipient</th>
              <th className="px-4 py-3">Course</th>
              <th className="px-4 py-3">Issued</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {(data ?? []).map((c: any) => (
              <tr key={c.id}>
                <td className="px-4 py-3 font-medium">
                  <Link href={`/certificates/${c.id}`} className="hover:text-brand-700">
                    {c.recipient_name}
                  </Link>
                </td>
                <td className="px-4 py-3">{getCourse(c.course_slug)?.title ?? c.course_slug}</td>
                <td className="px-4 py-3 text-slate-500">{new Date(c.issued_at).toLocaleDateString('en-GB')}</td>
                <td className="px-4 py-3">{c.revoked ? <span className="badge bg-red-50 text-red-700">revoked</span> : <span className="badge-green">valid</span>}</td>
                <td className="px-4 py-3">
                  <form action={toggleRevoke}>
                    <input type="hidden" name="id" value={c.id} />
                    <input type="hidden" name="revoked" value={String(!c.revoked)} />
                    <button className={`text-xs font-medium hover:underline ${c.revoked ? 'text-brand-700' : 'text-red-600'}`}>{c.revoked ? 'Restore' : 'Revoke'}</button>
                  </form>
                </td>
              </tr>
            ))}
            {!data?.length && (
              <tr>
                <td colSpan={5} className="px-4 py-6 text-center text-slate-500">
                  No certificates issued yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
