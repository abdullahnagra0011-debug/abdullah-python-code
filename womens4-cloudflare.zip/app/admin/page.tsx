import { Users, Crown, Euro, TrendingDown, AlertTriangle, BookOpen } from 'lucide-react';
import { requireAdmin } from '@/lib/auth';
import { createAdminClient, hasServiceRole } from '@/lib/supabase/admin';
import { getCurriculum } from '@/lib/content';
import { PREMIUM_PRICE_EUR } from '@/lib/env';

export const metadata = { title: 'Admin' };

export default async function AdminOverview() {
  await requireAdmin();
  if (!hasServiceRole()) return null;
  const admin = createAdminClient();
  const since30 = new Date(Date.now() - 30 * 864e5).toISOString();

  const [usersCount, newUsers, subs, payments30, completions] = await Promise.all([
    admin.from('profiles').select('id', { count: 'exact', head: true }),
    admin.from('profiles').select('id', { count: 'exact', head: true }).gte('created_at', since30),
    admin.from('subscriptions').select('status, cancel_at_period_end, current_period_end'),
    admin.from('payments').select('amount, status, created_at').gte('created_at', since30),
    admin.from('lesson_progress').select('lesson_key', { count: 'exact', head: true }).gte('completed_at', since30),
  ]);
  const modules = await getCurriculum();

  const rows = subs.data ?? [];
  const active = rows.filter((s: any) => ['active', 'trialing'].includes(s.status)).length;
  const canceling = rows.filter((s: any) => s.status === 'active' && s.cancel_at_period_end).length;
  const pastDue = rows.filter((s: any) => ['past_due', 'unpaid'].includes(s.status)).length;
  const churned = rows.filter((s: any) => s.status === 'canceled').length;
  const mrr = active * PREMIUM_PRICE_EUR;
  const revenue30 = (payments30.data ?? []).filter((p: any) => p.status === 'paid').reduce((n: number, p: any) => n + p.amount, 0) / 100;
  const failed30 = (payments30.data ?? []).filter((p: any) => p.status === 'failed').length;
  const conversion = usersCount.count ? ((active / usersCount.count) * 100).toFixed(1) : '0';
  const eur = (n: number) => new Intl.NumberFormat('en-IE', { style: 'currency', currency: 'EUR' }).format(n);

  const cards = [
    { icon: Euro, label: 'Monthly recurring revenue', value: eur(mrr), sub: `${active} active × €${PREMIUM_PRICE_EUR}` },
    { icon: Crown, label: 'Active Premium', value: String(active), sub: `${conversion}% of users · ${canceling} cancelling` },
    { icon: Users, label: 'Registered users', value: String(usersCount.count ?? 0), sub: `+${newUsers.count ?? 0} in 30 days` },
    { icon: Euro, label: 'Revenue (30 days)', value: eur(revenue30), sub: `${failed30} failed payments` },
    { icon: AlertTriangle, label: 'Past due', value: String(pastDue), sub: 'Payment retry in progress' },
    { icon: TrendingDown, label: 'Churned subscriptions', value: String(churned), sub: 'All time' },
    { icon: BookOpen, label: 'Lessons completed (30d)', value: String(completions.count ?? 0), sub: `${modules.length} modules live` },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Overview</h1>
      <p className="mt-1 text-sm text-slate-500">MRR is computed from subscriptions Stripe reports as active. Stripe&apos;s dashboard remains the financial source of truth.</p>
      <div className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map(({ icon: Icon, label, value, sub }) => (
          <div key={label} className="card p-5">
            <p className="flex items-center gap-2 text-sm text-slate-500">
              <Icon className="h-4 w-4 text-brand-600" /> {label}
            </p>
            <p className="mt-2 text-2xl font-bold text-slate-900 dark:text-white">{value}</p>
            <p className="mt-0.5 text-xs text-slate-500">{sub}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
