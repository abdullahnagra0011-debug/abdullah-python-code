import Link from 'next/link';
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { Plus, FileText, Lock } from 'lucide-react';
import { requireAdmin } from '@/lib/auth';
import { createAdminClient, hasServiceRole } from '@/lib/supabase/admin';
import { loadStaticModules } from '@/lib/content';
import { EXERCISES } from '@/content/exercises';

export const metadata = { title: 'Admin · Content' };

const slugify = (s: string) =>
  s
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
    .slice(0, 60);

async function createModule(formData: FormData) {
  'use server';
  await requireAdmin();
  const title = String(formData.get('title') ?? '').trim();
  if (!title) return;
  const slug = slugify(String(formData.get('slug') || title));
  if (loadStaticModules().some((m) => m.slug === slug)) redirect('/admin/content?error=slug');
  const { data, error } = await createAdminClient()
    .from('custom_modules')
    .insert({
      title,
      slug,
      description: String(formData.get('description') ?? ''),
      is_free: formData.get('is_free') === 'on',
      position: Number(formData.get('position') || 100),
    })
    .select('id')
    .single();
  if (error || !data) redirect('/admin/content?error=create');
  revalidatePath('/admin/content');
  redirect(`/admin/content/${data.id}`);
}

export default async function AdminContent({ searchParams: searchParamsP }: { searchParams: Promise<{ error?: string }> }) {
  const searchParams = await searchParamsP;
  await requireAdmin();
  const builtIn = loadStaticModules();
  const { data: custom } = hasServiceRole()
    ? await createAdminClient().from('custom_modules').select('id, slug, title, published, is_free, position').order('position')
    : { data: [] };

  return (
    <div className="space-y-10">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Courses & content</h1>
        <p className="mt-1 text-sm text-slate-500">
          Create new modules, lessons (Markdown), quizzes and coding exercises here. Published modules appear in the curriculum immediately.
        </p>
      </div>

      {searchParams.error && (
        <p className="rounded-xl bg-red-50 p-3 text-sm text-red-800">
          {searchParams.error === 'slug' ? 'That slug is used by a built-in module.' : 'Could not create the module (is the slug unique?).'}
        </p>
      )}

      <section className="card p-6">
        <h2 className="flex items-center gap-2 font-semibold">
          <Plus className="h-4 w-4 text-brand-600" /> New module
        </h2>
        <form action={createModule} className="mt-4 grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label">Title</label>
            <input name="title" required className="input" placeholder="e.g. Machine Learning Basics" />
          </div>
          <div>
            <label className="label">URL slug (optional)</label>
            <input name="slug" className="input" placeholder="machine-learning-basics" />
          </div>
          <div className="sm:col-span-2">
            <label className="label">Description</label>
            <textarea name="description" rows={2} className="input" />
          </div>
          <div>
            <label className="label">Sort position</label>
            <input name="position" type="number" defaultValue={100} className="input" />
          </div>
          <label className="mt-7 flex items-center gap-2 text-sm">
            <input type="checkbox" name="is_free" className="accent-brand-600" /> Free for everyone
          </label>
          <div className="sm:col-span-2">
            <button className="btn-primary">Create module</button>
          </div>
        </form>
      </section>

      <section>
        <h2 className="mb-3 font-semibold">Admin-created modules</h2>
        {!custom?.length ? (
          <p className="card p-5 text-sm text-slate-500">None yet.</p>
        ) : (
          <ul className="card divide-y divide-slate-100 dark:divide-slate-800">
            {custom.map((m: any) => (
              <li key={m.id}>
                <Link href={`/admin/content/${m.id}`} className="flex items-center justify-between px-5 py-3 hover:bg-slate-50 dark:hover:bg-slate-800/50">
                  <span className="font-medium">{m.title}</span>
                  <span className="flex gap-2">
                    {m.is_free && <span className="badge-green">Free</span>}
                    <span className={m.published ? 'badge-green' : 'badge-slate'}>{m.published ? 'Published' : 'Draft'}</span>
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section>
        <h2 className="mb-1 flex items-center gap-2 font-semibold">
          <Lock className="h-4 w-4 text-slate-400" /> Built-in curriculum ({builtIn.length} modules)
        </h2>
        <p className="mb-3 text-sm text-slate-500">
          Version-controlled in <code>content/course/*.md</code> and <code>content/exercises.ts</code>; edit them in the repository and redeploy.
        </p>
        <ul className="card divide-y divide-slate-100 text-sm dark:divide-slate-800">
          {builtIn.map((m) => (
            <li key={m.slug} className="flex items-center justify-between px-5 py-2.5">
              <span>
                <span className="mr-2 text-slate-400">{m.number}.</span>
                {m.title}
              </span>
              <span className="flex items-center gap-3 text-xs text-slate-500">
                <span className="flex items-center gap-1">
                  <FileText className="h-3.5 w-3.5" /> {m.lessons.length} lessons
                </span>
                <span>{EXERCISES[m.slug]?.length ?? 0} questions</span>
                {m.free ? <span className="badge-green">Free</span> : <span className="badge-slate">Premium</span>}
              </span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
