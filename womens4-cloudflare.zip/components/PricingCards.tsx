import Link from 'next/link';
import { Check, Crown, Minus } from 'lucide-react';

const free = [
  'First 6 beginner modules (30+ lessons)',
  'Try-it-yourself editor in every free lesson',
  'Exercises & basic quizzes for free modules',
  'Personal learning dashboard',
];
const premium = [
  'All 25 modules – beginner to job-ready',
  'Unlimited exercises & coding challenges',
  'Full online Python playground',
  'All quizzes and tests',
  'Practical portfolio projects',
  'Advanced Python, Git, testing, web & data',
  'Progress tracking and achievements',
  'Downloadable study guides',
  'Course completion certificates (PDF)',
  'All new courses and content updates',
];

export function PricingCards({ signedIn, premiumActive }: { signedIn: boolean; premiumActive: boolean }) {
  return (
    <div className="mx-auto grid max-w-4xl gap-6 md:grid-cols-2">
      <div className="card flex flex-col p-7 sm:p-8">
        <h3 className="text-lg font-semibold text-slate-900 dark:text-white">Free</h3>
        <p className="mt-1 text-sm text-slate-500">Start learning today, no card required.</p>
        <p className="mt-6 flex items-baseline gap-1">
          <span className="text-5xl font-extrabold tracking-tight text-slate-900 dark:text-white">€0</span>
          <span className="text-slate-500">/month</span>
        </p>
        <ul className="mt-8 flex-1 space-y-3 text-sm">
          {free.map((f) => (
            <li key={f} className="flex gap-3">
              <Check className="h-5 w-5 shrink-0 text-brand-600" /> {f}
            </li>
          ))}
          {['Certificates', 'Advanced & career modules'].map((f) => (
            <li key={f} className="flex gap-3 text-slate-400">
              <Minus className="h-5 w-5 shrink-0" /> {f}
            </li>
          ))}
        </ul>
        <Link href={signedIn ? '/learn/introduction/what-is-python' : '/register'} className="btn-secondary btn-lg mt-8">
          {signedIn ? 'Continue learning' : 'Start Learning for Free'}
        </Link>
      </div>

      <div className="relative flex flex-col rounded-2xl border-2 border-brand-500 bg-white p-7 shadow-lift dark:bg-slate-900 sm:p-8">
        <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 rounded-full bg-brand-600 px-3 py-1 text-xs font-bold uppercase tracking-wider text-white">
          Most popular
        </span>
        <h3 className="flex items-center gap-2 text-lg font-semibold text-slate-900 dark:text-white">
          <Crown className="h-5 w-5 text-amber-500" /> Premium
        </h3>
        <p className="mt-1 text-sm text-slate-500">Everything you need to become job-ready.</p>
        <p className="mt-6 flex items-baseline gap-1">
          <span className="text-5xl font-extrabold tracking-tight text-slate-900 dark:text-white">€6.99</span>
          <span className="text-slate-500">/month</span>
        </p>
        <p className="mt-1 text-xs text-slate-500">VAT included where applicable · billed monthly</p>
        <ul className="mt-8 flex-1 space-y-3 text-sm">
          {premium.map((f) => (
            <li key={f} className="flex gap-3">
              <Check className="h-5 w-5 shrink-0 text-brand-600" /> {f}
            </li>
          ))}
        </ul>
        {premiumActive ? (
          <Link href="/dashboard/billing" className="btn-primary btn-lg mt-8">
            You&apos;re Premium – manage subscription
          </Link>
        ) : signedIn ? (
          <form action="/api/stripe/checkout" method="post" className="mt-8 grid">
            <button className="btn-primary btn-lg">Get Premium</button>
          </form>
        ) : (
          <Link href="/register?next=/pricing" className="btn-primary btn-lg mt-8">
            Get Premium
          </Link>
        )}
        <p className="mt-3 text-center text-xs leading-5 text-slate-500">
          Renews automatically every month until you cancel. Cancel anytime in your dashboard – you keep access until the end of the period you paid for.
        </p>
      </div>
    </div>
  );
}
