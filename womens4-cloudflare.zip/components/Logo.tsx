import Link from 'next/link';

/** womens4.com mark: the Venus symbol (women) with a rising spark (empowerment). */
export function LogoMark({ className = 'h-8 w-8' }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="w4-g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#12b76a" />
          <stop offset="1" stopColor="#027a48" />
        </linearGradient>
      </defs>
      <rect width="40" height="40" rx="11" fill="url(#w4-g)" />
      <circle cx="18" cy="16" r="7.5" fill="none" stroke="#fff" strokeWidth="3.2" />
      <path d="M18 23.5V33M13 28.5h10" stroke="#fff" strokeWidth="3.2" strokeLinecap="round" />
      <path d="M31 5.5l1.3 3.2 3.2 1.3-3.2 1.3L31 14.5l-1.3-3.2-3.2-1.3 3.2-1.3z" fill="#a6f4c5" />
    </svg>
  );
}

export function Logo({ href = '/' }: { href?: string }) {
  return (
    <Link href={href} className="flex items-center gap-2.5" aria-label="womens4.com home">
      <LogoMark />
      <span className="text-lg font-extrabold tracking-tight text-slate-900 dark:text-white">
        womens<span className="text-brand-600 dark:text-brand-400">4</span>
        <span className="font-semibold text-slate-400">.com</span>
      </span>
    </Link>
  );
}
