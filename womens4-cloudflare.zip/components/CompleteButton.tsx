'use client';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useState, useTransition } from 'react';
import { CheckCircle2, Circle, Loader2 } from 'lucide-react';

export function CompleteButton({
  moduleSlug,
  lessonSlug,
  initiallyDone,
  signedIn,
}: {
  moduleSlug: string;
  lessonSlug: string;
  initiallyDone: boolean;
  signedIn: boolean;
}) {
  const [done, setDone] = useState(initiallyDone);
  const [error, setError] = useState('');
  const [pending, start] = useTransition();
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  if (!signedIn) {
    return (
      <Link href={`/login?next=/learn/${moduleSlug}/${lessonSlug}`} className="btn-secondary">
        <Circle className="h-4 w-4" /> Log in to track progress
      </Link>
    );
  }

  const toggle = async () => {
    setBusy(true);
    setError('');
    const res = await fetch('/api/progress', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ moduleSlug, lessonSlug, completed: !done }),
    });
    setBusy(false);
    if (!res.ok) {
      const j = await res.json().catch(() => ({}));
      setError(j.error || 'Could not save progress.');
      return;
    }
    setDone(!done);
    start(() => router.refresh());
  };

  return (
    <div className="flex flex-col items-start gap-1">
      <button onClick={toggle} disabled={busy || pending} className={done ? 'btn-secondary !border-brand-300 !text-brand-700 dark:!text-brand-400' : 'btn-primary'}>
        {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : done ? <CheckCircle2 className="h-4 w-4" /> : <Circle className="h-4 w-4" />}
        {done ? 'Completed' : 'Mark as completed'}
      </button>
      {error && <span className="text-xs text-red-600">{error}</span>}
    </div>
  );
}
