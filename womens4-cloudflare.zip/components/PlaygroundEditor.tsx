'use client';
import { useEffect, useRef, useState } from 'react';
import { PyEditor } from './PyEditor';

const DEFAULT = `import statistics

scores = [72, 88, 95, 64, 81]
print("Average:", statistics.mean(scores))
print("Best:", max(scores))

name = input("What's your name? ")
print(f"Nice to meet you, {name}!")
`;

/** Remembers your scratchpad in this browser (a per-device convenience). */
export function PlaygroundEditor() {
  const [initial, setInitial] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  useEffect(() => {
    let saved: string | null = null;
    try {
      saved = localStorage.getItem('playground-code');
    } catch {}
    setInitial(saved || DEFAULT);
  }, []);

  if (initial === null) return <div className="card h-[560px] animate-pulse" />;
  return (
    <>
      <PyEditor
        initialCode={initial}
        height={480}
        onCodeChange={(code) => {
          clearTimeout(timer.current);
          timer.current = setTimeout(() => {
            try {
              localStorage.setItem('playground-code', code);
            } catch {}
          }, 400);
        }}
      />
      <p className="mt-3 text-xs text-slate-500">
        Your code is saved automatically in this browser. Ctrl/⌘ + Enter runs it; use the Input button to provide values for input().
      </p>
    </>
  );
}
