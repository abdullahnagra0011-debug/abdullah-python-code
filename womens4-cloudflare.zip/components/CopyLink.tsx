'use client';
import { useState } from 'react';
import { Check, Link2 } from 'lucide-react';

export function CopyLink({ url }: { url: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      className="btn-secondary"
      onClick={async () => {
        try {
          if (navigator.share) await navigator.share({ title: 'My womens4.com certificate', url });
          else {
            await navigator.clipboard.writeText(url);
            setCopied(true);
            setTimeout(() => setCopied(false), 1800);
          }
        } catch {}
      }}
    >
      {copied ? <Check className="h-4 w-4 text-brand-600" /> : <Link2 className="h-4 w-4" />}
      {copied ? 'Link copied' : 'Share link'}
    </button>
  );
}
