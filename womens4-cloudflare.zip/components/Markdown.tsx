import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { CodeBlock } from './CodeBlock';

const slugify = (s: string) =>
  s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');

function text(children: React.ReactNode): string {
  if (typeof children === 'string') return children;
  if (Array.isArray(children)) return children.map(text).join('');
  return '';
}

export function Markdown({ source, canRun = true }: { source: string; canRun?: boolean }) {
  return (
    <div className="lesson">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          pre: ({ children }) => <>{children}</>,
          code: ({ className, children }) => {
            const match = /language-([\w-]+)/.exec(className || '');
            if (!match) return <code>{children}</code>;
            return <CodeBlock code={String(children).replace(/\n$/, '')} lang={match[1]} canRun={canRun} />;
          },
          h2: ({ children }) => <h2 id={slugify(text(children).replace(/^\d+\.\s*/, ''))}>{children}</h2>,
          table: ({ children }) => (
            <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
              <table className="!my-0">{children}</table>
            </div>
          ),
          a: ({ href, children }) => (
            <a href={href} {...(href?.startsWith('http') ? { target: '_blank', rel: 'noopener noreferrer' } : {})}>
              {children}
            </a>
          ),
        }}
      >
        {source}
      </ReactMarkdown>
    </div>
  );
}
