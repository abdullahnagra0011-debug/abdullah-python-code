import { LogoMark } from './Logo';

export function AuthShell({ title, subtitle, children }: { title: string; subtitle?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="flex min-h-[calc(100vh-4rem)] items-center justify-center bg-slate-50 px-4 py-12 dark:bg-slate-900/40">
      <div className="w-full max-w-md animate-fade-up">
        <div className="mb-8 text-center">
          <LogoMark className="mx-auto h-12 w-12" />
          <h1 className="mt-5 text-2xl font-bold tracking-tight text-slate-900 dark:text-white">{title}</h1>
          {subtitle && <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">{subtitle}</p>}
        </div>
        <div className="card p-6 sm:p-8">{children}</div>
      </div>
    </div>
  );
}

export function FormMessage({ type, children }: { type: 'error' | 'success'; children: React.ReactNode }) {
  return (
    <div
      role="alert"
      className={`rounded-xl px-4 py-3 text-sm ${
        type === 'error' ? 'bg-red-50 text-red-800 dark:bg-red-500/10 dark:text-red-300' : 'bg-brand-50 text-brand-800 dark:bg-brand-500/10 dark:text-brand-300'
      }`}
    >
      {children}
    </div>
  );
}

export function NotConfigured() {
  return (
    <FormMessage type="error">
      Accounts are not configured yet. The site owner must set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY.
    </FormMessage>
  );
}
