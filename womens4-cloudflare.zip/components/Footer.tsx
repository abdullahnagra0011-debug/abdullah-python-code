import Link from 'next/link';
import { Mail, MapPin } from 'lucide-react';
import { Logo } from './Logo';
import { COMPANY_ADDRESS, COMPANY_NAME, SUPPORT_EMAIL } from '@/lib/env';

const cols = [
  {
    title: 'Learn',
    links: [
      ['All courses', '/courses'],
      ['Zero to job-ready roadmap', '/roadmap'],
      ['Python tutorial', '/learn/introduction/what-is-python'],
      ['Online Python editor', '/playground'],
    ],
  },
  {
    title: 'Platform',
    links: [
      ['Pricing', '/pricing'],
      ['Create account', '/register'],
      ['Dashboard', '/dashboard'],
      ['FAQ', '/#faq'],
    ],
  },
  {
    title: 'Legal',
    links: [
      ['Privacy policy', '/privacy'],
      ['Terms of service', '/terms'],
      ['Cookie policy', '/cookies'],
      ['Cancel subscription', '/terms#cancellation'],
    ],
  },
];

export function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-slate-50 dark:border-slate-800 dark:bg-slate-900/40">
      <div className="container grid gap-10 py-14 md:grid-cols-[1.4fr_repeat(3,1fr)]">
        <div>
          <Logo />
          <p className="mt-4 max-w-xs text-sm leading-6 text-slate-600 dark:text-slate-400">
            Learn Python from your very first line of code to your first developer job – one clear lesson at a time.
          </p>
          <ul className="mt-5 space-y-2 text-sm text-slate-600 dark:text-slate-400">
            <li className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-brand-600" />
              <a href={`mailto:${SUPPORT_EMAIL}`} className="hover:text-brand-700">
                {SUPPORT_EMAIL}
              </a>
            </li>
            <li className="flex items-start gap-2">
              <MapPin className="mt-0.5 h-4 w-4 text-brand-600" />
              <span>
                {COMPANY_NAME}
                <br />
                {COMPANY_ADDRESS}
              </span>
            </li>
          </ul>
        </div>
        {cols.map((c) => (
          <div key={c.title}>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">{c.title}</h3>
            <ul className="mt-4 space-y-2.5 text-sm">
              {c.links.map(([label, href]) => (
                <li key={href}>
                  <Link href={href} className="text-slate-600 transition hover:text-brand-700 dark:text-slate-400 dark:hover:text-brand-400">
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-slate-200 dark:border-slate-800">
        <div className="container flex flex-col items-center justify-between gap-2 py-6 text-xs text-slate-500 sm:flex-row">
          <p>
            © {new Date().getFullYear()} {COMPANY_NAME}. All rights reserved.
          </p>
          <p>Python is a trademark of the Python Software Foundation. womens4.com is not affiliated with the PSF.</p>
        </div>
      </div>
    </footer>
  );
}
