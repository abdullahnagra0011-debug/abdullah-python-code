import Link from 'next/link';
import { Crown, Check } from 'lucide-react';

export function Paywall({ title, signedIn }: { title: string; signedIn: boolean }) {
  return (
    <div className="card relative overflow-hidden p-8 text-center sm:p-12">
      <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-brand-400 via-brand-600 to-brand-400" />
      <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-amber-50 dark:bg-amber-500/10">
        <Crown className="h-7 w-7 text-amber-500" />
      </div>
      <h2 className="mt-5 text-2xl font-bold text-slate-900 dark:text-white">“{title}” is part of Premium</h2>
      <p className="mx-auto mt-2 max-w-md text-slate-600 dark:text-slate-400">
        Unlock every module from loops to job-ready web development, all exercises, projects, downloadable guides and certificates.
      </p>
      <ul className="mx-auto mt-6 grid max-w-sm gap-2 text-left text-sm">
        {['All 25 modules and 100+ lessons', 'Unlimited exercises & code challenges', 'Course certificates (PDF)', 'Cancel anytime in two clicks'].map((f) => (
          <li key={f} className="flex items-center gap-2">
            <Check className="h-4 w-4 text-brand-600" /> {f}
          </li>
        ))}
      </ul>
      <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
        <Link href="/pricing" className="btn-primary btn-lg">
          Get Premium – €6.99/month
        </Link>
        {!signedIn && (
          <Link href="/register" className="btn-secondary btn-lg">
            Create free account
          </Link>
        )}
      </div>
      <p className="mt-4 text-xs text-slate-500">Recurring monthly subscription. Cancel any time; access continues until the end of the paid month.</p>
    </div>
  );
}
