'use client';
import { PyEditor } from './PyEditor';

const DEMO = `# Edit me and press Run – this is real Python in your browser!
name = "future developer"
skills = ["variables", "loops", "functions", "APIs"]

print(f"Hello, {name}! 👋")
for week, skill in enumerate(skills, start=1):
    print(f"Week {week}: learn {skill}")

total = sum(len(s) for s in skills)
print("Letters learned:", total)
`;

export function DemoEditor() {
  return <PyEditor initialCode={DEMO} height={280} showStdin={false} />;
}
