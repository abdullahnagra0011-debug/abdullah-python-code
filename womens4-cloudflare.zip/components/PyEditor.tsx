'use client';
import dynamic from 'next/dynamic';
import { useEffect, useRef, useState } from 'react';
import { Play, RotateCcw, Loader2, Terminal, Keyboard, CheckCircle2, XCircle } from 'lucide-react';
import { onPythonStatus, preloadPython, runPython, type RunResult } from '@/lib/pyodide-client';

const Monaco = dynamic(() => import('@monaco-editor/react'), {
  ssr: false,
  loading: () => <div className="grid h-full place-items-center text-sm text-slate-400">Loading editor…</div>,
});

function useDark() {
  const [dark, setDark] = useState(false);
  useEffect(() => {
    const el = document.documentElement;
    const update = () => setDark(el.classList.contains('dark'));
    update();
    const obs = new MutationObserver(update);
    obs.observe(el, { attributes: true, attributeFilter: ['class'] });
    return () => obs.disconnect();
  }, []);
  return dark;
}

export function PyEditor({
  initialCode,
  height = 260,
  tests,
  onResult,
  runLabel = 'Run',
  showStdin = true,
  onCodeChange,
}: {
  onCodeChange?: (code: string) => void;
  initialCode: string;
  height?: number;
  tests?: string;
  onResult?: (r: RunResult) => void;
  runLabel?: string;
  showStdin?: boolean;
}) {
  const [code, setCode] = useState(initialCode);
  const [stdin, setStdin] = useState('');
  const [stdinOpen, setStdinOpen] = useState(false);
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<RunResult | null>(null);
  const [pyStatus, setPyStatus] = useState<string>('idle');
  const codeRef = useRef(code);
  codeRef.current = code;
  const dark = useDark();

  useEffect(() => onPythonStatus(setPyStatus), []);
  useEffect(() => {
    if (/\binput\s*\(/.test(initialCode)) setStdinOpen(true);
  }, [initialCode]);

  const run = async () => {
    setRunning(true);
    setResult(null);
    const r = await runPython(codeRef.current, { stdin, tests });
    setResult(r);
    setRunning(false);
    onResult?.(r);
  };

  return (
    <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-card dark:border-slate-800 dark:bg-slate-900" onMouseEnter={preloadPython} onFocus={preloadPython}>
      <div className="flex items-center justify-between gap-2 border-b border-slate-200 bg-slate-50 px-3 py-2 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-center gap-2 text-xs font-medium text-slate-500">
          <span className="flex gap-1.5">
            <span className="h-2.5 w-2.5 rounded-full bg-red-400" />
            <span className="h-2.5 w-2.5 rounded-full bg-amber-400" />
            <span className="h-2.5 w-2.5 rounded-full bg-brand-400" />
          </span>
          <span className="ml-2 font-mono">main.py</span>
        </div>
        <div className="flex items-center gap-1.5">
          {showStdin && (
            <button onClick={() => setStdinOpen((o) => !o)} className="btn-ghost !px-2.5 !py-1.5 text-xs" title="Provide input() values">
              <Keyboard className="h-3.5 w-3.5" /> Input
            </button>
          )}
          <button
            onClick={() => {
              setCode(initialCode);
              setResult(null);
            }}
            className="btn-ghost !px-2.5 !py-1.5 text-xs"
            title="Reset code"
          >
            <RotateCcw className="h-3.5 w-3.5" /> Reset
          </button>
          <button onClick={run} disabled={running} className="btn-primary !px-3.5 !py-1.5 text-xs">
            {running ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Play className="h-3.5 w-3.5 fill-current" />}
            {running ? (pyStatus === 'loading' ? 'Loading Python…' : 'Running…') : runLabel}
          </button>
        </div>
      </div>

      <div style={{ height }}>
        <Monaco
          language="python"
          value={code}
          onChange={(v) => {
            setCode(v ?? '');
            onCodeChange?.(v ?? '');
          }}
          theme={dark ? 'vs-dark' : 'light'}
          onMount={(editor, monaco) => {
            editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.Enter, () => run());
          }}
          options={{
            fontSize: 14,
            fontFamily: '"JetBrains Mono Variable", ui-monospace, monospace',
            minimap: { enabled: false },
            scrollBeyondLastLine: false,
            lineNumbersMinChars: 3,
            padding: { top: 12, bottom: 12 },
            tabSize: 4,
            automaticLayout: true,
            wordWrap: 'on',
            renderLineHighlight: 'gutter',
          }}
        />
      </div>

      {stdinOpen && showStdin && (
        <div className="border-t border-slate-200 px-3 py-2 dark:border-slate-800">
          <label className="mb-1 block text-xs font-medium text-slate-500">Input for input() – one value per line</label>
          <textarea
            value={stdin}
            onChange={(e) => setStdin(e.target.value)}
            rows={2}
            className="input font-mono !text-xs"
            placeholder={'Ada\n36'}
          />
        </div>
      )}

      <div className="border-t border-slate-200 bg-slate-950 dark:border-slate-800">
        <div className="flex items-center justify-between px-4 pt-2.5 text-xs font-medium text-slate-400">
          <span className="flex items-center gap-1.5">
            <Terminal className="h-3.5 w-3.5" /> Output
          </span>
          <span className="text-slate-500">Ctrl/⌘ + Enter to run</span>
        </div>
        <pre className="scrollbar-thin max-h-64 min-h-[72px] overflow-auto whitespace-pre-wrap px-4 pb-3 pt-2 font-mono text-[13px] leading-6 text-slate-100" aria-live="polite">
          {!result && !running && <span className="text-slate-500">Click “{runLabel}” to see the result here.</span>}
          {running && pyStatus === 'loading' && <span className="text-slate-400">Starting Python in your browser (first run takes a few seconds)…</span>}
          {result?.stdout}
          {result?.error && <span className="text-red-400">{result.error}</span>}
          {result && !result.stdout && !result.error && result.passed === undefined && <span className="text-slate-500">(no output)</span>}
        </pre>
        {result && result.passed !== undefined && (
          <div className={`flex items-start gap-2 border-t px-4 py-2.5 text-sm ${result.passed ? 'border-brand-900 bg-brand-950 text-brand-300' : 'border-red-900 bg-red-950/60 text-red-300'}`}>
            {result.passed ? <CheckCircle2 className="mt-0.5 h-4 w-4" /> : <XCircle className="mt-0.5 h-4 w-4" />}
            {result.passed ? 'All tests passed!' : `Not yet: ${result.testError}`}
          </div>
        )}
      </div>
    </div>
  );
}
