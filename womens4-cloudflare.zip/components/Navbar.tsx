import { getViewer } from '@/lib/auth';
import { NavbarClient } from './NavbarClient';

export async function Navbar() {
  const viewer = await getViewer();
  return (
    <NavbarClient
      signedIn={!!viewer.user}
      name={viewer.profile?.full_name || viewer.user?.email || ''}
      premium={viewer.premium}
      isAdmin={viewer.isAdmin}
    />
  );
}
