import { ChevronDown } from 'lucide-react';

export const FAQ_ITEMS = [
  {
    q: 'I have never programmed before. Is womens4.com for me?',
    a: 'Yes. The first module assumes zero knowledge – we explain what a program is, what Python is, and walk you through your first line of code. Each lesson builds on the previous one in small steps.',
  },
  {
    q: 'Do I need to install anything?',
    a: 'No. Every code example runs directly in your browser with a real Python interpreter (Pyodide). Module 2 shows you how to install Python on your own computer when you are ready.',
  },
  {
    q: 'Can womens4.com really make me job-ready?',
    a: 'The Job-Ready path covers what junior Python roles typically ask for: solid Python, OOP, files, errors, SQL, APIs, Git, testing, a web framework (Flask/FastAPI), pandas, portfolio projects and interview preparation. Getting hired also takes practice and applications – we give you a clear plan for both, but no course can guarantee a job.',
  },
  {
    q: 'What does Premium cost and how is it billed?',
    a: 'Premium is €6.99 per month, charged automatically every month through Stripe until you cancel. There are no setup fees or long-term contracts.',
  },
  {
    q: 'How do I cancel?',
    a: 'Go to Dashboard → Subscription → “Manage or cancel”. You can cancel in two clicks. You keep Premium access until the end of the month you already paid for, and you are not charged again.',
  },
  {
    q: 'What happens to my progress if I cancel?',
    a: 'Nothing is lost. Your progress, scores and certificates stay in your account, and you can keep using all free lessons.',
  },
  {
    q: 'Are the certificates official?',
    a: 'They are womens4.com certificates of completion with a unique ID and public verification page you can share on LinkedIn. They are not a university degree or government-accredited qualification.',
  },
];

export function Faq() {
  return (
    <div className="mx-auto max-w-3xl divide-y divide-slate-200 rounded-2xl border border-slate-200 bg-white dark:divide-slate-800 dark:border-slate-800 dark:bg-slate-900">
      {FAQ_ITEMS.map((f) => (
        <details key={f.q} className="group p-5 [&_summary::-webkit-details-marker]:hidden">
          <summary className="flex cursor-pointer items-center justify-between gap-4 font-semibold text-slate-900 dark:text-white">
            {f.q}
            <ChevronDown className="h-5 w-5 shrink-0 text-slate-400 transition group-open:rotate-180" />
          </summary>
          <p className="mt-3 leading-7 text-slate-600 dark:text-slate-400">{f.a}</p>
        </details>
      ))}
    </div>
  );
}
