'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { CheckCircle2, ChevronDown, Circle, Lock, PanelLeftOpen, Target, X } from 'lucide-react';

export type SidebarModule = {
  slug: string;
  title: string;
  number: number;
  free: boolean;
  stage: string;
  hasExercises: boolean;
  lessons: { slug: string; title: string }[];
};

export function LessonSidebar({ modules, completed, premium }: { modules: SidebarModule[]; completed: string[]; premium: boolean }) {
  const pathname = usePathname();
  const [, , currentModule, currentLesson] = pathname.split('/');
  const [open, setOpen] = useState<Record<string, boolean>>({ [currentModule]: true });
  const [mobileOpen, setMobileOpen] = useState(false);
  const done = new Set(completed);
  const activeRef = useRef<HTMLAnchorElement>(null);

  useEffect(() => {
    setOpen((o) => ({ ...o, [currentModule]: true }));
    setMobileOpen(false);
  }, [currentModule, currentLesson]);
  useEffect(() => {
    activeRef.current?.scrollIntoView({ block: 'center' });
  }, []);

  const totalLessons = modules.reduce((n, m) => n + m.lessons.length, 0);
  const pct = totalLessons ? Math.round((completed.length / totalLessons) * 100) : 0;

  let lastStage = '';
  const nav = (
    <nav aria-label="Course lessons" className="space-y-1 pb-10">
      <div className="mb-4 rounded-xl bg-brand-50 p-3 dark:bg-brand-500/10">
        <div className="flex justify-between text-xs font-semibold text-brand-800 dark:text-brand-300">
          <span>Your progress</span>
          <span>{pct}%</span>
        </div>
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-brand-100 dark:bg-brand-900/50">
          <div className="h-full rounded-full bg-brand-500 transition-all duration-500" style={{ width: `${pct}%` }} />
        </div>
        <p className="mt-1.5 text-[11px] text-brand-700/80 dark:text-brand-300/70">
          {completed.length} of {totalLessons} lessons completed
        </p>
      </div>
      {modules.map((m) => {
        const locked = !m.free && !premium;
        const isOpen = open[m.slug];
        const modDone = m.lessons.filter((l) => done.has(`${m.slug}/${l.slug}`)).length;
        const showStage = m.stage !== lastStage;
        lastStage = m.stage;
        return (
          <div key={m.slug}>
            {showStage && <p className="mb-1 mt-5 px-2 text-[11px] font-bold uppercase tracking-wider text-slate-400 first:mt-0">{m.stage}</p>}
            <button
              onClick={() => setOpen((o) => ({ ...o, [m.slug]: !o[m.slug] }))}
              className={`flex w-full items-center gap-2 rounded-lg px-2 py-2 text-left text-sm font-semibold transition hover:bg-slate-100 dark:hover:bg-slate-800 ${
                m.slug === currentModule ? 'text-slate-900 dark:text-white' : 'text-slate-700 dark:text-slate-300'
              }`}
              aria-expanded={!!isOpen}
            >
              <span className="grid h-6 w-6 shrink-0 place-items-center rounded-md bg-slate-100 text-[11px] font-bold text-slate-500 dark:bg-slate-800">
                {m.number}
              </span>
              <span className="flex-1 leading-snug">{m.title}</span>
              {locked ? (
                <Lock className="h-3.5 w-3.5 text-slate-400" />
              ) : (
                <span className="text-[11px] font-medium text-slate-400">
                  {modDone}/{m.lessons.length}
                </span>
              )}
              <ChevronDown className={`h-4 w-4 text-slate-400 transition ${isOpen ? 'rotate-180' : ''}`} />
            </button>
            {isOpen && (
              <ul className="ml-[18px] mt-0.5 space-y-0.5 border-l border-slate-200 pl-3 dark:border-slate-800">
                {m.lessons.map((l) => {
                  const active = m.slug === currentModule && l.slug === currentLesson;
                  const isDone = done.has(`${m.slug}/${l.slug}`);
                  return (
                    <li key={l.slug}>
                      <Link
                        ref={active ? activeRef : undefined}
                        href={`/learn/${m.slug}/${l.slug}`}
                        className={`flex items-center gap-2 rounded-lg px-2.5 py-1.5 text-[13.5px] transition ${
                          active
                            ? 'bg-brand-600 font-medium text-white'
                            : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white'
                        }`}
                      >
                        {isDone ? (
                          <CheckCircle2 className={`h-3.5 w-3.5 shrink-0 ${active ? 'text-white' : 'text-brand-500'}`} />
                        ) : (
                          <Circle className={`h-3.5 w-3.5 shrink-0 ${active ? 'text-white/70' : 'text-slate-300 dark:text-slate-600'}`} />
                        )}
                        <span className="leading-snug">{l.title}</span>
                      </Link>
                    </li>
                  );
                })}
                {m.hasExercises && (
                  <li>
                    <Link
                      href={`/learn/${m.slug}/exercises`}
                      className={`flex items-center gap-2 rounded-lg px-2.5 py-1.5 text-[13.5px] font-medium transition ${
                        m.slug === currentModule && currentLesson === 'exercises'
                          ? 'bg-brand-600 text-white'
                          : 'text-brand-700 hover:bg-brand-50 dark:text-brand-400 dark:hover:bg-brand-500/10'
                      }`}
                    >
                      <Target className="h-3.5 w-3.5 shrink-0" /> Exercises & Quiz
                    </Link>
                  </li>
                )}
              </ul>
            )}
          </div>
        );
      })}
    </nav>
  );

  return (
    <>
      <button onClick={() => setMobileOpen(true)} className="btn-secondary fixed bottom-5 left-5 z-30 shadow-lift lg:hidden">
        <PanelLeftOpen className="h-4 w-4" /> Lessons
      </button>
      <aside className="scrollbar-thin sticky top-16 hidden h-[calc(100vh-4rem)] w-72 shrink-0 overflow-y-auto border-r border-slate-200 px-3 py-6 dark:border-slate-800 lg:block">
        {nav}
      </aside>
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-slate-950/40 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <div className="scrollbar-thin absolute inset-y-0 left-0 w-[85%] max-w-sm overflow-y-auto bg-white px-3 py-4 shadow-xl dark:bg-slate-950">
            <div className="mb-3 flex items-center justify-between px-2">
              <span className="font-semibold">All lessons</span>
              <button onClick={() => setMobileOpen(false)} className="btn-ghost !p-1.5" aria-label="Close">
                <X className="h-5 w-5" />
              </button>
            </div>
            {nav}
          </div>
        </div>
      )}
    </>
  );
}
