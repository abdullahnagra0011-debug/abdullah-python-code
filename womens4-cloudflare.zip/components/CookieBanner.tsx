'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { Cookie } from 'lucide-react';

/**
 * womens4.com only uses strictly necessary storage (login session, theme, this notice).
 * No analytics or advertising cookies are set, so no opt-in is required under the
 * ePrivacy rules – this banner informs users. If you add analytics later, gate it
 * behind the "accepted" value stored here.
 */
export function CookieBanner() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    try {
      setShow(!localStorage.getItem('cookie-notice'));
    } catch {
      setShow(false);
    }
  }, []);
  if (!show) return null;

  const close = (value: string) => {
    try {
      localStorage.setItem('cookie-notice', value);
    } catch {}
    setShow(false);
  };

  return (
    <div className="fixed inset-x-3 bottom-3 z-50 sm:inset-x-auto sm:right-5 sm:bottom-5 sm:max-w-md">
      <div className="card animate-fade-up p-5 shadow-lift">
        <div className="flex gap-3">
          <Cookie className="mt-0.5 h-5 w-5 shrink-0 text-brand-600" />
          <div>
            <p className="text-sm font-semibold text-slate-900 dark:text-white">We only use essential cookies</p>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
              They keep you logged in and remember your theme. No tracking, no ads.{' '}
              <Link href="/cookies" className="font-medium text-brand-700 underline dark:text-brand-400">
                Cookie policy
              </Link>
            </p>
            <div className="mt-3 flex gap-2">
              <button className="btn-primary !py-2" onClick={() => close('essential')}>
                Got it
              </button>
              <Link href="/privacy" className="btn-ghost !py-2">
                Privacy
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
