'use client';
import { Highlight, themes } from 'prism-react-renderer';
import { useState } from 'react';
import { Check, Copy, Play, X } from 'lucide-react';
import { PyEditor } from './PyEditor';

const LABELS: Record<string, string> = {
  python: 'Python',
  'python-norun': 'Python',
  bash: 'Terminal',
  sql: 'SQL',
  text: 'Output',
  json: 'JSON',
};

export function CodeBlock({ code, lang, canRun = true }: { code: string; lang: string; canRun?: boolean }) {
  const [copied, setCopied] = useState(false);
  const [tryIt, setTryIt] = useState(false);
  const runnable = lang === 'python' && canRun;
  const prismLang = lang.startsWith('python') ? 'python' : lang === 'bash' ? 'clike' : lang;

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch {}
  };

  return (
    <div className="not-prose my-6">
      <div className="overflow-hidden rounded-2xl border border-slate-200 dark:border-slate-800">
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-4 py-2 dark:border-slate-800 dark:bg-slate-900">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">{LABELS[lang] ?? lang}</span>
          <button onClick={copy} className="flex items-center gap-1.5 rounded-md px-2 py-1 text-xs font-medium text-slate-500 hover:bg-slate-200 hover:text-slate-800 dark:hover:bg-slate-800 dark:hover:text-white" aria-label="Copy code">
            {copied ? <Check className="h-3.5 w-3.5 text-brand-600" /> : <Copy className="h-3.5 w-3.5" />}
            {copied ? 'Copied' : 'Copy'}
          </button>
        </div>
        <Highlight code={code} language={prismLang} theme={themes.oneLight}>
          {({ tokens, getLineProps, getTokenProps }) => (
            <pre className="scrollbar-thin overflow-x-auto bg-white px-4 py-4 font-mono text-[13.5px] leading-6 dark:hidden">
              {tokens.map((line, i) => (
                <div key={i} {...getLineProps({ line })}>
                  {line.map((token, k) => (
                    <span key={k} {...getTokenProps({ token })} />
                  ))}
                </div>
              ))}
            </pre>
          )}
        </Highlight>
        <Highlight code={code} language={prismLang} theme={themes.oneDark}>
          {({ tokens, getLineProps, getTokenProps }) => (
            <pre className="scrollbar-thin hidden overflow-x-auto !bg-slate-900 px-4 py-4 font-mono text-[13.5px] leading-6 dark:block">
              {tokens.map((line, i) => (
                <div key={i} {...getLineProps({ line })}>
                  {line.map((token, k) => (
                    <span key={k} {...getTokenProps({ token })} />
                  ))}
                </div>
              ))}
            </pre>
          )}
        </Highlight>
      </div>
      {runnable && !tryIt && (
        <button onClick={() => setTryIt(true)} className="btn-primary mt-3 !py-2">
          <Play className="h-4 w-4 fill-current" /> Try it Yourself »
        </button>
      )}
      {runnable && tryIt && (
        <div className="mt-3 animate-fade-up">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-sm font-semibold text-slate-700 dark:text-slate-300">Try it Yourself – edit the code and press Run</span>
            <button onClick={() => setTryIt(false)} className="btn-ghost !p-1.5" aria-label="Close editor">
              <X className="h-4 w-4" />
            </button>
          </div>
          <PyEditor initialCode={code} height={Math.min(420, Math.max(180, code.split('\n').length * 22 + 40))} />
        </div>
      )}
    </div>
  );
}
