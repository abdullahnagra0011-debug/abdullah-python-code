'use client';
import Link from 'next/link';
import { useMemo, useState } from 'react';
import { CheckCircle2, XCircle, Loader2, Lightbulb, Trophy } from 'lucide-react';
import type { PublicQuestion, Level } from '@/lib/exercise-types';
import { PyEditor } from './PyEditor';

type Feedback = { correct: boolean; explanation?: string; correctAnswer?: string | null };

const levelStyle: Record<Level, string> = {
  Beginner: 'badge-green',
  Intermediate: 'badge bg-sky-50 text-sky-700 ring-1 ring-inset ring-sky-600/20 dark:bg-sky-500/10 dark:text-sky-300',
  Advanced: 'badge bg-violet-50 text-violet-700 ring-1 ring-inset ring-violet-600/20 dark:bg-violet-500/10 dark:text-violet-300',
};

const typeLabel = { mcq: 'Multiple choice', fill: 'Fill in the code', code: 'Coding challenge' };

export function ExerciseSet({ moduleSlug, questions, signedIn }: { moduleSlug: string; questions: PublicQuestion[]; signedIn: boolean }) {
  const [answers, setAnswers] = useState<Record<number, unknown>>({});
  const [feedback, setFeedback] = useState<Record<number, Feedback>>({});
  const [checking, setChecking] = useState<number | null>(null);
  const [filter, setFilter] = useState<'All' | Level>('All');
  const [submit, setSubmit] = useState<{ state: 'idle' | 'saving' | 'saved' | 'error'; msg?: string }>({ state: 'idle' });

  const answeredCount = Object.keys(feedback).length;
  const correctCount = Object.values(feedback).filter((f: Feedback) => f.correct).length;
  const levels = useMemo(() => Array.from(new Set(questions.map((q) => q.level))), [questions]);

  const check = async (i: number, answer: unknown) => {
    setChecking(i);
    const res = await fetch('/api/exercises/check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ moduleSlug, index: i, answer }),
    });
    const j: Feedback = res.ok
      ? await res.json().catch(() => ({ correct: false, explanation: 'Could not check your answer. Try again.' }))
      : { correct: false, explanation: (await res.json().catch(() => ({}))).error || 'Could not check your answer. Try again.' };
    setChecking(null);
    setFeedback((f) => ({ ...f, [i]: j }));
  };

  const doSubmit = async () => {
    setSubmit({ state: 'saving' });
    const res = await fetch('/api/exercises/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ moduleSlug, answers }),
    });
    const j = await res.json().catch(() => ({}));
    if (res.ok) setSubmit({ state: 'saved', msg: `Saved: ${j.score}/${j.total} (${Math.round((j.score / j.total) * 100)}%)` });
    else setSubmit({ state: 'error', msg: j.error || 'Could not save your score.' });
  };

  return (
    <div>
      {/* score bar */}
      <div className="sticky top-16 z-20 -mx-2 mb-6 rounded-2xl border border-slate-200 bg-white/95 px-4 py-3 backdrop-blur dark:border-slate-800 dark:bg-slate-950/95">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3 text-sm">
            <Trophy className="h-5 w-5 text-amber-500" />
            <span className="font-semibold text-slate-900 dark:text-white">
              Score: {correctCount}/{questions.length}
            </span>
            <span className="text-slate-500">· {answeredCount} checked</span>
          </div>
          <div className="flex gap-1 rounded-lg bg-slate-100 p-1 text-xs font-medium dark:bg-slate-800">
            {(['All', ...levels] as const).map((l) => (
              <button
                key={l}
                onClick={() => setFilter(l)}
                className={`rounded-md px-2.5 py-1 transition ${filter === l ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-700 dark:text-white' : 'text-slate-500 hover:text-slate-800'}`}
              >
                {l}
              </button>
            ))}
          </div>
        </div>
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
          <div className="h-full rounded-full bg-brand-500 transition-all" style={{ width: `${(correctCount / questions.length) * 100}%` }} />
        </div>
      </div>

      <ol className="space-y-6">
        {questions.map((q, i) => {
          if (filter !== 'All' && q.level !== filter) return null;
          const fb = feedback[i];
          return (
            <li key={i} className={`card p-5 sm:p-6 ${fb ? (fb.correct ? '!border-brand-300 dark:!border-brand-800' : '!border-red-200 dark:!border-red-900') : ''}`}>
              <div className="mb-3 flex flex-wrap items-center gap-2">
                <span className="grid h-7 w-7 place-items-center rounded-lg bg-slate-900 text-xs font-bold text-white dark:bg-white dark:text-slate-900">{i + 1}</span>
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">{typeLabel[q.type]}</span>
                <span className={levelStyle[q.level]}>{q.level}</span>
              </div>
              <p className="font-medium leading-7 text-slate-900 dark:text-white">{q.prompt}</p>

              {q.type === 'mcq' && (
                <div className="mt-4 grid gap-2">
                  {q.options.map((opt, oi) => {
                    const selected = answers[i] === oi;
                    return (
                      <label
                        key={oi}
                        className={`flex cursor-pointer items-start gap-3 rounded-xl border px-4 py-3 text-sm transition ${
                          selected ? 'border-brand-500 bg-brand-50 dark:bg-brand-500/10' : 'border-slate-200 hover:border-slate-300 dark:border-slate-700'
                        }`}
                      >
                        <input
                          type="radio"
                          name={`q${i}`}
                          className="mt-0.5 accent-brand-600"
                          checked={selected}
                          onChange={() => {
                            setAnswers((a) => ({ ...a, [i]: oi }));
                            setFeedback((f) => {
                              const n = { ...f };
                              delete n[i];
                              return n;
                            });
                          }}
                        />
                        <span className="font-mono text-[13px] leading-6">{opt}</span>
                      </label>
                    );
                  })}
                  <CheckButton disabled={answers[i] === undefined} loading={checking === i} onClick={() => check(i, answers[i])} />
                </div>
              )}

              {q.type === 'fill' && (
                <div className="mt-4">
                  <pre className="overflow-x-auto rounded-xl bg-slate-900 p-4 font-mono text-[13px] leading-6 text-slate-100">{q.code}</pre>
                  <div className="mt-3 flex flex-col gap-2 sm:flex-row">
                    <input
                      className="input font-mono"
                      placeholder="Type what replaces ___"
                      value={String(answers[i] ?? '')}
                      onChange={(e) => {
                        setAnswers((a) => ({ ...a, [i]: e.target.value }));
                        setFeedback((f) => {
                          const n = { ...f };
                          delete n[i];
                          return n;
                        });
                      }}
                      onKeyDown={(e) => e.key === 'Enter' && String(answers[i] ?? '').trim() && check(i, answers[i])}
                      aria-label={`Answer for question ${i + 1}`}
                    />
                    <CheckButton disabled={!String(answers[i] ?? '').trim()} loading={checking === i} onClick={() => check(i, answers[i])} />
                  </div>
                </div>
              )}

              {q.type === 'code' && (
                <div className="mt-4">
                  {q.hint && (
                    <details className="mb-3 text-sm text-slate-600 dark:text-slate-400">
                      <summary className="cursor-pointer font-medium text-amber-600">
                        <Lightbulb className="mr-1 inline h-4 w-4" />
                        Show hint
                      </summary>
                      <p className="mt-1 pl-5">{q.hint}</p>
                    </details>
                  )}
                  <PyEditor
                    initialCode={q.starter}
                    tests={q.tests}
                    runLabel="Run & check"
                    height={220}
                    showStdin={false}
                    onResult={(r) => {
                      if (r.passed === undefined) return;
                      setAnswers((a) => ({ ...a, [i]: r.passed }));
                      if (r.passed) check(i, true);
                      else setFeedback((f) => ({ ...f, [i]: { correct: false, explanation: r.testError } }));
                    }}
                  />
                </div>
              )}

              {fb && (
                <div
                  className={`mt-4 flex gap-3 rounded-xl p-4 text-sm animate-fade-up ${
                    fb.correct ? 'bg-brand-50 text-brand-900 dark:bg-brand-500/10 dark:text-brand-200' : 'bg-red-50 text-red-900 dark:bg-red-500/10 dark:text-red-200'
                  }`}
                  role="status"
                >
                  {fb.correct ? <CheckCircle2 className="h-5 w-5 shrink-0 text-brand-600" /> : <XCircle className="h-5 w-5 shrink-0 text-red-500" />}
                  <div>
                    <p className="font-semibold">{fb.correct ? 'Correct!' : 'Not quite.'}</p>
                    {!fb.correct && fb.correctAnswer && (
                      <p className="mt-1">
                        Correct answer: <code className="rounded bg-white/70 px-1.5 py-0.5 font-mono dark:bg-black/30">{fb.correctAnswer}</code>
                      </p>
                    )}
                    {fb.explanation && <p className="mt-1 leading-6">{fb.explanation}</p>}
                  </div>
                </div>
              )}
            </li>
          );
        })}
      </ol>

      <div className="card mt-8 flex flex-wrap items-center justify-between gap-4 p-5">
        <div>
          <p className="font-semibold text-slate-900 dark:text-white">
            You answered {correctCount} of {questions.length} correctly
          </p>
          <p className="text-sm text-slate-500">Submitting grades every answer again on our server and saves your score.</p>
          {submit.msg && <p className={`mt-1 text-sm font-medium ${submit.state === 'error' ? 'text-red-600' : 'text-brand-700'}`}>{submit.msg}</p>}
        </div>
        {signedIn ? (
          <button className="btn-primary" disabled={submit.state === 'saving'} onClick={doSubmit}>
            {submit.state === 'saving' && <Loader2 className="h-4 w-4 animate-spin" />}
            Submit score
          </button>
        ) : (
          <Link href="/register" className="btn-primary">
            Sign up to save scores
          </Link>
        )}
      </div>
    </div>
  );
}

function CheckButton({ disabled, loading, onClick }: { disabled: boolean; loading: boolean; onClick: () => void }) {
  return (
    <button className="btn-primary self-start" disabled={disabled || loading} onClick={onClick}>
      {loading && <Loader2 className="h-4 w-4 animate-spin" />}
      Check
    </button>
  );
}
