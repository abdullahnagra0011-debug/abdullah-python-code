import { Markdown } from './Markdown';

export function LegalPage({ title, updated, source }: { title: string; updated: string; source: string }) {
  return (
    <div className="container max-w-3xl py-14">
      <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white">{title}</h1>
      <p className="mt-2 text-sm text-slate-500">Last updated: {updated}</p>
      <div className="mt-6 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900 dark:border-amber-900 dark:bg-amber-500/10 dark:text-amber-200">
        Template text – the site operator must review this with a qualified lawyer and fill in company details before launch.
      </div>
      <div className="mt-8">
        <Markdown source={source} canRun={false} />
      </div>
    </div>
  );
}
