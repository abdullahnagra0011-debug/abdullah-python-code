'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Menu, X, Crown, LayoutDashboard, LogOut, Shield } from 'lucide-react';
import { Logo } from './Logo';
import { ThemeToggle } from './ThemeToggle';

const links = [
  { href: '/courses', label: 'Courses' },
  { href: '/roadmap', label: 'Roadmap' },
  { href: '/learn/introduction/what-is-python', label: 'Tutorial' },
  { href: '/playground', label: 'Playground' },
  { href: '/pricing', label: 'Pricing' },
];

export function NavbarClient({
  signedIn,
  name,
  premium,
  isAdmin,
}: {
  signedIn: boolean;
  name: string;
  premium: boolean;
  isAdmin: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [menu, setMenu] = useState(false);
  const pathname = usePathname();
  useEffect(() => {
    setOpen(false);
    setMenu(false);
  }, [pathname]);

  const initial = (name || '?').trim().charAt(0).toUpperCase();
  const active = (href: string) =>
    href === '/learn/introduction/what-is-python' ? pathname.startsWith('/learn') : pathname.startsWith(href);

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200/80 bg-white/85 backdrop-blur-lg dark:border-slate-800/80 dark:bg-slate-950/85">
      <nav className="container flex h-16 items-center justify-between gap-4">
        <div className="flex items-center gap-8">
          <Logo />
          <ul className="hidden items-center gap-1 lg:flex">
            {links.map((l) => (
              <li key={l.href}>
                <Link
                  href={l.href}
                  className={`rounded-lg px-3 py-2 text-sm font-medium transition ${
                    active(l.href)
                      ? 'text-brand-700 dark:text-brand-400'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                  }`}
                >
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div className="flex items-center gap-2">
          <ThemeToggle />
          {signedIn ? (
            <div className="relative hidden lg:block">
              <button
                onClick={() => setMenu((m) => !m)}
                className="flex items-center gap-2 rounded-xl py-1 pl-1 pr-3 text-sm font-medium hover:bg-slate-100 dark:hover:bg-slate-800"
                aria-expanded={menu}
              >
                <span className="grid h-8 w-8 place-items-center rounded-lg bg-brand-600 text-sm font-bold text-white">{initial}</span>
                <span className="max-w-[140px] truncate">{name}</span>
                {premium && <Crown className="h-4 w-4 text-amber-500" aria-label="Premium" />}
              </button>
              {menu && (
                <div className="card absolute right-0 mt-2 w-56 animate-fade-up p-1.5">
                  <Link href="/dashboard" className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-slate-100 dark:hover:bg-slate-800">
                    <LayoutDashboard className="h-4 w-4" /> Dashboard
                  </Link>
                  <Link href="/dashboard/billing" className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-slate-100 dark:hover:bg-slate-800">
                    <Crown className="h-4 w-4" /> Subscription
                  </Link>
                  {isAdmin && (
                    <Link href="/admin" className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-slate-100 dark:hover:bg-slate-800">
                      <Shield className="h-4 w-4" /> Admin
                    </Link>
                  )}
                  <form action="/auth/signout" method="post">
                    <button className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-500/10">
                      <LogOut className="h-4 w-4" /> Log out
                    </button>
                  </form>
                </div>
              )}
            </div>
          ) : (
            <div className="hidden items-center gap-2 lg:flex">
              <Link href="/login" className="btn-ghost">
                Log in
              </Link>
              <Link href="/register" className="btn-primary">
                Start for free
              </Link>
            </div>
          )}
          <button className="btn-ghost h-9 w-9 !p-0 lg:hidden" onClick={() => setOpen((o) => !o)} aria-label="Toggle menu" aria-expanded={open}>
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </nav>

      {open && (
        <div className="border-t border-slate-200 bg-white px-4 pb-6 pt-2 dark:border-slate-800 dark:bg-slate-950 lg:hidden">
          <ul className="space-y-1">
            {links.map((l) => (
              <li key={l.href}>
                <Link href={l.href} className="block rounded-lg px-3 py-2.5 font-medium hover:bg-slate-100 dark:hover:bg-slate-800">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
          <div className="mt-4 grid gap-2">
            {signedIn ? (
              <>
                <Link href="/dashboard" className="btn-secondary">
                  Dashboard
                </Link>
                {isAdmin && (
                  <Link href="/admin" className="btn-secondary">
                    Admin
                  </Link>
                )}
                <form action="/auth/signout" method="post" className="grid">
                  <button className="btn-ghost text-red-600">Log out</button>
                </form>
              </>
            ) : (
              <>
                <Link href="/login" className="btn-secondary">
                  Log in
                </Link>
                <Link href="/register" className="btn-primary">
                  Start for free
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
